package com.payment_cs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment_cs.dto.InvoiceResponseDTO;
import com.payment_cs.dto.PaymentTransactionResponseDTO;
import com.payment_cs.exception.InvalidDataException;
import com.payment_cs.exception.ResourceNotFoundException;
import com.payment_cs.model.Invoice;
import com.payment_cs.model.PaymentTransaction;
import com.payment_cs.service.InvoiceService;
import com.payment_cs.service.PaymentTransactionService;

@RestController
@RequestMapping("/payment")
public class CentralController 
{
	@Autowired
	private PaymentTransactionService paymentTransactionService;
	
	@PostMapping("/paymenttransaction")
	public ResponseEntity<PaymentTransaction> createPaymentTransaction(@RequestBody PaymentTransaction paymentTransaction) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			PaymentTransaction res = paymentTransactionService.createPaymentTransaction(paymentTransaction);
			return new ResponseEntity<>(res, HttpStatus.CREATED);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/paymenttransaction/{id}")
	public ResponseEntity<PaymentTransaction> getPaymentTransactionById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			PaymentTransaction res = paymentTransactionService.getPaymentTransactionById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@PutMapping("/paymenttransaction/{id}")
	public ResponseEntity<PaymentTransaction> updatePaymentTransactionById(@PathVariable Long id, @RequestBody PaymentTransaction paymentTransaction) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			PaymentTransaction res = paymentTransactionService.updatePaymentTransactionById(id, paymentTransaction);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/paymenttransaction")
	public ResponseEntity<List<PaymentTransaction>> getAllPaymentTransactions() throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			List<PaymentTransaction> res = paymentTransactionService.getAllPaymentTransactions();
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@DeleteMapping("/paymenttransaction/{id}")
	public ResponseEntity<Void> deletePaymentTransactionById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			paymentTransactionService.deletePaymentTransactionById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/paymenttransaction/details/{id}")
	public ResponseEntity<PaymentTransactionResponseDTO> getPaymentTransactionDetailsById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			PaymentTransactionResponseDTO res = paymentTransactionService.getPaymentTransactionDetailsyId(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	
	
	//Invoice
	
	@Autowired
	private InvoiceService invoiceService;
	
	@PostMapping("/invoice")
	public ResponseEntity<Invoice> createInvoice(@RequestBody Invoice invoice) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Invoice res = invoiceService.createInvoice(invoice);
			return new ResponseEntity<>(res, HttpStatus.CREATED);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/invoice/{id}")
	public ResponseEntity<Invoice> getInvoiceById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Invoice res = invoiceService.getInvoiceById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@PutMapping("/invoice/{id}")
	public ResponseEntity<Invoice> updateInvoiceById(@PathVariable Long id, @RequestBody Invoice invoice) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Invoice res = invoiceService.updateInvoiceById(id, invoice);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/invoice")
	public ResponseEntity<List<Invoice>> getAllInvoices() throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			List<Invoice> res = invoiceService.getAllInvoices();
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@DeleteMapping("/invoice/{id}")
	public ResponseEntity<Void> deleteInvoiceById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			invoiceService.deleteInvoiceById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/invoice/details/{id}")
	public ResponseEntity<InvoiceResponseDTO> getInvoiceDetailsById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			InvoiceResponseDTO res = invoiceService.getInvoiceDetailsById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
}
