package com.payment_cs.exception;

public class ResourceNotFoundException extends RuntimeException
{

	public ResourceNotFoundException(String message) {
		super(message);
	}
	
}
