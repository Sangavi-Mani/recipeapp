package com.payment_cs.exception;

public class InvalidDataException extends RuntimeException
{

	public InvalidDataException(String message) {
		super(message);
	}
	
}
