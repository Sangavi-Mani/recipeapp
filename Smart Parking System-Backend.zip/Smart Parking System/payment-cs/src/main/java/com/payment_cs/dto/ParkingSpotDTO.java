package com.payment_cs.dto;

public class ParkingSpotDTO 
{
	
	private Long id;
	
	private String location;
	
	private ParkingStatus status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public ParkingStatus getStatus() {
		return status;
	}

	public void setStatus(ParkingStatus status) {
		this.status = status;
	}

	public ParkingSpotDTO(Long id, String location, ParkingStatus status) {
		super();
		this.id = id;
		this.location = location;
		this.status = status;
	}
	
	

	public ParkingSpotDTO() {
		super();
	}
	
}
