package com.payment_cs.model;

public enum PaymentStatus 
{
	UNKNOWN, PAID, NOT_PAID, PROCESSING;
}
