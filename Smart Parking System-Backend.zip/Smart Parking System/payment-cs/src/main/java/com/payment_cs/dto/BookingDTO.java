package com.payment_cs.dto;

import java.time.LocalDateTime;


public class BookingDTO
{
	
	private Long id;
	
	private Long userId; //Foreign to user in userMS
	
	
	private ParkingSpotDTO parkingSpot; //internal
	
	private LocalDateTime timestamp;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public ParkingSpotDTO getParkingSpot() {
		return parkingSpot;
	}

	public void setParkingSpot(ParkingSpotDTO parkingSpot) {
		this.parkingSpot = parkingSpot;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public BookingDTO(Long id, Long userId, ParkingSpotDTO parkingSpot, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.userId = userId;
		this.parkingSpot = parkingSpot;
		this.timestamp = timestamp;
	}

	public BookingDTO() {
		super();
	}
	
}
