package com.payment_cs.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class PaymentTransaction 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	private Double amount;
	private Long userId; //foreign
	
	@Enumerated(EnumType.STRING)
	private PaymentStatus status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public PaymentStatus getStatus() {
		return status;
	}

	public void setStatus(PaymentStatus status) {
		this.status = status;
	}

	public PaymentTransaction(Long id, Double amount, Long userId, PaymentStatus status) {
		super();
		this.id = id;
		this.amount = amount;
		this.userId = userId;
		this.status = status;
	}

	public PaymentTransaction() {
		super();
	}

	@Override
	public String toString() {
		return "PaymentTransaction [id=" + id + ", amount=" + amount + ", userId=" + userId + ", status=" + status
				+ "]";
	}
	
	
	
}
