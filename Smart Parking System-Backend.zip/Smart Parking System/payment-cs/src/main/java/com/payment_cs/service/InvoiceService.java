package com.payment_cs.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.payment_cs.dto.BookingDTO;
import com.payment_cs.dto.InvoiceResponseDTO;
import com.payment_cs.dto.ParkingSpotDTO;
import com.payment_cs.dto.ParkingStatus;
import com.payment_cs.exception.InvalidDataException;
import com.payment_cs.exception.ResourceNotFoundException;
import com.payment_cs.model.Invoice;
import com.payment_cs.repository.InvoiceRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class InvoiceService 
{
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private CircuitBreakerFactory circuitBreakerFactory;
	
	private final String BOOKING_URL = "http://localhost:3000/parking/booking/";
	
	@Autowired
	private InvoiceRepository invoiceRepository;
	
	public Invoice createInvoice(Invoice invoice)
	{
		if(invoice==null)
		{
			throw new ResourceNotFoundException("Invoice Not Found");
		}
		if(invoice.getAmount()==null)
		{
			throw new InvalidDataException("Invoice Data Invalid");
		}
		return invoiceRepository.save(invoice);
	}
	
	public Invoice getInvoiceById(Long id)
	{
		return invoiceRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Invoice Not Found"));
	}
	
	public Invoice updateInvoiceById(Long id, Invoice invoice)
	{
		Invoice inDB = getInvoiceById(id);
		inDB.setAmount(invoice.getAmount());
		inDB.setBookingId(invoice.getBookingId());
		inDB.setDate(invoice.getDate());
		return invoiceRepository.save(inDB);
	}
	
	public List<Invoice> getAllInvoices()
	{
		return invoiceRepository.findAll();
	}
	
	public void deleteInvoiceById(Long id)
	{
		Invoice invoice = getInvoiceById(id);
		invoiceRepository.delete(invoice);
	}
	
	
	//Linking
	
	public BookingDTO getBookingDTO(Long id)
	{
		return circuitBreakerFactory.create("bookingCircuit").run(()->{
			BookingDTO booking = restTemplate.getForObject(BOOKING_URL+id, BookingDTO.class);
			return booking;
		}, throwable->bookingFallback(id));
	}
	
	public BookingDTO bookingFallback(Long id)
	{
		ParkingSpotDTO parkingSpot = new ParkingSpotDTO(0L, "Unknown Parking Spot - Fallback", ParkingStatus.UNKNOWN);
		return new BookingDTO(id, 0L, parkingSpot, LocalDateTime.now());
	}
	
	public InvoiceResponseDTO getInvoiceDetailsById(Long id)
	{
		return circuitBreakerFactory.create("invoiceCircuit").run(()->{
			Invoice invoice = getInvoiceById(id);
			BookingDTO booking = getBookingDTO(invoice.getBookingId());
			return new InvoiceResponseDTO(invoice.getId(), booking, invoice.getAmount(), invoice.getDate());
		}, throwable->invoiceFallback(id));
	}
	
	public InvoiceResponseDTO invoiceFallback(Long id)
	{
		ParkingSpotDTO parkingSpot = new ParkingSpotDTO(0L, "Unknown Parking Spot - Fallback", ParkingStatus.UNKNOWN);
		BookingDTO booking = new BookingDTO(0L, 0L, parkingSpot, LocalDateTime.now());
		return new InvoiceResponseDTO(id, booking, Double.valueOf(0.0), LocalDate.now());
	}
}
