package com.payment_cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.payment_cs.dto.PaymentTransactionResponseDTO;
import com.payment_cs.dto.UserDTO;
import com.payment_cs.exception.InvalidDataException;
import com.payment_cs.exception.ResourceNotFoundException;
import com.payment_cs.model.PaymentStatus;
import com.payment_cs.model.PaymentTransaction;
import com.payment_cs.repository.PaymentTransactionRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PaymentTransactionService 
{
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private CircuitBreakerFactory circuitBreakerFactory;
	
	private final String USER_URL = "http://localhost:1000/user/user";
	
	@Autowired
	private PaymentTransactionRepository paymentTransactionRepository;
	
	public PaymentTransaction createPaymentTransaction(PaymentTransaction paymentTransaction)
	{
		if(paymentTransaction==null)
		{
			throw new ResourceNotFoundException("PaymentTransaction Not Found");
		}
		if(paymentTransaction.getStatus()==null)
		{
			throw new InvalidDataException("PaymentTransaction Data Invalid");
		}
		return paymentTransactionRepository.save(paymentTransaction);
	}
	
	public PaymentTransaction getPaymentTransactionById(Long id)
	{
		return paymentTransactionRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("PaymentTransaction Not Found"));
	}
	
	public PaymentTransaction updatePaymentTransactionById(Long id, PaymentTransaction paymentTransaction)
	{
		PaymentTransaction inDB = getPaymentTransactionById(id);
		inDB.setAmount(paymentTransaction.getAmount());
		inDB.setStatus(paymentTransaction.getStatus());
		inDB.setUserId(paymentTransaction.getUserId());
		return paymentTransactionRepository.save(inDB);
	}
	
	public List<PaymentTransaction> getAllPaymentTransactions()
	{
		return paymentTransactionRepository.findAll();
	}
	
	public void deletePaymentTransactionById(Long id)
	{
		PaymentTransaction paymentTransaction = getPaymentTransactionById(id);
		paymentTransactionRepository.delete(paymentTransaction);
	}
	
	
	//Linking
	
	public UserDTO getUserDTO(Long userId)
	{
		return circuitBreakerFactory.create("userCircuit").run(()->{
			UserDTO user = restTemplate.getForObject(USER_URL+"/"+userId, UserDTO.class);
			return user;
		}, throwable->userFallback(userId));
	}
	
	public UserDTO userFallback(Long userId)
	{
		return new UserDTO(userId, "Unknown User - Fallback", "Unknown");
	}
	
	public PaymentTransactionResponseDTO getPaymentTransactionDetailsyId(Long paymentTransactionId)
	{
		return circuitBreakerFactory.create("paymentTransactionCircuit").run(()->{
			PaymentTransaction paymentTransaction = getPaymentTransactionById(paymentTransactionId);
			UserDTO user = getUserDTO(paymentTransaction.getUserId());
			return new PaymentTransactionResponseDTO(paymentTransaction.getId(), paymentTransaction.getAmount(), user, paymentTransaction.getStatus());
		}, throwable->paymentTransactionFallback(paymentTransactionId));
	}
	
	public PaymentTransactionResponseDTO paymentTransactionFallback(Long paymentTransactionId)
	{
		UserDTO user = new UserDTO(0L, "Unknown User - Fallback", "Unknown");
		return new PaymentTransactionResponseDTO(paymentTransactionId, Double.valueOf(0.0), user, PaymentStatus.UNKNOWN);
	}
}
