package com.payment_cs.dto;

import java.time.LocalDate;


public class InvoiceResponseDTO 
{
	
	private Long id;
	
	private BookingDTO booking; //foreign
	
	private Double amount;
	
	private LocalDate date;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public BookingDTO getBooking() {
		return booking;
	}

	public void setBooking(BookingDTO booking) {
		this.booking = booking;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public InvoiceResponseDTO(Long id, BookingDTO booking, Double amount, LocalDate date) {
		super();
		this.id = id;
		this.booking = booking;
		this.amount = amount;
		this.date = date;
	}

	public InvoiceResponseDTO() {
		super();
	}

	
}
