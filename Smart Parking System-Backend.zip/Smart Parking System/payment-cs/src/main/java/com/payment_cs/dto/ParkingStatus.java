package com.payment_cs.dto;

public enum ParkingStatus
{
	UNKNOWN, PARKED, UNPARKED, PROCESSING;
}
