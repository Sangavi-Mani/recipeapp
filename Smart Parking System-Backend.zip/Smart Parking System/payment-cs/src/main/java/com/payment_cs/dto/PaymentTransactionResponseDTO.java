package com.payment_cs.dto;

import com.payment_cs.model.PaymentStatus;

public class PaymentTransactionResponseDTO
{
	
	private Long id;
	
	private Double amount;
	private UserDTO user; //foreign
	
	private PaymentStatus status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public UserDTO getUser() {
		return user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public PaymentStatus getStatus() {
		return status;
	}

	public void setStatus(PaymentStatus status) {
		this.status = status;
	}

	public PaymentTransactionResponseDTO(Long id, Double amount, UserDTO user, PaymentStatus status) {
		super();
		this.id = id;
		this.amount = amount;
		this.user = user;
		this.status = status;
	}

	public PaymentTransactionResponseDTO() {
		super();
	}

	
}
