package com.user_cs.model;

public enum VehicleType 
{
	UNKNOWN, CAR, TRUCK, VAN;
}
