package com.user_cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user_cs.exception.InvalidDataException;
import com.user_cs.exception.ResourceNotFoundException;
import com.user_cs.model.Vehicle;
import com.user_cs.repository.VehicleRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class VehicleService 
{
	@Autowired
	private VehicleRepository vehicleRepository;
	
	public Vehicle createVehicle(Vehicle vehicle)
	{
		if(vehicle==null)
		{
			throw new ResourceNotFoundException("Vehicle Not Found");
		}
		if(vehicle.getType()==null)
		{
			throw new InvalidDataException("Vehicle Data Invalid");
		}
		return vehicleRepository.save(vehicle);
	}
	
	public Vehicle getVehicleById(Long id)
	{
		return vehicleRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Vehicle Not Found"));
	}
	
	public Vehicle updateVehicleById(Long id, Vehicle vehicle)
	{
		Vehicle inDB = getVehicleById(id);
		inDB.setType(vehicle.getType());
		inDB.setUser(vehicle.getUser());
		return vehicleRepository.save(inDB);
	}
	
	public List<Vehicle> getAllVehicles()
	{
		return vehicleRepository.findAll();
	}
	
	public void deleteVehicleById(Long id)
	{
		Vehicle vehicle = getVehicleById(id);
		vehicleRepository.delete(vehicle);
	}
}
