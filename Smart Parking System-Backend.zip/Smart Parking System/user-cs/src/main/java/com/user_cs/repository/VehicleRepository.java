package com.user_cs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.user_cs.model.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Long>
{

}
