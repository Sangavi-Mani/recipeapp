package com.user_cs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user_cs.exception.InvalidDataException;
import com.user_cs.exception.ResourceNotFoundException;
import com.user_cs.model.User;
import com.user_cs.model.Vehicle;
import com.user_cs.service.UserService;
import com.user_cs.service.VehicleService;

@RestController
@RequestMapping("/user")
public class CentralController 
{
	@Autowired
	private UserService userService;
	
	@PostMapping("/user")
	public ResponseEntity<User> createUser(@RequestBody User user) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			User res = userService.createUser(user);
			return new ResponseEntity<>(res, HttpStatus.CREATED);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/user/{id}")
	public ResponseEntity<User> getUserById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			User res = userService.getUserById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@PutMapping("/user/{id}")
	public ResponseEntity<User> updateUserById(@PathVariable Long id, @RequestBody User user) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			User res = userService.updateUserById(id, user);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/user")
	public ResponseEntity<List<User>> getAllUsers() throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			List<User> res = userService.getAllUsers();
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@DeleteMapping("/user/{id}")
	public ResponseEntity<Void> deleteUserById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			userService.deleteUserById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	
	
	//Vehicle
	
	@Autowired
	private VehicleService vehicleService;
	
	@PostMapping("/vehicle")
	public ResponseEntity<Vehicle> createVehicle(@RequestBody Vehicle vehicle) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Vehicle res = vehicleService.createVehicle(vehicle);
			return new ResponseEntity<>(res, HttpStatus.CREATED);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/vehicle/{id}")
	public ResponseEntity<Vehicle> getVehicleById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Vehicle res = vehicleService.getVehicleById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@PutMapping("/vehicle/{id}")
	public ResponseEntity<Vehicle> updateVehicleById(@PathVariable Long id, @RequestBody Vehicle vehicle) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Vehicle res = vehicleService.updateVehicleById(id, vehicle);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/vehicle")
	public ResponseEntity<List<Vehicle>> getAllVehicles() throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			List<Vehicle> res = vehicleService.getAllVehicles();
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@DeleteMapping("/vehicle/{id}")
	public ResponseEntity<Void> deleteVehicleById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			vehicleService.deleteVehicleById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
}
