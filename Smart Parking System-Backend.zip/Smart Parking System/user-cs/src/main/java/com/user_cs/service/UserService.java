package com.user_cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user_cs.exception.InvalidDataException;
import com.user_cs.exception.ResourceNotFoundException;
import com.user_cs.model.User;
import com.user_cs.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserService 
{
	@Autowired
	private UserRepository userRepository;
	
	public User createUser(User user)
	{
		if(user==null)
		{
			throw new ResourceNotFoundException("User Not Found");
		}
		if(user.getName()==null)
		{
			throw new InvalidDataException("User Data Invalid");
		}
		return userRepository.save(user);
	}
	
	public User getUserById(Long id)
	{
		return userRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("User Not Found"));
	}
	
	public User updateUserById(Long id, User user)
	{
		User inDB = getUserById(id);
		inDB.setName(user.getName());
		inDB.setEmail(user.getEmail());
		return userRepository.save(inDB);
	}
	
	public List<User> getAllUsers()
	{
		return userRepository.findAll();
	}
	
	public void deleteUserById(Long id)
	{
		User user = getUserById(id);
		userRepository.delete(user);
	}
}
