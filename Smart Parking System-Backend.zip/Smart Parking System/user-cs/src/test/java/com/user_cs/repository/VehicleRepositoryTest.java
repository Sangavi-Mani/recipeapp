package com.user_cs.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import com.user_cs.model.Vehicle;
import com.user_cs.model.VehicleType;

@DataJpaTest
@TestPropertySource(locations="classpath:application-test.properties")
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
public class VehicleRepositoryTest 
{
	@Autowired
	private VehicleRepository vehicleRepository;
	
	private Vehicle vehicle;
	private Vehicle savedVehicle;
	
	@BeforeEach
	public void setUp()
	{
		vehicle=new Vehicle();
		vehicle.setType(VehicleType.CAR);
		savedVehicle = vehicleRepository.save(vehicle);
	}
	
	@Test
	public void testSave()
	{
		assertNotNull(savedVehicle);
		assertEquals(vehicle.getType(), savedVehicle.getType());
	}
	
	@Test
	public void testFindById()
	{
		Vehicle foundVehicle = vehicleRepository.findById(vehicle.getId()).orElse(null);
		assertNotNull(foundVehicle);
		assertEquals(vehicle.getType(), foundVehicle.getType());
	}
	
	@Test
	public void testDelete()
	{
		vehicleRepository.delete(vehicle);
		Optional<Vehicle> vehicleFoundAfterDeletion = vehicleRepository.findById(vehicle.getId());
		assertThat(vehicleFoundAfterDeletion).isNotPresent();
	}
}
