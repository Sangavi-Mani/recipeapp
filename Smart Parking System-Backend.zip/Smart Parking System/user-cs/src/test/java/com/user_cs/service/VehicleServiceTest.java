package com.user_cs.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.user_cs.model.Vehicle;
import com.user_cs.model.VehicleType;
import com.user_cs.repository.VehicleRepository;

@ExtendWith(MockitoExtension.class)
public class VehicleServiceTest 
{
	@Mock
	private VehicleRepository vehicleRepository;
	
	@InjectMocks
	private VehicleService vehicleService;
	
	private Vehicle vehicle;
	
	@BeforeEach
	public void setUp()
	{
		vehicle=new Vehicle();
		vehicle.setId(1L);
		vehicle.setType(VehicleType.CAR);
	}
	
	@Test
	public void testCreate()
	{
		when(vehicleRepository.save(vehicle)).thenReturn(vehicle);
		
		Vehicle createdVehicle = vehicleService.createVehicle(vehicle);
		assertNotNull(createdVehicle);
		assertThat(createdVehicle.getType()).isEqualTo(vehicle.getType());
		
		verify(vehicleRepository).save(vehicle);
	}
	
	@Test
	public void testGetById()
	{
		when(vehicleRepository.findById(vehicle.getId())).thenReturn(Optional.of(vehicle));
		
		Vehicle vehicleFound = vehicleService.getVehicleById(vehicle.getId());
		assertNotNull(vehicleFound);
		assertThat(vehicleFound.getType()).isEqualTo(vehicle.getType());
		
		verify(vehicleRepository).findById(vehicle.getId());
	}
	
	@Test
	public void testUpdateById()
	{
		when(vehicleRepository.findById(vehicle.getId())).thenReturn(Optional.of(vehicle));
		
		when(vehicleRepository.save(vehicle)).thenReturn(vehicle);
		
		Vehicle vehicleUpdate = new Vehicle();
		vehicleUpdate.setId(1L);
		vehicleUpdate.setType(VehicleType.TRUCK);
		
		Vehicle vehicleUpdated = vehicleService.updateVehicleById(vehicle.getId(), vehicleUpdate);
		assertNotNull(vehicleUpdated);
		assertThat(vehicleUpdated.getType()).isEqualTo(vehicle.getType());
		
		verify(vehicleRepository).save(vehicle);
		
		verify(vehicleRepository).findById(vehicle.getId());
	}
	
	@Test
	public void testDeleteById()
	{
		when(vehicleRepository.findById(vehicle.getId())).thenReturn(Optional.of(vehicle));
		
		vehicleService.deleteVehicleById(vehicle.getId());	
		
		verify(vehicleRepository).findById(vehicle.getId());
		verify(vehicleRepository).delete(vehicle);
	}
	
	@Test
	public void testGetAll()
	{
		Vehicle vehicleTwo=new Vehicle();
		vehicle.setId(2L);
		vehicle.setType(VehicleType.TRUCK);
		
		List<Vehicle> vehicleList = List.of(vehicle, vehicleTwo);
		
		when(vehicleRepository.findAll()).thenReturn(vehicleList);
		
		List<Vehicle> vehicleListGotten = vehicleService.getAllVehicles();
		assertNotNull(vehicleListGotten);
		assertThat(vehicleListGotten.size()).isEqualTo(vehicleList.size());
		assertThat(vehicleListGotten.get(1).getType()).isEqualTo(vehicleList.get(1).getType());
		
		verify(vehicleRepository).findAll();
	}
}
