package com.user_cs.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.user_cs.model.User;
import com.user_cs.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest 
{
	@Mock
	private UserRepository userRepository;
	
	@InjectMocks
	private UserService userService;
	
	private User user;
	
	@BeforeEach
	public void setUp()
	{
		user=new User();
		user.setId(1L);
		user.setName("1");
	}
	
	@Test
	public void testCreate()
	{
		when(userRepository.save(user)).thenReturn(user);
		
		User createdUser = userService.createUser(user);
		assertNotNull(createdUser);
		assertThat(createdUser.getName()).isEqualTo(user.getName());
		
		verify(userRepository).save(user);
	}
	
	@Test
	public void testGetById()
	{
		when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
		
		User userFound = userService.getUserById(user.getId());
		assertNotNull(userFound);
		assertThat(userFound.getName()).isEqualTo(user.getName());
		
		verify(userRepository).findById(user.getId());
	}
	
	@Test
	public void testUpdateById()
	{
		when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
		
		when(userRepository.save(user)).thenReturn(user);
		
		User userUpdate = new User();
		userUpdate.setId(1L);
		userUpdate.setName("100");
		
		User userUpdated = userService.updateUserById(user.getId(), userUpdate);
		assertNotNull(userUpdated);
		assertThat(userUpdated.getName()).isEqualTo(user.getName());
		
		verify(userRepository).save(user);
		
		verify(userRepository).findById(user.getId());
	}
	
	@Test
	public void testDeleteById()
	{
		when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
		
		userService.deleteUserById(user.getId());	
		
		verify(userRepository).findById(user.getId());
		verify(userRepository).delete(user);
	}
	
	@Test
	public void testGetAll()
	{
		User userTwo=new User();
		user.setId(2L);
		user.setName("2");
		
		List<User> userList = List.of(user, userTwo);
		
		when(userRepository.findAll()).thenReturn(userList);
		
		List<User> userListGotten = userService.getAllUsers();
		assertNotNull(userListGotten);
		assertThat(userListGotten.size()).isEqualTo(userList.size());
		assertThat(userListGotten.get(1).getName()).isEqualTo(userList.get(1).getName());
		
		verify(userRepository).findAll();
	}
}
