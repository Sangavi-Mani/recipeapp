package com.user_cs.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.user_cs.model.User;
import com.user_cs.model.Vehicle;
import com.user_cs.model.VehicleType;
import com.user_cs.service.UserService;
import com.user_cs.service.VehicleService;

@WebMvcTest(CentralController.class)
public class CentralControllerTest 
{
	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private UserService userService;
	
	@MockBean
	private VehicleService vehicleService;
	
	private User user;
	private Vehicle vehicle;
	
	@BeforeEach
	public void setUp()
	{
		user=new User();
		user.setId(1L);
		user.setName("1");
		
		vehicle=new Vehicle();
		vehicle.setId(1L);
		vehicle.setType(VehicleType.CAR);
	}
	
	@Test
	public void testUserCreate() throws Exception
	{
		when(userService.createUser(any(User.class))).thenReturn(user);
		
		mockMvc.perform(post("/user/user")
				.contentType("application/json")
				.content(objectMapper.writeValueAsString(user))
				)
		.andExpect(status().isCreated())
		.andExpect(jsonPath("$.name").value(user.getName()));
	}
	
	@Test
	public void testGetUserById() throws Exception
	{
		when(userService.getUserById(any(Long.class))).thenReturn(user);
		
		mockMvc.perform(get("/user/user/" + user.getId())
				.contentType("application/json")
				)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.name").value(user.getName()));
	}
	
	@Test
	public void testUpdateUserById() throws Exception
	{
		User userUpdate=new User();
		userUpdate.setId(1L);
		userUpdate.setName("100");
		
		User userUpdated=new User();
		userUpdated.setId(1L);
		userUpdated.setName("100");
		
		when(userService.updateUserById(any(Long.class), any(User.class))).thenReturn(userUpdated);
		
		mockMvc.perform(put("/user/user/"+user.getId())
				.contentType("application/json")
				.content(objectMapper.writeValueAsString(userUpdate))
				)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.name").value(userUpdated.getName()));
	}
	
	@Test
	public void testDeleteUserById() throws Exception
	{
		mockMvc.perform(delete("/user/user/" + user.getId())
				.contentType("application/json")
				)
		.andExpect(status().isNoContent());
	}
	
	@Test
	public void testGetAllUsers() throws Exception
	{
		User userTwo=new User();
		userTwo.setId(2L);
		userTwo.setName("2");
		
		List<User> userList = List.of(user, userTwo);
		
		when(userService.getAllUsers()).thenReturn(userList);
		
		mockMvc.perform(get("/user/user")
				.contentType(MediaType.APPLICATION_JSON)
				)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.length()").value(userList.size()))
		.andExpect(jsonPath("$.[1].name").value(userList.get(1).getName()));
	}
	
	
	
	
	//Vehicle
	
	
	
	
	@Test
	public void testVehicleCreate() throws Exception
	{
		when(vehicleService.createVehicle(any(Vehicle.class))).thenReturn(vehicle);
		
		mockMvc.perform(post("/user/vehicle")
				.contentType("application/json")
				.content(objectMapper.writeValueAsString(vehicle))
				)
		.andExpect(status().isCreated())
		.andExpect(jsonPath("$.type").value(vehicle.getType().toString()));
	}
	
	@Test
	public void testGetVehicleById() throws Exception
	{
		when(vehicleService.getVehicleById(any(Long.class))).thenReturn(vehicle);
		
		mockMvc.perform(get("/user/vehicle/" + vehicle.getId())
				.contentType("application/json")
				)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.type").value(vehicle.getType().toString()));
	}
	
	@Test
	public void testUpdateVehicleById() throws Exception
	{
		Vehicle vehicleUpdate=new Vehicle();
		vehicleUpdate.setId(1L);
		vehicleUpdate.setType(VehicleType.TRUCK);
		
		Vehicle vehicleUpdated=new Vehicle();
		vehicleUpdated.setId(1L);
		vehicleUpdated.setType(VehicleType.TRUCK);
		
		when(vehicleService.updateVehicleById(any(Long.class), any(Vehicle.class))).thenReturn(vehicleUpdated);
		
		mockMvc.perform(put("/user/vehicle/"+vehicle.getId())
				.contentType("application/json")
				.content(objectMapper.writeValueAsString(vehicleUpdate))
				)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.type").value(vehicleUpdated.getType().toString()));
	}
	
	@Test
	public void testDeleteVehicleById() throws Exception
	{
		mockMvc.perform(delete("/user/vehicle/" + vehicle.getId())
				.contentType("application/json")
				)
		.andExpect(status().isNoContent());
	}
	
	@Test
	public void testGetAllVehicles() throws Exception
	{
		Vehicle vehicleTwo=new Vehicle();
		vehicleTwo.setId(2L);
		vehicleTwo.setType(VehicleType.TRUCK);
		
		List<Vehicle> vehicleList = List.of(vehicle, vehicleTwo);
		
		when(vehicleService.getAllVehicles()).thenReturn(vehicleList);
		
		mockMvc.perform(get("/user/vehicle")
				.contentType(MediaType.APPLICATION_JSON)
				)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.length()").value(vehicleList.size()))
		.andExpect(jsonPath("$.[1].type").value(vehicleList.get(1).getType().toString()));
	}
}
