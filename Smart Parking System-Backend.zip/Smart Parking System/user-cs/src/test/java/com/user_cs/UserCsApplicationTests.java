package com.user_cs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCsApplicationTests {

	@Test
	void contextLoads() {
	}

}
