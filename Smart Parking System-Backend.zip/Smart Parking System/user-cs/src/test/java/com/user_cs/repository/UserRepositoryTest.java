package com.user_cs.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import com.user_cs.model.User;

@DataJpaTest
@TestPropertySource(locations="classpath:application-test.properties")
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
public class UserRepositoryTest 
{
	@Autowired
	private UserRepository userRepository;
	
	private User user;
	private User savedUser;
	
	@BeforeEach
	public void setUp()
	{
		user=new User();
		user.setName("1");
		savedUser = userRepository.save(user);
	}
	
	@Test
	public void testSave()
	{
		assertNotNull(savedUser);
		assertEquals(user.getName(), savedUser.getName());
	}
	
	@Test
	public void testFindById()
	{
		User foundUser = userRepository.findById(user.getId()).orElse(null);
		assertNotNull(foundUser);
		assertEquals(user.getName(), foundUser.getName());
	}
	
	@Test
	public void testDelete()
	{
		userRepository.delete(user);
		Optional<User> userFoundAfterDeletion = userRepository.findById(user.getId());
		assertThat(userFoundAfterDeletion).isNotPresent();
	}
}
