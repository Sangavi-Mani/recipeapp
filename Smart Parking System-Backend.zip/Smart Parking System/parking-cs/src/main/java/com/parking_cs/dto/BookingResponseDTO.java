package com.parking_cs.dto;

import java.time.LocalDateTime;

import com.parking_cs.model.ParkingSpot;

public class BookingResponseDTO
{
	private Long id;
	
	private UserDTO user; //Foreign to user in userMS
	
	private ParkingSpot parkingSpot; //internal
	
	private LocalDateTime timestamp;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UserDTO getUser() {
		return user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public ParkingSpot getParkingSpot() {
		return parkingSpot;
	}

	public void setParkingSpot(ParkingSpot parkingSpot) {
		this.parkingSpot = parkingSpot;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public BookingResponseDTO(Long id, UserDTO user, ParkingSpot parkingSpot, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.user = user;
		this.parkingSpot = parkingSpot;
		this.timestamp = timestamp;
	}

	public BookingResponseDTO() {
		super();
	}

	
}
