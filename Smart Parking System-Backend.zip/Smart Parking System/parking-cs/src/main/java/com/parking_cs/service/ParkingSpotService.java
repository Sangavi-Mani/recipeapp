package com.parking_cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.parking_cs.exception.InvalidDataException;
import com.parking_cs.exception.ResourceNotFoundException;
import com.parking_cs.model.ParkingSpot;
import com.parking_cs.repository.ParkingSpotRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ParkingSpotService 
{
	@Autowired
	private ParkingSpotRepository parkingSpotRepository;
	
	public ParkingSpot createParkingSpot(ParkingSpot parkingSpot)
	{
		if(parkingSpot==null)
		{
			throw new ResourceNotFoundException("ParkingSpot Not Found");
		}
		if(parkingSpot.getLocation()==null)
		{
			throw new InvalidDataException("ParkingSpot Data Invalid");
		}
		return parkingSpotRepository.save(parkingSpot);
	}
	
	public ParkingSpot getParkingSpotById(Long id)
	{
		return parkingSpotRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("ParkingSpot Not Found"));
	}
	
	public ParkingSpot updateParkingSpotById(Long id, ParkingSpot parkingSpot)
	{
		ParkingSpot inDB = getParkingSpotById(id);
		inDB.setLocation(parkingSpot.getLocation());
		inDB.setStatus(parkingSpot.getStatus());
		return parkingSpotRepository.save(inDB);
	}
	
	public List<ParkingSpot> getAllParkingSpots()
	{
		return parkingSpotRepository.findAll();
	}
	
	public void deleteParkingSpotById(Long id)
	{
		ParkingSpot parkingSpot = getParkingSpotById(id);
		parkingSpotRepository.delete(parkingSpot);
	}
}
