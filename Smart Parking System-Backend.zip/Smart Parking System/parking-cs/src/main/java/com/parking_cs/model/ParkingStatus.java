package com.parking_cs.model;

public enum ParkingStatus
{
	UNKNOWN, PARKED, UNPARKED, PROCESSING;
}
