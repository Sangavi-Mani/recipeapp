package com.parking_cs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.parking_cs.model.ParkingSpot;

public interface ParkingSpotRepository extends JpaRepository<ParkingSpot, Long>
{

}
