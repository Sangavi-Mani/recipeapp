package com.parking_cs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.parking_cs.dto.BookingResponseDTO;
import com.parking_cs.exception.InvalidDataException;
import com.parking_cs.exception.ResourceNotFoundException;
import com.parking_cs.model.Booking;
import com.parking_cs.model.ParkingSpot;
import com.parking_cs.service.BookingService;
import com.parking_cs.service.ParkingSpotService;

@RestController
@RequestMapping("/parking")
public class CentralController 
{
	@Autowired
	private ParkingSpotService parkingSpotService;
	
	@PostMapping("/parkingspot")
	public ResponseEntity<ParkingSpot> createParkingSpot(@RequestBody ParkingSpot parkingSpot) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			ParkingSpot res = parkingSpotService.createParkingSpot(parkingSpot);
			return new ResponseEntity<>(res, HttpStatus.CREATED);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/parkingspot/{id}")
	public ResponseEntity<ParkingSpot> getParkingSpotById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			ParkingSpot res = parkingSpotService.getParkingSpotById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@PutMapping("/parkingspot/{id}")
	public ResponseEntity<ParkingSpot> updateParkingSpotById(@PathVariable Long id, @RequestBody ParkingSpot parkingSpot) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			ParkingSpot res = parkingSpotService.updateParkingSpotById(id, parkingSpot);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/parkingspot")
	public ResponseEntity<List<ParkingSpot>> getAllParkingSpots() throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			List<ParkingSpot> res = parkingSpotService.getAllParkingSpots();
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@DeleteMapping("/parkingspot/{id}")
	public ResponseEntity<Void> deleteParkingSpotById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			parkingSpotService.deleteParkingSpotById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	
	
	//Booking
	
	@Autowired
	private BookingService bookingService;
	
	@PostMapping("/booking")
	public ResponseEntity<Booking> createBooking(@RequestBody Booking booking) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Booking res = bookingService.createBooking(booking);
			return new ResponseEntity<>(res, HttpStatus.CREATED);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/booking/{id}")
	public ResponseEntity<Booking> getBookingById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Booking res = bookingService.getBookingById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@PutMapping("/booking/{id}")
	public ResponseEntity<Booking> updateBookingById(@PathVariable Long id, @RequestBody Booking booking) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			Booking res = bookingService.updateBookingById(id, booking);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/booking")
	public ResponseEntity<List<Booking>> getAllBookings() throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			List<Booking> res = bookingService.getAllBookings();
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@DeleteMapping("/booking/{id}")
	public ResponseEntity<Void> deleteBookingById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			bookingService.deleteBookingById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
	
	@GetMapping("/booking/details/{id}")
	public ResponseEntity<BookingResponseDTO> getBookingDetailsById(@PathVariable Long id) throws ResourceNotFoundException, InvalidDataException, Exception
	{
		try
		{
			BookingResponseDTO res = bookingService.getBookingDetailsById(id);
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
		catch(ResourceNotFoundException e)
		{
			throw new ResourceNotFoundException(e.getMessage());
		}
		catch(InvalidDataException e)
		{
			throw new InvalidDataException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
}
