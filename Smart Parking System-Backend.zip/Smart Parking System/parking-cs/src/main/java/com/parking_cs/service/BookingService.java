package com.parking_cs.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.parking_cs.dto.BookingResponseDTO;
import com.parking_cs.dto.UserDTO;
import com.parking_cs.exception.InvalidDataException;
import com.parking_cs.exception.ResourceNotFoundException;
import com.parking_cs.model.Booking;
import com.parking_cs.model.ParkingSpot;
import com.parking_cs.model.ParkingStatus;
import com.parking_cs.repository.BookingRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BookingService 
{
	private final String USER_URL = "http://localhost:1000/user/user";
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private CircuitBreakerFactory circuitBreakerFactory;
	
	@Autowired
	private BookingRepository bookingRepository;
	
	public Booking createBooking(Booking booking)
	{
		if(booking==null)
		{
			throw new ResourceNotFoundException("Booking Not Found");
		}
		if(booking.getTimestamp()==null)
		{
			throw new InvalidDataException("Booking Data Invalid");
		}
		return bookingRepository.save(booking);
	}
	
	public Booking getBookingById(Long id)
	{
		return bookingRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Booking Not Found"));
	}
	
	public Booking updateBookingById(Long id, Booking booking)
	{
		Booking inDB = getBookingById(id);
		inDB.setParkingSpot(booking.getParkingSpot());
		inDB.setTimestamp(booking.getTimestamp());
		inDB.setUserId(booking.getUserId());
		return bookingRepository.save(inDB);
	}
	
	public List<Booking> getAllBookings()
	{
		return bookingRepository.findAll();
	}
	
	public void deleteBookingById(Long id)
	{
		Booking booking = getBookingById(id);
		bookingRepository.delete(booking);
	}
	
	//Linking
	public UserDTO getUserDTO(Long userId)
	{
		return circuitBreakerFactory.create("userCircuit").run(()->{
			UserDTO user = restTemplate.getForObject(USER_URL+"/"+userId, UserDTO.class);
			return user;
		}, throwable->userFallback(userId));
	}
	
	public UserDTO userFallback(Long userId)
	{
		return new UserDTO(userId, "Unknown User - Fallback", "Unknown");
	}
	
	public BookingResponseDTO getBookingDetailsById(Long bookingId)
	{
		return circuitBreakerFactory.create("bookingCircuit").run(()->{
			Booking booking = getBookingById(bookingId);
			UserDTO user = getUserDTO(booking.getUserId());
			return new BookingResponseDTO(booking.getId(), user, booking.getParkingSpot(), booking.getTimestamp());
		}, throwable->bookingFallback(bookingId));
	}
	
	public BookingResponseDTO bookingFallback(Long bookingId)
	{
		UserDTO user = new UserDTO(0L, "Unknown User - Fallback", "Unknown");
		ParkingSpot parkingSpot = new ParkingSpot(0L, "Unknown Parking Spot - Fallback", ParkingStatus.UNKNOWN);
		return new BookingResponseDTO(bookingId, user, parkingSpot, LocalDateTime.now());
	}
}
