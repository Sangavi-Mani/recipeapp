package com.parking_cs.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ParkingSpot 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	private String location;
	
	@Enumerated(EnumType.STRING)
	private ParkingStatus status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public ParkingStatus getStatus() {
		return status;
	}

	public void setStatus(ParkingStatus status) {
		this.status = status;
	}

	public ParkingSpot(Long id, String location, ParkingStatus status) {
		super();
		this.id = id;
		this.location = location;
		this.status = status;
	}
	
	

	public ParkingSpot() {
		super();
	}

	@Override
	public String toString() {
		return "ParkingSpot [id=" + id + ", location=" + location + ", status=" + status + "]";
	}
	
	
	
}
