package com.parking_cs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingCsApplicationTests {

	@Test
	void contextLoads() {
	}

}
