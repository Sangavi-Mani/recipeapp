package com.mycompany.app.util;

import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mycompany.app.entity.Article;
import com.mycompany.app.entity.Catagory;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {
	
private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory() {
		
		try {
			
			
			//loading the configuration and mapping -> hibernate.cfg.xml 
			Configuration config = new Configuration().configure();
			
			config.addAnnotatedClass(Catagory.class);
			config.addAnnotatedClass(Article.class);
			ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().
					applySettings(config.getProperties()).build();
			
			
			
			//Builds the session factory
			sessionFactory = config.buildSessionFactory(serviceRegistry);
			
			
	
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return sessionFactory;
	}
	
		

}
