package com.mycompany.app.entity;

import java.io.Serializable;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name ="catagory")
public class Catagory  implements Serializable{
	
	@Id
	@GeneratedValue
	@Column(name = "CATAGORY_ID")
	private Long id;
	private String  name;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(
		name = "CATEGORY_ARTICLE",
		joinColumns = @JoinColumn(name = "CATEGORY_ID"),
		inverseJoinColumns = @JoinColumn(name = "ARTICLE_ID")
	)
	private Set<Article> articles;
	
	
	public Catagory() {
		
	}
	
	public Catagory(String name) {
		this.name = name;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void setArticles(Set<Article> articles) {
		this.articles = articles;
	}
	
	
	public Set<Article> getArticles() {
		return articles;
	}
	
	
	


}
