package com.mycompany.app;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.hibernate.Session;

import com.mycompany.app.entity.*;
import com.mycompany.app.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App 
{
	static Session session = HibernateUtil.getSessionFactory().openSession();
    public static void main( String[] args )
    {
    	
        System.out.println( "Hello World!" );
        
        
       insertCatagoryWithArticles();
       
      fetchArticlesForCatagory();

       
       
       
    }

	private static void fetchArticlesForCatagory() {
		// TODO Auto-generated method stub
		
	       session.beginTransaction();
	       
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter catagory id to fetch articles ");
		int postId = sc.nextInt();
		
		
		String query = " from Catagory c where c.id = "+postId;
		
		List<Catagory> comments = session.createQuery(query).getResultList();
		
		System.out.println(comments.size());
		
		for(Catagory comm : comments) {
			System.out.println("  id "+comm.getId()+" \t  name : "+comm.getName());
			Set<Article> articles = comm.getArticles();
			for(Article art : articles) {
				System.out.println("  id "+art.getId()+" \t  content : "+art.getContent());
			}
		}

		
	}

	private static void insertCatagoryWithArticles() {
		// TODO Auto-generated method stub
		
			Session session = HibernateUtil.getSessionFactory().openSession();
	       session.beginTransaction();
	       
	       Catagory catagory = new Catagory("Cricket");
	       
	       
	       Article articleOne = new Article("IPL 2024 Auction:", 
	    		   "Seven cricketers who could fetch highest bids" 
	    		   ,
	    		   "Seven cricketers who could fetch highest bids"  
	       	       	, "Cricket, IPL");
	       Set<Article>  articles = new HashSet<Article>();
	       articles.add(articleOne);
	      // articles.add(articleTwo);
	       
	       catagory.setArticles(articles);
	       
	       session.save(catagory);
	       
	       session.getTransaction().commit();
	       session.close();
	       
		
	}
}
