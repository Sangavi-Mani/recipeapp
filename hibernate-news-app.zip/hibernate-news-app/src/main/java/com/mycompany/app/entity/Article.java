package com.mycompany.app.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="article")
public class Article implements Serializable {

	
	@Id
	@GeneratedValue
	@Column(name = "ARTICLE_ID")
	private Long id;
	private String title;
	private String description;
	private String keywords;
	private String content;
	
	public Article() {
		
	}
	
	public Article(String title, String description, String content, String keywords) {
		 this.title = title;
		 this.description = description;
		 this.keywords = keywords;
		 this.content = content;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
	
	
	
}
