package com.mycompany.app;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        
		/*
		 * int x = 5; x += (x++) + (++x); System.out.println(x);
		 */
        
        int x = 5;  int y = x++ + ++x;  System.out.println(y); 

    }
}
