package com.mycompany.app.model;


import java.util.Set;

public class Bank {
    private int bankId;
    private String name;
    private Set<Account> accounts;

    // Getters and Setters
    public int getBankId() { return bankId; }
    public void setBankId(int bankId) { this.bankId = bankId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Set<Account> getAccounts() { return accounts; }
    public void setAccounts(Set<Account> accounts) { this.accounts = accounts; }
	@Override
	public String toString() {
		return "Bank [bankId=" + bankId + ", name=" + name + ", accounts=" + accounts + "]";
	}
    
}
