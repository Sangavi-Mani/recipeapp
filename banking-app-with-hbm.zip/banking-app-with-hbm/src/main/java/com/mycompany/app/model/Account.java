package com.mycompany.app.model;


public class Account {
    private int accountId;
    private String type;
    private double balance;
    private Bank bank;

    // Getters and Setters
    public int getAccountId() { return accountId; }
    public void setAccountId(int accountId) { this.accountId = accountId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }

    public Bank getBank() { return bank; }
    public void setBank(Bank bank) { this.bank = bank; }
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", type=" + type + ", balance=" + balance +  "]";
	}
    
    
}
