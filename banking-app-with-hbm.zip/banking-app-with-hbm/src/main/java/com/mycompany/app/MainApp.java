package com.mycompany.app;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mycompany.app.model.*;
import com.mycompany.app.util.HibernateUtil;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainApp {
    @SuppressWarnings("deprecation")
	public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Bank bank = new Bank();
        bank.setName("City Bank");

        Account acc1 = new Account();
        acc1.setType("Savings");
        acc1.setBalance(10000);
        acc1.setBank(bank);

        Account acc2 = new Account();
        acc2.setType("Current");
        acc2.setBalance(20000);
        acc2.setBank(bank);

        //
        Set<Account> accounts = new HashSet<>();
        accounts.add(acc1);
        accounts.add(acc2);
        //session.merge(bank)
        bank.setAccounts(accounts);

        session.save(bank);  // Cascades and saves accounts too
        tx.commit();
       
        System.out.println("Bank and Accounts saved!");
        
        //Query: Get Account by Type and Minimum Balance
        String hql = "FROM Account A WHERE A.type = :type AND A.balance > :minBalance";
        List<Account> result = session.createQuery(hql)
            .setParameter("type", "Savings")
            .setParameter("minBalance", 5000.0)
            .list();

        System.out.println(result);
        
        
        //SQL Join: Bank + Account Native SQL Query
        String sql = "SELECT b.name, a.type, a.balance FROM banks b " +
                "JOIN accounts a ON b.bank_id = a.bank_id " +
                "WHERE a.balance > ? ";
   List<Object[]> result1 = session.createNativeQuery(sql)
       .setParameter(1, 1000)
        .list();

   for (Object[] row : result1) {
       System.out.println("Bank: " + row[0] + ", Type: " + row[1] + ", Balance: " + row[2]);
   }
        session.close();

    }
}
