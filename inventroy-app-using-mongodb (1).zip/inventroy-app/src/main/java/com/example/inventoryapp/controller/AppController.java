package com.example.inventoryapp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.inventoryapp.model.Order;
import com.example.inventoryapp.model.OrderDTO;
import com.example.inventoryapp.model.Product;
import com.example.inventoryapp.service.OrderService;
import com.example.inventoryapp.service.ProductService;

@Controller
public class AppController {
	@Autowired
	private ProductService service;
	@Autowired
	private OrderService orderService;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Product> listProducts = service.listAll();
		model.addAttribute("listOfProducts", listProducts);
		List<Order> listOfOrders = orderService.listAll();
		model.addAttribute("listOfOrders", listOfOrders);
		return "index";
	}
	
	
	@RequestMapping("/login")
	public String showLogin(Model model) {
		
		return "login";
	}
	
	@RequestMapping("/new")
	public String showNewProduct(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		return "new-product";
	}
	
	
	@RequestMapping("/new-order")
	public String showNewOrder(Model model) {
		OrderDTO order = new OrderDTO();
		List<Product> prodNames = service.listAll();
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println(prodNames);
		model.addAttribute("listOfProds", prodNames);
		model.addAttribute("orderDTO", order);
		return "new-order";
		
	}
	
	
	
	@RequestMapping("/save")
	public String saveProduct(@ModelAttribute("product") Product product) {
		service.save(product);
		return "redirect:/";
	}
	
	@RequestMapping("/save-order")
	public String saveOrder(@ModelAttribute("order")  OrderDTO order, BindingResult bindingResult,
            Model model
			) {
		
		System.out.println(" Save Order ");
		
		if(bindingResult.hasErrors()){
            Map<String, String> errorsMap = ControllerUtils.getErrors(bindingResult);
            model.mergeAttributes(errorsMap);

            //return "index"
        } else{
        	
        	System.out.println(order);
        	Product product = service.get(order.getProductid());
        	Order orderObj = new Order();
        	orderObj.setName(order.getName());
        	orderObj.setOrderId(order.getOrderId());
        	orderObj.setSelectedProduct(product);
        	orderObj.setCount(order.getCount());
        	orderService.save(orderObj);
        }
        	return "redirect:/";
	}
	@RequestMapping("/save-order-byid")
	public String saveOrderById(@ModelAttribute("order")  OrderDTO order, BindingResult bindingResult,
            Model model
			) {
		
		System.out.println(" Save Order ");
		
		if(bindingResult.hasErrors()){
            Map<String, String> errorsMap = ControllerUtils.getErrors(bindingResult);
            model.mergeAttributes(errorsMap);

            //return "index"
        } else{
        	
        	System.out.println(order);
        	Product product = service.get(order.getProductid().toString());
        	Order orderObj = orderService.get(order.getId().toString());
        	orderObj.setName(order.getName());
        	orderObj.setSelectedProduct(product);
        	orderObj.setCount(order.getCount());
        	orderService.save(orderObj);
        }
        	return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductPage(@PathVariable (name="id") String id) {
		ModelAndView mav = new ModelAndView("edit_product");
		Product product = service.get(id);
		mav.addObject("product", product);
		return mav;
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteProduct(@PathVariable (name="id") String id) {
		service.delete(id);
		return "redirect:/";
	}
	
	@RequestMapping("/edit-order/{id}")
	public ModelAndView showEditOrderPage(@PathVariable (name="id") String id) {
		ModelAndView mav = new ModelAndView("edit-order");
		Order order = orderService.get(id);
		OrderDTO orderDTO = new OrderDTO();
		orderDTO.setId(order.getId().toString());
		orderDTO.setName(order.getName());
		orderDTO.setCount(order.getCount());
		orderDTO.setProductid(order.getSelectedProduct().getId());
		List<Product> prodNames = service.listAll();
		System.out.println(" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
		System.out.println(prodNames);
		mav.addObject("listOfProds", prodNames);
		mav.addObject("order", orderDTO);
		return mav;
	}
	
	@RequestMapping("/delete-order/{id}")
	public String deleteOrder(@PathVariable (name="id") String id) {
		orderService.delete(id);
		return "redirect:/";
	}
}
