package com.example.inventoryapp.controller;

public class CustomErrorController {

}
