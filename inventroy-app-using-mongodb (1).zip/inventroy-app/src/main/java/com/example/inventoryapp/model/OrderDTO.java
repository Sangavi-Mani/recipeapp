package com.example.inventoryapp.model;

public class OrderDTO {
	private String id;
	private Long orderId;
	
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	private String name;
	private String productid;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductid() {
		return productid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	private int count;
	
	public OrderDTO() {
		
	}
	@Override
	public String toString() {
		return "OrderDTO [name=" + name + ", productid=" + productid + ", count=" + count + "]";
	}
	

}
