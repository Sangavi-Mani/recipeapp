package com.example.inventoryapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.inventoryapp.model.Order;
import com.example.inventoryapp.model.Product;
import com.example.inventoryapp.repository.OrderRepository;


@Service

public class OrderService {
	
	@Autowired
	private OrderRepository repo;
	
	public List<Order> listAll(){
		return repo.findAll();
		
	}
	
	public void save(Order order) {
		repo.save(order);
	}
	
	public Order get(String id) {
		return repo.findById(id).get();
	}
	
	public void delete(String id) {
		repo.deleteById(id);
	}

}
