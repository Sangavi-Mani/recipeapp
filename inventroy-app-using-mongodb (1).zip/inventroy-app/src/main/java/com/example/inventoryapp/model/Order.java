package com.example.inventoryapp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.*;


@Document
public class Order {
	
	@Id
	private String id;
	
	@Indexed(unique = true, background = true)
	private Long orderId;
	
	List<Product> prod;
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	private String name;
	private int count;
	
	private Product selectedProduct;
	
	
	public int getCount() {
		return count;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", name=" + name + ", product=" + selectedProduct + ", count=" + count + "]";
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Order() {
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Product getSelectedProduct() {
		return selectedProduct;
	}

	public void setSelectedProduct(Product product) {
		this.selectedProduct = product;
	}
	
	
	
	

}
