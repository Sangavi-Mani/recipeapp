package com.example.activity_service.service;

import com.example.activity_service.model.Activity;
import com.example.activity_service.repository.ActivityRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service

public class ActivityService {
	@Autowired
    private  ActivityRepository activityRepository;

    public Activity logActivity(Activity activity) {
    	if (activity.getDate() == null) {
            activity.setDate(LocalDate.now());
        }
        
        return activityRepository.save(activity);
    }

    public List<Activity> getActivitiesByUser(Long userId) {
        return activityRepository.findByUserId(userId);
    }
    
    
}

