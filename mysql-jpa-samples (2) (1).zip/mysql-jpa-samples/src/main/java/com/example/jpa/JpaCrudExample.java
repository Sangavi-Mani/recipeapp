package com.example.jpa;

import java.util.List;
import java.util.Scanner;

import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;

public class JpaCrudExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//JpaCrudExample.insertProduct();
	//	JpaCrudExample.insertProductFromUser();
	//	JpaCrudExample.retrieveProduct();
		JpaCrudExample.retrieveAllProducts();
		JpaCrudExample.sumOfAllPrices();
		
		//JpaCrudExample.updateProduct();
	//	JpaCrudExample.deleteProduct();
		

	}

	private static void sumOfAllPrices() {
		// TODO Auto-generated method stub
		System.out.println(" inside all");
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//retrieve 
		Double  sumOfPrice = (Double)em.createNamedQuery("findTotalPrice").getSingleResult();
		System.out.println(sumOfPrice);
		
		
	}

	private static void insertProductFromUser() {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter Product details");
		System.out.println("Enter product name :");
		String pname = sc.next();
		System.out.println("Enter product id :");
		long idd = sc.nextLong();
		System.out.println("Enter product price :");
		long price = sc.nextLong();
		
		Product prod = new Product();
		prod.setId(idd);
		prod.setName(pname);
		prod.setPrice(price);
//		//insert query 
		em.persist(prod);
//		
		em.getTransaction().commit();
		
	}

	private static void deleteProduct() {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//retrieve 
		Long key = Long.valueOf(3);
		Product prod = em.find(Product.class, key);
		System.out.println(" Product id "+prod.getId()+" \t Product Name : "+prod.getName()+"\t Price : "+prod.getPrice());
		//delete query
		em.remove(prod);
		

		em.getTransaction().commit();
		
	}

	private static void updateProduct() {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//retrieve 
		Long key = Long.valueOf(7);
		Product prod = em.find(Product.class, key);
		System.out.println(" Product id "+prod.getId()+" \t Product Name : "+prod.getName()+"\t Price : "+prod.getPrice());
		//update query
		prod.setPrice(400);

		em.getTransaction().commit();
		retrieveProduct();

		
	}

	private static void retrieveAllProducts() {
		System.out.println(" inside all");
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//retrieve 
		List<Product> prods = em.createNamedQuery("findAllProducts").getResultList();
		System.out.println(prods.size());
		
		for(Product prod : prods) {
			System.out.println(" Product id "+prod.getId()+" \t Product Name : "+prod.getName()+"\t Price : "+prod.getPrice());
		}
//		em.getTransaction().commit();

	}

	private static void retrieveProduct() {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		//retrieve 
		Long key = Long.valueOf(7);
		//select query
		Product prod = em.find(Product.class, key);
		System.out.println(" Product id "+prod.getId()+" \t Product Name : "+prod.getName()+"\t Price : "+prod.getPrice());

	//	em.getTransaction().commit();

	}

	private static void insertProduct() {
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
			
		Product prod = new Product();
		prod.setId(6L);
		prod.setName("Computers");
		prod.setPrice(150.00);
		//insert query 
		em.persist(prod);
		
		Product prod1 = new Product();
		prod1.setId(7L);
		prod1.setName("Laptops");
		prod1.setPrice(200.00);
		em.persist(prod1);

		em.getTransaction().commit();
		
		
	}

}
