package com.example.customer.repository;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;
import com.example.customer.model.Category;

@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
@TestPropertySource(locations = "classpath:application-test.properties")
public class CategoryRepositoryTest {
	@Autowired CategoryRepository categoryRepository;
	
	@Test
	@DisplayName("Test save ")
	public void testSaveCategory() {
		//ARRANGE
		Category category=new Category();
		category.setName("tour");
		
		//ACT
		Category saveCatgeory=categoryRepository.save(category);
		Optional<Category> retrieveCategory=categoryRepository.findById(categoryRepository.save(category).getId());
		
		//ASSERT
		assertThat(retrieveCategory).isPresent();
		assertThat(retrieveCategory.get().getName()).isEqualTo("tour");
		assertEquals("tour", retrieveCategory.get().getName());
	}
	
	@Test
	@DisplayName("Test FindAll Method")
	public void testfindAllMethod() {
		Category category = new Category();
		category.setName("technical");
		category.setDescription("this is tech");
		categoryRepository.save(category);
		
		Category userOne = new Category();
		userOne.setName("billing");
		userOne.setDescription("this is bill");
		categoryRepository.save(userOne);
		
		List<Category> userTwo = categoryRepository.findAll();
		assertThat(userTwo).isNotNull();
		assertThat(userTwo.size()).isEqualTo(2);
		
	}
	
	@Test
	public void testDeleteCategory() {
		//ARRNAGE
		Category category=new Category();
		category.setName("tour");
		Category saveCategory=categoryRepository.save(category);
		
		//ACT
		categoryRepository.deleteById(saveCategory.getId());
		Optional<Category> deleteCategory=categoryRepository.findById(saveCategory.getId());
		
		//ASSERT
		assertThat(deleteCategory).isNotPresent();
		
		
	}

}
