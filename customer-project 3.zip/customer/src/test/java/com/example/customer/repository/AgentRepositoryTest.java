package com.example.customer.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import com.example.customer.model.Agent;

@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
@TestPropertySource(locations = "classpath:application-test.properties")
public class AgentRepositoryTest {
	@Autowired AgentRepository agentRepository;
	
	@Test
	@DisplayName("Test save ")
	public void testSaveAndFindById() {
		//ARRANGE
		Agent agent=new Agent();
		agent.setName("dv");
		
		//ACT
		Agent saveAgent=agentRepository.save(agent);
		Optional<Agent> retrieveAgent=agentRepository.findById(agentRepository.save(agent).getId());
		
		//ASSERT
		assertThat(retrieveAgent).isPresent();
		assertThat(retrieveAgent.get().getName()).isEqualTo("dv");
		//assertEquals("dv", retrieveAgent.get().getName());
	}
	
	@Test
	public void testDeleteAgent() {
		//ARRNAGE
		Agent agent=new Agent();
		agent.setName("vidhya");
		Agent saveAgent=agentRepository.save(agent);
		
		//ACT
		agentRepository.deleteById(saveAgent.getId());
		Optional<Agent> deleteAgent=agentRepository.findById(saveAgent.getId());
		
		//ASSERT
		assertThat(deleteAgent).isNotPresent();
		
		
	}

}
