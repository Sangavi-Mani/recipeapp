package com.example.customer.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import com.example.customer.model.Customer;


@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
@TestPropertySource(locations = "classpath:application-test.properties")
public class CustomerRepositoryTest {
	@Autowired CustomerRepository customerRepository;
	
	@Test
	@DisplayName("Test save ")
	public void testSaveAndFindById() {
		//ARRANGE
		Customer customer=new Customer();
		customer.setName("dv");
		
		//ACT
		Customer saveCustomer=customerRepository.save(customer);
		Optional<Customer> retrieveCustomer=customerRepository.findById(customerRepository.save(customer).getId());
		
		//ASSERT
		assertThat(retrieveCustomer).isPresent();
		assertThat(retrieveCustomer.get().getName()).isEqualTo("dv");
		//assertEquals("dv", retrieveAgent.get().getName());
	}
	
	@Test
	public void testDeleteAgent() {
		//ARRNAGE
		Customer customer=new Customer();
		customer.setName("vidhya");
		Customer saveCustomer=customerRepository.save(customer);
		
		//ACT
		customerRepository.deleteById(saveCustomer.getId());
		Optional<Customer> deleteCustomer=customerRepository.findById(saveCustomer.getId());
		
		//ASSERT
		assertThat(deleteCustomer).isNotPresent();
		
		
	}
}