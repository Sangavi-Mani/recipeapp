package com.example.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer.model.Ticket;
import com.example.customer.repository.TicketRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class TicketService {
	
	@Autowired
	private TicketRepository ticketRepository;
	
	public Ticket saveTicket(Ticket ticket) {
		return ticketRepository.save(ticket);
	}
	
	public Ticket getTicket(Long id) {
		return ticketRepository.findById(id).orElse(null);	}
	
	public List<Ticket> getAllTickets(){
		return ticketRepository.findAll();
	}
	
	public void deleteTicket(Long id) {
		ticketRepository.deleteById(id);
	}

	public boolean CheckPriority(String priority) {
		// TODO Auto-generated method stub
		if(priority.equalsIgnoreCase("low") || priority.equalsIgnoreCase("high") || priority.equalsIgnoreCase("medium")) {
			return true;
		}
		return false;
	}

}
