package com.example.customer.exception;

public class TicketPriorityInvalidException extends RuntimeException{
	public TicketPriorityInvalidException(String msg) {
		super(msg);
	}

}
