package com.example.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer.model.Category;
import com.example.customer.repository.CategoryRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CategoryService {
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	public Category saveCategory(Category category) {
		return categoryRepository.save(category);
	}
	
	public Category getCategory(Long id) {
		return categoryRepository.findById(id).orElse(null);
	}
	
	public List<Category> getAllCategories(){
		return categoryRepository.findAll();
	}
	
	public void deleteCategory(Long id) {
		categoryRepository.deleteById(id);
	}

	public boolean categoryExist(String name) {
		
		for(Category c:categoryRepository.findAll()) {
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$ ");
			if(c.getName().equalsIgnoreCase(name)) {
				System.out.println("$$$$$$$$$$$$$$$$$$$$$$  true");
				return true;
			}
		}
		return false;
	}

}
