package com.example.customer.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer.model.Response;
import com.example.customer.repository.ResponseRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ResponseService {
	@Autowired
	private ResponseRepository responseRepository;
	
	public Response saveResponse(Response response) {
		return responseRepository.save(response);
	}
	
	public List<Response> getAllResponses(){
		return responseRepository.findAll();
	}
	
	public Response getResponse(Long id) {
		return responseRepository.findById(id).orElse(null);
	}
	
	public void deleteResponse(Long id) {
		responseRepository.deleteById(id);
	}

	public List<Response> getResponseByTicketId(Long ticketId) {
		List<Response> responseList=new ArrayList<>();
		for(Response r:responseRepository.findAll()) {
			if(r.getTicket().getId()==ticketId) {
				responseList.add(r);
			}
		}
		return responseList;
	}
	
}
