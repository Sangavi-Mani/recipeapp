package com.example.customer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Agent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String email;
	
	@ManyToOne
	@JoinColumn(name="ticket_id")
	private Ticket ticket;
	
	@OneToMany(mappedBy = "agent", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Response> responses;
	
	public Long getId() {
		return id;
	}

	
	

	public List<Response> getResponses() {
		return responses;
	}




	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}




	public void setId(Long id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public Ticket getTicket() {
		return ticket;
	}



	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}



	public Agent() {
		super();
	}



	@Override
	public String toString() {
		return "Agent [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
	
	

}
