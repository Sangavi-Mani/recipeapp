package com.example.customer.exception;


public class CategoryAlreadyExistException extends RuntimeException{
	public CategoryAlreadyExistException(String msg) {
		super(msg);
	}

}
