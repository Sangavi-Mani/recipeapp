package com.example.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer.model.Agent;
import com.example.customer.repository.AgentRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AgentService {
	
	@Autowired
	private AgentRepository agentRepository;
	
	public Agent saveAgent(Agent agent) {
		return agentRepository.save(agent);
	}
	
	public Agent getAgent(Long id) {
		return agentRepository.findById(id).orElse(null);
	}
	
	public List<Agent> getAllAgents(){
		return agentRepository.findAll();
	}
	
	public void deleteAgent(Long id) {
		agentRepository.deleteById(id);
	}

}
