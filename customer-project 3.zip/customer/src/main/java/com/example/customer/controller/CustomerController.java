package com.example.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.customer.exception.CategoryAlreadyExistException;
import com.example.customer.exception.TicketNotFoundException;
import com.example.customer.exception.TicketPriorityInvalidException;
import com.example.customer.model.Agent;
import com.example.customer.model.Category;
import java.util.*;
import com.example.customer.model.Customer;
import com.example.customer.model.Response;
import com.example.customer.model.Ticket;
import com.example.customer.service.AgentService;
import com.example.customer.service.CategoryService;
import com.example.customer.service.CustomerService;
import com.example.customer.service.ResponseService;
import com.example.customer.service.TicketService;

@RestController
public class CustomerController {
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private AgentService agentService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private ResponseService responseService;
	
	@Autowired
	private TicketService ticketService;
	
	@PostMapping("/customers")
	public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer){
		try {
			Customer customerObj=customerService.saveCustomer(customer);
			return new ResponseEntity<Customer>(customerObj,HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@GetMapping("/customers/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable("id") Long id){
		Customer customer=customerService.getCustomer(id);
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		
	}
	
	@PostMapping("/tickets")
	public ResponseEntity<Ticket> saveTicket(@RequestBody Ticket ticket) throws Exception{
		try {
			if(!ticketService.CheckPriority(ticket.getPriority())) {
				throw new TicketPriorityInvalidException("Invalid prority : "+ticket.getPriority());
			}
			Ticket ticketObj=ticketService.saveTicket(ticket);
			return new ResponseEntity<Ticket>(ticketObj,HttpStatus.OK);
		}catch(Exception e) {
			throw new Exception(e.getMessage());
		}
		//return null;
		
	}
	
	@GetMapping("/tickets")
	public ResponseEntity<List<Ticket>> getAllTickets(){
		
		List<Ticket> ticketList=ticketService.getAllTickets();
		return new ResponseEntity<List<Ticket>>(ticketList, HttpStatus.OK);
	}
	
	@GetMapping("/tickets/{id}")
	public ResponseEntity<Ticket> getTicketById(@PathVariable("id") Long id){
		Ticket ticket=ticketService.getTicket(id);
		if(ticket==null) {
			throw new TicketNotFoundException("ticket is not found with id : "+id);
		}
	
		return new ResponseEntity<Ticket>(ticket, HttpStatus.OK);
		
	}
	
	//update ticket
	@PutMapping("/tickets/{id}/close")
	public ResponseEntity<Ticket> CloseTicket(@PathVariable("id") Long id, @RequestBody Ticket ticket){
		Ticket ticketObj=ticketService.getTicket(id);
		ticketObj.setSubject(ticket.getSubject());
		ticketObj.setDescription(ticket.getDescription());
		ticketObj.setStatus(ticket.getStatus());
		ticketObj.setPriority(ticket.getPriority());
		ticketObj.setCreated_at(ticket.getCreated_at());
		
		Customer customer=customerService.getCustomer(ticket.getCustomer().getId());
		customer.setName(ticket.getCustomer().getName());
		customer.setEmail(ticket.getCustomer().getEmail());
		customer.setCreated_at(ticket.getCustomer().getCreated_at());
		
		Category category=categoryService.getCategory(ticket.getCategory().getId());
		category.setName(ticket.getCategory().getName());
		category.setDescription(ticket.getCategory().getDescription());
		
		ticketObj.setCategory(category);
		ticketObj.setCustomer(customer);
		
		ticketService.saveTicket(ticketObj);
		
		return new ResponseEntity<Ticket>(ticketObj, HttpStatus.OK);
	}
	
	/*•	PUT /tickets/{id}/assign: Assign an agent to a ticket
	@PutMapping("/tickets/{id}/assign")
	public ResponseEntity<Ticket> assignAgentToTicket(@PathVariable("id")Long id){
		Ticket ticket=ticketService.getTicket(id);
		
		
	}*/
	

	@PostMapping("/agents")
	public ResponseEntity<Agent> saveAgent(@RequestBody Agent agent){
		try {
			Agent agentObj=agentService.saveAgent(agent);
			return new ResponseEntity<Agent>(agentObj,HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@GetMapping("/agents/{id}")
	public ResponseEntity<Agent> getAgentById(@PathVariable("id") Long id){
		Agent agent=agentService.getAgent(id);
		return new ResponseEntity<Agent>(agent, HttpStatus.OK);
		
	}
	
	//•	GET /agents/{id}/tickets: Get tickets assigned to a specific agent
	@GetMapping("/agents/{id}/tickets")
	public ResponseEntity<Ticket> getTicketByAgent(@PathVariable("id")Long id){
		Agent agent=agentService.getAgent(id);
		Ticket ticket=agent.getTicket();
		return new ResponseEntity<Ticket>(ticket, HttpStatus.OK );
	}
	
	@PostMapping("/responses")
	public ResponseEntity<Response> saveResponse(@RequestBody Response response){
		try {
			Response responseObj=responseService.saveResponse(response);
			return new ResponseEntity<Response>(responseObj,HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@GetMapping("/responses/{ticketId}")
	public ResponseEntity<List<Response>> getAllResponses(@PathVariable("ticketId") Long ticketId){
		List<Response> responseList=responseService.getResponseByTicketId(ticketId);
		return new ResponseEntity<List<Response>>(responseList, HttpStatus.OK);
	}
	
	@PostMapping("/categories")
	public ResponseEntity<Category> saveCatgory(@RequestBody Category category) throws Exception{
		try {
			if(categoryService.categoryExist(category.getName())) {
				throw new CategoryAlreadyExistException("categroy "+ category.getName()+" is already exits.");
			}
			Category categoryObj=categoryService.saveCategory(category);
			return new ResponseEntity<Category>(categoryObj,HttpStatus.OK);
		}catch(Exception e) {
			throw new Exception(e.getMessage());
		}
		//return null;
		
	}
	
	@GetMapping("/categories")
	public ResponseEntity<List<Category>> getAllCategories(){

		List<Category> categoryList=categoryService.getAllCategories();
		return new ResponseEntity<List<Category>>(categoryList,HttpStatus.OK);
		
	}

}



