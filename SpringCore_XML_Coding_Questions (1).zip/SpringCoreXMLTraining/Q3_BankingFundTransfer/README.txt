Implement a Fund Transfer system using Spring Core XML config. TransactionService should debit and credit accounts accordingly.

Input:
transactionService.transfer("ACC001", "ACC002", 5000);

Output:
"Transfer successful" or "Insufficient balance"

Implement:
- Account.java
- AccountRepository.java, AccountRepositoryImpl.java
- TransactionService.java, TransactionServiceImpl.java
- banking-context.xml
- MainApp.java to run test case