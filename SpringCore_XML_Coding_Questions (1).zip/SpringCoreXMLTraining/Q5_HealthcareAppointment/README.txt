Build Appointment Booking in Healthcare system using Spring XML. AppointmentService books only if doctor is available.

Input:
appointmentService.book("DOC101", "2025-04-10")

Output:
"Appointment confirmed" or "Doctor not available"

Implement:
- Doctor.java
- DoctorRepository.java, DoctorRepositoryImpl.java
- AppointmentService.java, AppointmentServiceImpl.java
- healthcare-context.xml
- MainApp.java