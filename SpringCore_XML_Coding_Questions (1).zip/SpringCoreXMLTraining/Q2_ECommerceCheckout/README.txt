Implement a Spring Core (XML-based) E-commerce Checkout system. OrderService checks cart validity and inventory before placing an order.

Input:
OrderService.checkout("CART001")

Output:
"Checkout successful for CART001" or error messages

Implement:
- Order.java
- InventoryService.java
- CartValidator.java
- OrderService.java, OrderServiceImpl.java
- ecommerce-context.xml
- MainApp.java to run