Implement Airline Booking system using Spring XML config. TicketService confirms booking only if seats are available.

Input:
ticketService.confirmBooking("FL123", "USER456")

Output:
"Booking confirmed for USER456 on FL123" or "Flight FL123 is full"

Files:
- Flight.java
- FlightService.java
- TicketService.java, TicketServiceImpl.java
- airline-context.xml
- MainApp.java