Implement a Spring Core (XML-based) Library Management system where a BookService lends books to users by checking stock.

Input:
Book ID: B001
User ID: U123

Output:
"Book B001 lent to user U123" or "Book B001 is not available"

Implement the following:
- Book.java
- BookRepository.java, BookRepositoryImpl.java
- BookService.java, BookServiceImpl.java
- applicationContext.xml
- MainApp.java to test the output