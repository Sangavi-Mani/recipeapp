package com.springwebapp.movie_mgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
