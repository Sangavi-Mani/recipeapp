package com.springwebapp.movie_mgmt.model;

import jakarta.persistence.*;


@Entity
public class CastMember {
	
	@Id
	private Long CastId;
	private String CastName;
	private String castRole;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="MovieId")
	private Movie movie;

	public CastMember() {
		
	}

	public CastMember(Long castId, String castName, String castRole, Movie movie) {
		super();
		CastId = castId;
		CastName = castName;
		this.castRole = castRole;
		this.movie = movie;
	}

	public Long getCastId() {
		return CastId;
	}

	public void setCastId(Long castId) {
		CastId = castId;
	}

	public String getCastName() {
		return CastName;
	}

	public void setCastName(String castName) {
		CastName = castName;
	}

	public String getCastRole() {
		return castRole;
	}

	public void setCastRole(String castRole) {
		this.castRole = castRole;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	@Override
	public String toString() {
	    return "CastMember [CastId=" + CastId + ", CastName=" + CastName + ", castRole=" + castRole + "]";
	    // Avoid calling movie.toString() to prevent recursion
	}

}
