package com.springwebapp.movie_mgmt.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springwebapp.movie_mgmt.model.*;
import com.springwebapp.movie_mgmt.repository.*;

@Service
public class MovieService {
	
    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private GenreRepository genreRepository;

    @Autowired
    private CastMemberRepository castMemberRepository;

	public void AddRecords() {
		// Genre: Action
		Genre g1 = new Genre();
		g1.setGenreId((long) 1);
		g1.setGenreName("Action");

		// Cast Members for Action Movie
		CastMember cm1 = new CastMember();
		cm1.setCastId((long) 1);
		cm1.setCastName("Ryan Reynolds");
		cm1.setCastRole("Hero");

		CastMember cm2 = new CastMember();
		cm2.setCastId((long) 2);
		cm2.setCastName("Hugh Jack");
		cm2.setCastRole("Hero");

		// Action Movie
		Movie m1 = new Movie();
		m1.setMovieTitle("DeadPool");
		m1.setDescription("Revenge of Deadpool");
		m1.setDuration(119);
		m1.setReleaseYear(2024);
		m1.setGenre(g1);
		m1.setCastList(new ArrayList<>(Arrays.asList(cm1, cm2)));

		// Linking Action Movie
		g1.setMovieList(new ArrayList<>(Arrays.asList(m1)));
		cm1.setMovie(m1);
		cm2.setMovie(m1);

		// Genre: Sci-Fi
		Genre g2 = new Genre();
		g2.setGenreId((long) 2);
		g2.setGenreName("Sci-Fi");

		// Cast Members for Sci-Fi Movie
		CastMember cm3 = new CastMember();
		cm3.setCastId((long) 3);
		cm3.setCastName("Chris Hemsworth");
		cm3.setCastRole("Hero");

		CastMember cm4 = new CastMember();
		cm4.setCastId((long) 4);
		cm4.setCastName("Natalie Portman");
		cm4.setCastRole("Heroine");

		// Sci-Fi Movie
		Movie m2 = new Movie();
		m2.setMovieTitle("Thor: Galactic Wars");
		m2.setDescription("Thor takes on cosmic forces to save the universe.");
		m2.setDuration(145);
		m2.setReleaseYear(2025);
		m2.setGenre(g2);
		m2.setCastList(new ArrayList<>(Arrays.asList(cm3, cm4)));

		// Linking Sci-Fi Movie
		g2.setMovieList(new ArrayList<>(Arrays.asList(m2)));
		cm3.setMovie(m2);
		cm4.setMovie(m2);

		// Genre: Comedy
		Genre g3 = new Genre();
		g3.setGenreId((long) 3);
		g3.setGenreName("Comedy");

		// Cast Members for Comedy Movie 1
		CastMember cm5 = new CastMember();
		cm5.setCastId((long) 5);
		cm5.setCastName("Will Ferrell");
		cm5.setCastRole("Lead");

		CastMember cm6 = new CastMember();
		cm6.setCastId((long) 6);
		cm6.setCastName("Kevin Hart");
		cm6.setCastRole("Supporting");

		// Comedy Movie 1
		Movie m3 = new Movie();
		m3.setMovieTitle("Laugh Riot");
		m3.setDescription("Two unlikely friends team up for the biggest heist of their lives.");
		m3.setDuration(110);
		m3.setReleaseYear(2023);
		m3.setGenre(g3);
		m3.setCastList(new ArrayList<>(Arrays.asList(cm5, cm6)));

		// Cast Members for Comedy Movie 2
		CastMember cm9 = new CastMember();
		cm9.setCastId((long) 9);
		cm9.setCastName("Jim Carrey");
		cm9.setCastRole("Lead Actor");

		CastMember cm10 = new CastMember();
		cm10.setCastId((long) 10);
		cm10.setCastName("Emma Stone");
		cm10.setCastRole("Supporting Actress");

		CastMember cm11 = new CastMember();
		cm11.setCastId((long) 11);
		cm11.setCastName("Steve Carell");
		cm11.setCastRole("Comedian");

		// Comedy Movie 2
		Movie m5 = new Movie();
		m5.setMovieTitle("Laugh Out Loud");
		m5.setDescription("A hilarious tale of a mismatched team trying to break a world record.");
		m5.setDuration(112);
		m5.setReleaseYear(2023);
		m5.setGenre(g3);
		m5.setCastList(new ArrayList<>(Arrays.asList(cm9, cm10, cm11)));

		// Linking Comedy Movies
		g3.setMovieList(new ArrayList<>(Arrays.asList(m3, m5)));
		cm5.setMovie(m3);
		cm6.setMovie(m3);
		cm9.setMovie(m5);
		cm10.setMovie(m5);
		cm11.setMovie(m5);

		// Persisting All at Once
		movieRepository.save(m1);
		movieRepository.save(m2);
		movieRepository.save(m3);
		movieRepository.save(m5);

	}

	public Movie getMovieById(long MovieId) {
		// Fetching a single Movie entity using native SQL
		Movie movie = movieRepository.findById(MovieId).get();

		System.out.println("Movie details: ");
		System.out.println("Name: " + movie.getMovieTitle());
		System.out.println("Year: " + movie.getReleaseYear());
		System.out.println("Genre: " + movie.getGenre().getGenreName());
		System.out.println("Description: " + movie.getDescription());
		System.out.println("Cast: " + movie.getCastList().toString());
		System.out.println("Duration: " + movie.getDuration());
		
		return movie;

		// System.out.println(movie.toString());
	}
	
	/*
	 * public void updateMovieGenre(long movieId, long newGenreId, EntityManager em)
	 * { em.getTransaction().begin(); // Start the transaction
	 * 
	 * // Fetch the Movie and the new Genre from the database Movie movie =
	 * em.find(Movie.class, movieId); Genre newGenre = em.find(Genre.class,
	 * newGenreId);
	 * 
	 * // Ensure both entities exist if (movie == null || newGenre == null) {
	 * em.getTransaction().rollback(); // Rollback if either entity is missing throw
	 * new IllegalArgumentException("Movie or Genre not found"); }
	 * 
	 * // Update the genre of the movie movie.setGenre(newGenre);
	 * newGenre.getMovieList().add(movie);
	 * 
	 * // Merge the updated movie entity em.merge(movie);
	 * 
	 * em.getTransaction().commit(); // Commit the transaction }
	 */
	public void updateMovieGenre(long movieId, long newGenreId) {
	    Movie movie = movieRepository.findById(movieId).get();
	    Genre newGenre = genreRepository.findById(newGenreId).get();

	    // Optional: Remove the movie from old genre list if bi-directional
	    Genre oldGenre = movie.getGenre();
	    if (oldGenre != null) {
	        oldGenre.getMovieList().remove(movie);
	    }

	    // Update association
	    movie.setGenre(newGenre);

	    // Add to new genre's movie list if not already present
	    if (!newGenre.getMovieList().contains(movie)) {
	        newGenre.getMovieList().add(movie);
	    }

	    
	}


	/*
	 * public void updateMovieCast(long movieId, long castToRemoveId, long
	 * castToAddId, EntityManager em) { em.getTransaction().begin();
	 * 
	 * // Fetch the Movie and Cast Members Movie movie = em.find(Movie.class,
	 * movieId); CastMember castToRemove = em.find(CastMember.class,
	 * castToRemoveId); CastMember castToAdd = em.find(CastMember.class,
	 * castToAddId);
	 * 
	 * // Ensure entities exist if (movie == null || castToRemove == null ||
	 * castToAdd == null) { em.getTransaction().rollback(); throw new
	 * IllegalArgumentException("Movie or CastMembers not found."); }
	 * 
	 * // Remove the old CastMember and add the new CastMember if
	 * (movie.getCastList().contains(castToRemove)) {
	 * movie.getCastList().remove(castToRemove); } // Update the CastMember
	 * references Movie toalter = castToAdd.getMovie();
	 * toalter.getCastList().remove(castToAdd);
	 * 
	 * castToAdd.setMovie(null);
	 * 
	 * if (!movie.getCastList().contains(castToAdd)) {
	 * movie.getCastList().add(castToAdd); }
	 * 
	 * castToRemove.setMovie(null); castToAdd.setMovie(movie);
	 * 
	 * // Merge the Movie entity (Hibernate will handle the join table updates) //
	 * em.merge(movie);
	 * 
	 * em.getTransaction().commit(); }
	 */
	public void updateMovieCast(long movieId, long castToRemoveId, long castToAddId) {
		
	    Movie movie = movieRepository.findById(movieId).get();
	    CastMember castToRemove = castMemberRepository.findById(castToRemoveId).get();
	    CastMember castToAdd = castMemberRepository.findById(castToAddId).get();

	    // Remove the old cast member
	    if (movie.getCastList().contains(castToRemove)) {
	        movie.getCastList().remove(castToRemove);
	        castToRemove.setMovie(null);
	    }

	    // Remove castToAdd from its current movie (if any)
	    Movie previousMovie = castToAdd.getMovie();
	    if (previousMovie != null) {
	        previousMovie.getCastList().remove(castToAdd);
	    }

	    // Set the new association
	    castToAdd.setMovie(movie);
	    if (!movie.getCastList().contains(castToAdd)) {
	        movie.getCastList().add(castToAdd);
	    }

	}

	public List<Movie> getMoviesByGenre(String genreName) {
	    // Find the Genre entity by name using the repository
	    Genre genre = genreRepository.findByGenreName(genreName).orElse(null);

	    if (genre == null) {
	        System.out.println("Genre not found");
	        return new ArrayList<>(); // Return an empty list if the genre doesn't exist
	    }

	    // Fetch the movies associated with the genre
	    List<Movie> movies = genre.getMovieList(); // Assuming `getMovieList()` exists in Genre entity

	    // Extract and return the movie titles
	    return movies;
	}
	
	
	public List<Movie> getAllMovies(){
		List<Movie> movies = movieRepository.findAll();
		return movies;
		
	}


}

