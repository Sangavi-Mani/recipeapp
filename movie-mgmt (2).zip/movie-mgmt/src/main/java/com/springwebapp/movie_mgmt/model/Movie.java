package com.springwebapp.movie_mgmt.model;


import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
public class Movie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long MovieId;
	private String MovieTitle;
	private String description;
	private int duration;
	private int releaseYear;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "genreId")
	private Genre genre;

	
	@OneToMany(cascade = CascadeType.ALL)
	private List<CastMember> castList = new ArrayList<>();

	public Movie() {
		
	}

	public Movie(Long movieId, String movieTitle, String description, int duration, int releaseYear, Genre genre,
			List<CastMember> castList) {
		super();
		MovieId = movieId;
		MovieTitle = movieTitle;
		this.description = description;
		this.duration = duration;
		this.releaseYear = releaseYear;
		this.genre = genre;
		this.castList = castList;
	}
	
	

	public Long getMovieId() {
		return MovieId;
	}

	public void setMovieId(Long movieId) {
		MovieId = movieId;
	}

	public String getMovieTitle() {
		return MovieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		MovieTitle = movieTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	public List<CastMember> getCastList() {
		return castList;
	}

	public void setCastList(List<CastMember> castList) {
		this.castList = castList;
	}

	@Override
	public String toString() {
	    return "Movie [MovieId=" + MovieId + ", MovieTitle=" + MovieTitle + ", description=" + description
	            + ", duration=" + duration + ", releaseYear=" + releaseYear
	            + ", genre=" + (genre != null ? genre.getGenreName() : "null")
	            + ", castList=" + castList + "]";
	    // Avoid calling genre.toString() to prevent recursion
	}

}
