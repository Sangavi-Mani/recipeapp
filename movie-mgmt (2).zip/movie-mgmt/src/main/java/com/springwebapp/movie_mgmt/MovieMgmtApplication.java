package com.springwebapp.movie_mgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieMgmtApplication.class, args);
	}

}
