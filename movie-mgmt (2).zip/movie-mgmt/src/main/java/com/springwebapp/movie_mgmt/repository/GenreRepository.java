package com.springwebapp.movie_mgmt.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.springwebapp.movie_mgmt.model.Genre;

@Repository
public interface GenreRepository extends JpaRepository<Genre, Long> {

	Optional<Genre> findByGenreName(String genreName);
    // You can add custom query methods here, if needed
}
