package com.springwebapp.movie_mgmt.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
public class Genre {
	
	@Id
	private Long genreId;
	private String genreName;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Movie> movieList = new ArrayList<>();


	public Genre() {
		
	}

	public Genre(Long genreId, String genreName, List<Movie> movieList) {
		super();
		this.genreId = genreId;
		this.genreName = genreName;
		this.movieList = movieList;
	}

	public Long getGenreId() {
		return genreId;
	}

	public void setGenreId(Long genreId) {
		this.genreId = genreId;
	}

	public String getGenreName() {
		return genreName;
	}

	public void setGenreName(String genreName) {
		this.genreName = genreName;
	}

	public List<Movie> getMovieList() {
		return movieList;
	}

	public void setMovieList(List<Movie> movieList) {
		this.movieList = movieList;
	}

	@Override
	public String toString() {
	    return "Genre [genreId=" + genreId + ", genreName=" + genreName + "]";
	    // Avoid printing the movieList to prevent recursion
	}

	
}
