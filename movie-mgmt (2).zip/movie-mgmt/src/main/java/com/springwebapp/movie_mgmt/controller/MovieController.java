package com.springwebapp.movie_mgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.springwebapp.movie_mgmt.service.MovieService;
import com.springwebapp.movie_mgmt.model.*;

@Controller
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieService movieService;

    // Add default records to the database
    
    @GetMapping
    public String landingPage() {
        return "movies/home"; // Points to the home.html file for the landing page
    }

    
    @GetMapping("/addRecords")
    public String addRecords() {
        movieService.AddRecords();
        return "movies/addRecords"; // Redirect to the movie list page
    }
    
    @GetMapping("/showlist")
    public String showmovies(Model model) {
        List<Movie> movlist1= movieService.getAllMovies();
        model.addAttribute("movieslist", movlist1);
        return "movies/list"; // Redirect to the movie list page
    }
    
    // Get movies by genre
    @GetMapping("/byGenre")
    public String getMoviesByGenre(@RequestParam("genreName") String genreName, Model model) {
        List<Movie> movlist = movieService.getMoviesByGenre(genreName);
        model.addAttribute("movieslist", movlist); // Pass genre name to the view
        return "movies/genre"; // Points to genre.html
    }
    

    // Get a movie by its ID
    @GetMapping("/raghav")
    public String getMovieById(@RequestParam("movieID") Long movieID, Model model) {
    	System.out.println("inside getmoviesbyid");
    	
        Movie movie = movieService.getMovieById(movieID); // Call service to fetch movie details
        
       // model.addAttribute("allmoviedeets", movie.toString());
        
        model.addAttribute("movieId", movie.getMovieId());
        model.addAttribute("movieName", movie.getMovieTitle());
        model.addAttribute("movieYear", movie.getReleaseYear()); 
        model.addAttribute("movieGenre", movie.getGenre().getGenreName());
        model.addAttribute("movieDes", movie.getDescription());
        model.addAttribute("movieCast", movie.getCastList()); // Pass the ID to display movie details
        return "movies/details"; // Points to details.html for movie details
    }
    
    @GetMapping("/addnew")
    public String addNewMovies(Model model) {
        List<Movie> movlist1= movieService.getAllMovies();
        model.addAttribute("movieslist", movlist1);
        return "movies/list"; // Redirect to the movie list page
    }



}
