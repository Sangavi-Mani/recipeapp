package day7.streams;

import java.time.LocalDate;
import java.time.chrono.IsoChronology;

public class User {

    public String name;
    private LocalDate dateOfBirth;

    public User(String name, LocalDate dateOfBirth) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    
    //business logic method
    public long getAge() {
    	
    	// 2022 - 1979 = 43 - 1st user
    	//2025 - 1979 = 46 - 1st user
    	//return 2025 - this.getAge();
        return (long)dateOfBirth.until(IsoChronology.INSTANCE.dateNow()).getYears();
    }

    @Override
    public String toString() {

        StringBuilder builder = new StringBuilder();
        builder.append("User{name=").append(name).append(", dateOfBirth=")
                .append(dateOfBirth).append("}");

        return builder.toString();
    }
}
