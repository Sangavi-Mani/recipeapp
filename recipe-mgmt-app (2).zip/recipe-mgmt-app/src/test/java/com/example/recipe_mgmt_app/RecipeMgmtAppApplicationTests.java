package com.example.recipe_mgmt_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeMgmtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
