package com.example.recipe_mgmt_app.model;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name ="categories")
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; 
	private String name;
	
	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
	private List <Recipe> receipes;

	public Category() {
//		super();
	}

	public Category(String name) {
//		super();
//		this.id = id;
		this.name = name;
//		this.receipe = receipe;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Recipe> getReceipes() {
        return receipes;
    }

    public void setReceipes(List<Recipe> receipes) {
        this.receipes = receipes;
    }

	
	
	
}
