package com.example.recipe_mgmt_app.model;

import java.util.List;

import jakarta.persistence.*;
@Entity
@Table(name ="receipes")

public class Recipe {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String name; 
	private String description;
	private int cookingTime;
	
	public Recipe() {}
	@OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Ingredient> ingredients;

	
	@ManyToOne
	@JoinColumn(name ="category_id")
	private Category category;

	public Recipe(String name, String description, int cookingTime, Category category) {
//		super();
		this.name = name;
		this.description = description;
		this.cookingTime = cookingTime;
		this.category = category;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public int getCookingTime() {
		return cookingTime;
	}
	
	public List<Ingredient> getIngredients() {
	        return ingredients;
	}

	

	public Category getCategory() {
		return category;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setCookingTime(int cookingTime) {
		this.cookingTime = cookingTime;
	}

	public void setIngredients(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

	public void setCategory(Category category) {
		this.category = category;
	}
}
