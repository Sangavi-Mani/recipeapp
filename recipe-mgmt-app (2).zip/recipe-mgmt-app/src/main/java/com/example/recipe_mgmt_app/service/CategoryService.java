package com.example.recipe_mgmt_app.service;

import com.example.recipe_mgmt_app.model.Category;
import com.example.recipe_mgmt_app.repository.CategoryRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CategoryService {
	@Autowired
	private CategoryRepository categoryRepository;
	
	public CategoryService(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
	}
	
	public Category saveCategory(Category category) {
		return categoryRepository.save(category);
	}
	
	public Category getCategoryById(Long categoryId) {
		Optional<Category> category = categoryRepository.findById(categoryId);
		return category.orElse(null);
	}
	
	public List<Category> getAllCategories(){
		return categoryRepository.findAll();
	}
	
	public void updateCategory(Category category) {
        categoryRepository.save(category);
    }
	
	public void deleteCategory(Long categoryId) {
		categoryRepository.deleteById(categoryId);
	}
	
}
