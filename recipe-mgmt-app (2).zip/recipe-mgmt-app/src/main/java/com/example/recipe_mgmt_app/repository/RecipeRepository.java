package com.example.recipe_mgmt_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.recipe_mgmt_app.model.Recipe;

import java.util.List;

public interface RecipeRepository extends JpaRepository<Recipe, Long>{
	public List<Recipe> findByCategoryId(Long categoryId);
	
	List<Recipe> findByNameContainingIgnoreCase(String name);
	
	
}
