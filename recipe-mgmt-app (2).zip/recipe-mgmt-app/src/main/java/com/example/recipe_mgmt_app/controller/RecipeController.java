package com.example.recipe_mgmt_app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.recipe_mgmt_app.model.Category;
import com.example.recipe_mgmt_app.model.Recipe;
import com.example.recipe_mgmt_app.service.CategoryService;
import com.example.recipe_mgmt_app.service.RecipeService;

@Controller
@RequestMapping("/recipes")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @Autowired
    private CategoryService categoryService;

    // 🟢 GET All Recipes
    @GetMapping
    public String listRecipes(Model model) {
        model.addAttribute("recipes", recipeService.getAllRecipes());
        return "recipes";
    }

    // 🟢 GET Recipe by ID
    @GetMapping("/details/{id}")
    public String recipeDetails(@PathVariable Long id, Model model) {
        Recipe recipe = recipeService.getRecipeById(id);
        if (recipe == null) {
            throw new IllegalArgumentException("Recipe not found");
        }
        model.addAttribute("recipe", recipe);
        return "recipeDetails";  // This must match the template name exactly!
    }


    // 🟢 GET Recipes by Category
    @GetMapping("/category/{categoryId}")
    public String getRecipesByCategory(@PathVariable Long categoryId, Model model) {
        model.addAttribute("recipes", recipeService.getRecipesByCategory(categoryId));
        return "recipes";
    }

    // 🟢 CREATE Recipe (Show Form)
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("recipe", new Recipe());
        
        // Ensure categories are fetched and added to the model
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);

        return "addRecipe";
    }


    // 🟢 CREATE Recipe (Submit Form)
    @PostMapping("/save")
    public String saveRecipe(@ModelAttribute Recipe recipe, @RequestParam Long categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        if (category == null) {
            throw new IllegalArgumentException("Category must not be null");
        }
        recipe.setCategory(category);
        recipeService.createRecipe(recipe);
        return "redirect:/recipes";
    }

    
    
    @GetMapping("/search")
    public String searchRecipes(@RequestParam("query") String query, Model model) {
        model.addAttribute("recipes", recipeService.searchRecipes(query));
        return "recipes";
    }

    
    
    // 🟢 UPDATE Recipe (Show Edit Form)
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Recipe recipe = recipeService.getRecipeById(id);
        model.addAttribute("recipe", recipe);
        model.addAttribute("categories", categoryService.getAllCategories());
        return "editRecipe";
    }

    // 🟢 UPDATE Recipe (Submit Form)
    @PostMapping("/update/{id}")
    public String updateRecipe(@PathVariable Long id, @ModelAttribute Recipe recipe) {
        recipe.setId(id);
        recipeService.updateRecipe(recipe);
        return "redirect:/recipes";
    }

    // 🔴 DELETE Recipe
    @GetMapping("/delete/{id}")
    public String deleteRecipe(@PathVariable Long id) {
        recipeService.deleteRecipe(id);
        return "redirect:/recipes";
    }
}
