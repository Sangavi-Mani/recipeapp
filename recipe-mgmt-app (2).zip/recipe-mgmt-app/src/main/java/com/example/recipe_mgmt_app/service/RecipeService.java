package com.example.recipe_mgmt_app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.recipe_mgmt_app.model.Recipe;
import com.example.recipe_mgmt_app.repository.CategoryRepository;
import com.example.recipe_mgmt_app.repository.IngredientRepository;
import com.example.recipe_mgmt_app.repository.RecipeRepository;

@Service
@Transactional
public class RecipeService {
	
	@Autowired
	private RecipeRepository recipeRepository;
	@Autowired
	private CategoryRepository categoryRepository;
	@Autowired
	private IngredientRepository ingredientRepository;
	
	public RecipeService(RecipeRepository recipeRepository) {
		this.recipeRepository = recipeRepository;
	}
	
	public Recipe createRecipe(Recipe recipe) {
	    categoryRepository.save(recipe.getCategory()); 

	    Recipe savedRecipe = recipeRepository.save(recipe);

	    if (recipe.getIngredients() != null && !recipe.getIngredients().isEmpty()) {
	        ingredientRepository.saveAll(recipe.getIngredients());
	    }

	    return savedRecipe;
	}


	
	public Recipe getRecipeById(Long recipeId) {
		return recipeRepository.findById(recipeId).orElse(null);
	}
	
	public List<Recipe> getAllRecipes() {
	    return recipeRepository.findAll();
	}
	
	
	public List<Recipe> searchRecipes(String query) {
	    return recipeRepository.findByNameContainingIgnoreCase(query);
	}


	
	public void updateRecipe(Recipe recipe) {
		recipeRepository.save(recipe);
	}
	
	public void deleteRecipe(Long recipeId) {
		recipeRepository.deleteById(recipeId);
	}
	//Derived Method
	public List <Recipe> getRecipesByCategory(Long categoryId){
		return recipeRepository.findByCategoryId(categoryId);
	}
	
	
}
