package com.example.recipe_mgmt_app.service;

import com.example.recipe_mgmt_app.model.Ingredient;
import com.example.recipe_mgmt_app.repository.IngredientRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class IngredientService {
	@Autowired
	private IngredientRepository ingredientRepository;
	
	public IngredientService(IngredientRepository ingredientRepository) {
		this.ingredientRepository = ingredientRepository;
	}
	
	public Ingredient saveIngredient(Ingredient ingredient) {
        return ingredientRepository.save(ingredient);
    }
	
	public List<Ingredient> saveIngredients(List<Ingredient> ingredients) {
        return ingredientRepository.saveAll(ingredients);
    }
	
	public Ingredient getIngredientById(Long id) {
        return ingredientRepository.findById(id).orElse(null);
    }
	
	public List<Ingredient> getAllIngredients() {
        return ingredientRepository.findAll();
    }
	
	public void updateIngredient(Ingredient ingredient) {
        ingredientRepository.save(ingredient);
    }
	
	public void deleteIngredient(Long id) {
        ingredientRepository.deleteById(id);
    }
}
