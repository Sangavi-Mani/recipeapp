package com.example.category_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.category_service.model.Category;
import com.example.category_service.service.CategoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/category")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;
    @Value("${server.port}")
    private String port;

    private static final Logger log = LoggerFactory.getLogger(CategoryController.class);


	@PostMapping
	public ResponseEntity<Category> create(@RequestBody Category category) {
		return ResponseEntity.ok(categoryService.save(category));
	}

	@GetMapping("/{id}")
	public ResponseEntity<Category> getCategory(@PathVariable Long id) {
		log.info("Serving from port: {}", port);

		return ResponseEntity.ok(categoryService.findById(id));
	}
}