package com.example.category_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.category_service.model.Category;
import com.example.category_service.repository.CategoryRepository;
@Service
public class CategoryService {
	
	@Autowired
	CategoryRepository categoryRepository;
	
	// inject the configured port (will be an int)
    @Value("${server.port}")
    private int serverPort;


	public Category save(Category category) {
		// TODO Auto-generated method stub
		return categoryRepository.save(category);
	}

	public Category findById(Long id) {
		// TODO Auto-generated method stub
		System.out.println("I am running on port " + serverPort);
		Category category = categoryRepository.findById(id)
			    .orElseThrow(() -> new RuntimeException("Category not found with ID: " + id));

		return category;
	}

}
