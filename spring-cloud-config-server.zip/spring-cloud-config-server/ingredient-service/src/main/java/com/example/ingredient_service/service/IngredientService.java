package com.example.ingredient_service.service;


import com.example.ingredient_service.model.Ingredient;
import com.example.ingredient_service.repository.IngredientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IngredientService {

    @Autowired
    private IngredientRepository ingredientRepository;

    public Ingredient saveIngredient(Ingredient ingredient) {
        return ingredientRepository.save(ingredient);
    }

    public List<Ingredient> getAllIngredients() {
        return ingredientRepository.findAll();
    }

    public Ingredient getIngredientById(Long id) { 
    	Ingredient ingredient = ingredientRepository.findById(id)        		
        		.orElseThrow(() -> new RuntimeException("Ingredient not found with ID: " + id));
        return ingredient;

    }

    public List<Ingredient> getIngredientsByRecipeId(Long recipeId) {
        return ingredientRepository.findByRecipeId(recipeId);
    }

    public void deleteIngredient(Long id) {
        ingredientRepository.deleteById(id);
    }

    public Ingredient updateIngredient(Long id, Ingredient updated) {
        return ingredientRepository.findById(id).map(existing -> {
            existing.setName(updated.getName());
            existing.setQuantity(updated.getQuantity());
            existing.setRecipeId(updated.getRecipeId());
            return ingredientRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Ingredient not found"));
    }
}


