package model;

public class Engine {
	
	private int engineNo;
	private String engineModelName;
	private int volves;
	private int pistons;
	private float hp;

	public int getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(int engineNo) {
		this.engineNo = engineNo;
	}

	public String getEngineModelName() {
		return engineModelName;
	}

	public void setEngineModelName(String engineModelName) {
		this.engineModelName = engineModelName;
	}

	public int getVolves() {
		return volves;
	}

	public void setVolves(int volves) {
		this.volves = volves;
	}

	public int getPistons() {
		return pistons;
	}

	public void setPistons(int pistons) {
		this.pistons = pistons;
	}

	public float getHp() {
		return hp;
	}

	public void setHp(float hp) {
		this.hp = hp;
	}
	@Override
	public String toString() {
		return "Engine [engineModelName=" + engineModelName + ", engineNo=" + engineNo + ", volves=" + volves
				+ ", pistons=" + pistons + ", hp=" + hp + "]";
	}
}
