package model;

public class Car {

	private int plateNo;
	private String ownerName;
	private String location;
	
	private Engine engine;
	private Tyres tyres;
	
	public Car()
	{
		super();
	}

	public int getPlateNo() {
		return plateNo;
	}

	public void setPlateNo(int plateNo) {
		this.plateNo = plateNo;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public Tyres getTyres() {
		return tyres;
	}

	public void setTyres(Tyres tyres) {
		this.tyres = tyres;
	}
	
	@Override
	public String toString() {
		return "Car [plateNo=" + plateNo + ", ownerName=" + ownerName + ", location="+ location +","
				+ "engine="+ engine +",tyres="+ tyres +"]";
	}
}
