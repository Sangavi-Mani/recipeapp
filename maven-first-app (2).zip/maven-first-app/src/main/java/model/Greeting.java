package model;

public class Greeting {
	
	public Greeting() {
		System.out.println(" Empty cons greeting");
	}
	
	public String helloSpring() {
		
		return "Hello welcome to Spring Framework!";
	}

}
