package model;

public class Tyres {

	private int tyreSize;
	private String brandName;

	public int getTyreSize() {
		return tyreSize;
	}

	public void setTyreSize(int tyreSize) {
		this.tyreSize = tyreSize;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	@Override
	public String toString() {
		return "Tyres [tyreSize=" + tyreSize + ", brandName=" + brandName + "]";
	}
}
