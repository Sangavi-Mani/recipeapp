package main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Greeting;
import model.Mentor;
import model.Patient;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//
		ClassPathXmlApplicationContext context  = new ClassPathXmlApplicationContext("beans.xml");

		
		
		//Greeting greet = new Greeting()
		Greeting greet = (Greeting) context.getBean("greeting");
		System.out.println(greet.helloSpring());
		
		
		//Access patient
		Patient p = (Patient) context.getBean("patient");
		System.out.println(p);
		
		Mentor m = (Mentor) context.getBean("mentor");
		System.out.println(m.getModules());
		
		
	}

}
