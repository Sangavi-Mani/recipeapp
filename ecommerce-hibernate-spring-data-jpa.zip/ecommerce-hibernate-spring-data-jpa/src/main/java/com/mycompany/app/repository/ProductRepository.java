package com.mycompany.app.repository;


import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mycompany.app.model.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	
	// Find by a single property
    List<Product> findByName(String name);
    
    // Find by multiple properties
    List<Product> findByCategoryAndPrice(String category, BigDecimal price);
    
    // Using greater than and less than
    List<Product> findByPriceGreaterThan(BigDecimal price);
    List<Product> findByPriceLessThan(BigDecimal price);
    
    // Or condition
    List<Product> findByCategoryOrName(String category, String name);
    
    // Using Like for pattern matching
    List<Product> findByNameContaining(String substring);
    
    // Order by
    List<Product> findByOrderByPriceAsc();
    
    // Find products with null values
    List<Product> findByCategoryIsNull();
    
    // Check if a product exists
    boolean existsByName(String name);
    
    // Pagination
    Page<Product> findByCategory(String category, Pageable pageable);

}
