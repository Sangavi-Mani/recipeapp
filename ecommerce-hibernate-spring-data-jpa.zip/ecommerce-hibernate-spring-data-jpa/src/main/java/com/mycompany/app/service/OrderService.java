package com.mycompany.app.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.app.model.Order;
import com.mycompany.app.repository.OrderRepository;

@Service
@Transactional
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public void saveOrder(Order order) {
        orderRepository.save(order);
    }

    public void getOrder(Long id) {
        Order order = orderRepository.findById(id).orElse(null);
        System.out.println("Order: " + order);
    }
}
