package com.mycompany.app;

import com.mycompany.app.model.Order;
import com.mycompany.app.model.Product;
import com.mycompany.app.service.OrderService;
import com.mycompany.app.service.ProductService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.math.BigDecimal;

import org.springframework.context.ApplicationContext;


/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
     // Initialize the Spring Context
        ApplicationContext context = new AnnotationConfigApplicationContext(com.mycompany.app.config.HibernateConfig.class);
        
        // Retrieve the beans
        ProductService productService = context.getBean(ProductService.class);
        OrderService orderService = context.getBean(OrderService.class);
 
     // Create Product
        Product product = new Product();
        product.setName("Laptop");
        product.setPrice(new BigDecimal(1000.00));
        productService.saveProduct(product);

        // Create Order for Product
        Order order = new Order();
        order.setCustomerName("John Doe");
        order.setProduct(product);
        orderService.saveOrder(order);

        // Fetch and display the product and order
        productService.getProduct(product.getId());
        orderService.getOrder(order.getId());
        productService.saveProduct(new Product("Laptop", new BigDecimal("1500.00"), "Electronics"));
        productService.saveProduct(new Product("Smartphone", new BigDecimal("800.00"), "Electronics"));
        productService.saveProduct(new Product("Jeans", new BigDecimal("49.99"), "Fashion"));
        productService.saveProduct(new Product("Shoes", new BigDecimal("89.99"), null));


        
        
        System.out.println("\n--- Find by name 'Laptop' ---");
        productService.findByName("Laptop").forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Find by category 'Electronics' and price 800.00 ---");
        productService.findByCategoryAndPrice("Electronics", new BigDecimal("800.00")).forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        
        System.out.println("\n--- Find products with price > 1000 ---");
        productService.findByPriceGreaterThan(new BigDecimal("1000.00")).forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Find products with category OR name 'Fashion' ---");
        productService.findByCategoryOrName("Fashion", "Shoes").forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Find products containing 'top' ---");
        productService.findByNameContaining("top").forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Find all products ordered by price ASC ---");
        productService.findByOrderByPriceAsc().forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Find products with NULL category ---");
        productService.findByCategoryIsNull().forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Does 'Laptop' exist? ---");
        System.out.println(productService.existsByName("Laptop"));
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        System.out.println("\n--- Find paginated products by category 'Electronics' (page 0, size 1) ---");
        productService.findByCategoryPaged("Electronics", 0, 10).forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");


    }
}
