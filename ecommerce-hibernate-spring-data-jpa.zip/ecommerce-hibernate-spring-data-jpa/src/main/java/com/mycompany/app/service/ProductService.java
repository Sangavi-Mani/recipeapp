package com.mycompany.app.service;

import java.math.BigDecimal;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.mycompany.app.model.Product;
import com.mycompany.app.repository.ProductRepository;

@Service
@Transactional
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public void saveProduct(Product product) {
        productRepository.save(product);
    }

    public void getProduct(Long id) {
        Product product = productRepository.findById(id).orElse(null);
        System.out.println("Product: " + product);
    }
 // Derived methods
    public List<Product> findByName(String name) {
        return productRepository.findByName(name);
    }

    public List<Product> findByCategoryAndPrice(String category, BigDecimal price) {
        return productRepository.findByCategoryAndPrice(category, price);
    }

    public List<Product> findByPriceGreaterThan(BigDecimal price) {
        return productRepository.findByPriceGreaterThan(price);
    }

    public List<Product> findByPriceLessThan(BigDecimal price) {
        return productRepository.findByPriceLessThan(price);
    }

    public List<Product> findByCategoryOrName(String category, String name) {
        return productRepository.findByCategoryOrName(category, name);
    }

    public List<Product> findByNameContaining(String substring) {
        return productRepository.findByNameContaining(substring);
    }

    public List<Product> findByOrderByPriceAsc() {
        return productRepository.findByOrderByPriceAsc();
    }

    public List<Product> findByCategoryIsNull() {
        return productRepository.findByCategoryIsNull();
    }

    public boolean existsByName(String name) {
        return productRepository.existsByName(name);
    }

    public Page<Product> findByCategoryPaged(String category, int page, int size) {
        return productRepository.findByCategory(category, PageRequest.of(page, size));
    }
}
