package com.example.StockService.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

public class Product {
	
	@Id
	@GeneratedValue
	private Long  id;
	private String name;
	private int availableItems;
	private int reservedItems;

	public Product() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAvailableItems() {
		return availableItems;
	}

	public void setAvailableItems(int availableItems) {
		this.availableItems = availableItems;
	}

	public int getReservedItems() {
		return reservedItems;
	}

	public void setReservedItems(int reservedItems) {
		this.reservedItems = reservedItems;
	}
	
	
}

