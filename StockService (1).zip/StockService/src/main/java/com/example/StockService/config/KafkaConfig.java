/*
 * package com.example.StockService.config;
 * 
 * //Importing required classes
 * 
 * import java.util.HashMap; import java.util.Map;
 * 
 * import org.apache.kafka.clients.admin.NewTopic; import
 * org.apache.kafka.clients.consumer.ConsumerConfig; import
 * org.apache.kafka.common.serialization.StringDeserializer; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.kafka.annotation.EnableKafka; import
 * org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
 * import org.springframework.kafka.config.TopicBuilder; import
 * org.springframework.kafka.core.ConsumerFactory; import
 * org.springframework.kafka.core.DefaultKafkaConsumerFactory; import
 * org.springframework.kafka.support.serializer.JsonDeserializer;
 * 
 * import com.example.StockService.model.Customer; import
 * com.example.StockService.model.Order;
 * 
 * //Annotation
 * 
 * @EnableKafka
 * 
 * @Configuration
 * 
 * //Class public class KafkaConfig {
 * 
 * @Bean public NewTopic newTopic() { NewTopic ordersTopic =
 * TopicBuilder.name("stock-orders").build();
 * 
 * return ordersTopic;
 * 
 * }
 * 
 * 
 * @Bean public ConsumerFactory<String, Order> consumerFactory() {
 * 
 * // Creating a map of string-object type Map<String, Object> config = new
 * HashMap<>();
 * 
 * // Adding the Configuration
 * config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
 * config.put(ConsumerConfig.GROUP_ID_CONFIG, "my-group");
 * config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
 * StringDeserializer.class);
 * config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
 * JsonDeserializer.class);
 * 
 * // Returning message in JSON format return new
 * DefaultKafkaConsumerFactory<>(config, new StringDeserializer(), new
 * JsonDeserializer<>(Order.class)); }
 * 
 * // Creating a Listener
 * 
 * @Bean public ConcurrentKafkaListenerContainerFactory<String, Order>
 * orderListener() { ConcurrentKafkaListenerContainerFactory<String, Order>
 * factory = new ConcurrentKafkaListenerContainerFactory<>();
 * factory.setConsumerFactory(consumerFactory());
 * 
 * return factory; }
 * 
 * 
 * @Bean public ConsumerFactory<String, Customer> consumerCustomerFactory() {
 * 
 * // Creating a map of string-object type Map<String, Object> config = new
 * HashMap<>();
 * 
 * // Adding the Configuration
 * config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
 * config.put(ConsumerConfig.GROUP_ID_CONFIG, "my-group");
 * config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
 * StringDeserializer.class);
 * config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
 * JsonDeserializer.class);
 * 
 * // Returning message in JSON format return new
 * DefaultKafkaConsumerFactory<>(config, new StringDeserializer(), new
 * JsonDeserializer<>(Customer.class)); }
 * 
 * // Creating a Listener
 * 
 * @Bean public ConcurrentKafkaListenerContainerFactory<String, Customer>
 * customerListener() { ConcurrentKafkaListenerContainerFactory<String,
 * Customer> factory = new ConcurrentKafkaListenerContainerFactory<>();
 * factory.setConsumerFactory(consumerCustomerFactory());
 * 
 * return factory; }
 * 
 * }
 */