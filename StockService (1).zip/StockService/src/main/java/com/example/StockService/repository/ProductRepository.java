package com.example.StockService.repository;



import org.springframework.data.repository.CrudRepository;

import com.example.StockService.model.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {

}
