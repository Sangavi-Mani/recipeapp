package com.example.StockService.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.StockService.model.Product;
import com.example.StockService.service.StockService;

import java.util.List;

@RestController
@RequestMapping("/stocks")
@CrossOrigin("*")
public class StockController {
    
    @Autowired
    private StockService service;

    // ✅ Create
    @PostMapping("/save")
    public Product save(@RequestBody Product product) {
        return service.saveProduct(product);
    }

    // ✅ Get all products
    @GetMapping("/all")
    public List<Product> getAllProducts() {
        return service.getAllProducts();
    }

    // ✅ Get product by ID
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id) {
        return service.getProductById(id);
    }

    // ✅ Update product
    @PutMapping("/update/{id}")
    public Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        return service.updateProduct(id, updatedProduct);
    }

    // ✅ Delete product
    @DeleteMapping("/delete/{id}")
    public void deleteProduct(@PathVariable Long id) {
        service.deleteProduct(id);
    }
}
