package com.example.StockService.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;*/
import org.springframework.stereotype.Component;

import com.example.StockService.model.Customer;
import com.example.StockService.model.Order;
import com.example.StockService.model.Product;
import com.example.StockService.repository.ProductRepository;

//Annotation 
@Component

//Class 
public class StockService {

	//@Autowired
	//private KafkaTemplate<Long, Order> template;

	@Autowired
	private ProductRepository productRepository;

	//@KafkaListener(topics = "orders-batch5", groupId = "my-group", containerFactory = "orderListener")
	// Method
	public void consume(Order order) {
		// Print statement
		System.out.println("message = " + order);

		if (order.getStatus().equals("NEW")) {
			System.out.println("order :: " + order);
			Optional<Product> product = productRepository.findById(order.getProductId());
			if (product.isPresent()) {
				Product resultProduct = product.get();
				if (order.getProductCount() < resultProduct.getAvailableItems()) {
					resultProduct.setReservedItems(resultProduct.getReservedItems() + order.getProductCount());
					resultProduct.setAvailableItems(resultProduct.getAvailableItems() - order.getProductCount());
					order.setStatus("ACCEPT");
					productRepository.save(resultProduct);
				} else {
					order.setStatus("REJECT");
				}
			//	template.send("stock-orders", order.getId(), order);
			} else {
				System.out.println("product not available");
			}
		}
	}
	
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}
	
	//@KafkaListener(topics = "stock-orders", groupId = "my-group", containerFactory = "orderListener")
	// Method
	public void consumeStocks(Order order) {
		// Print statement
		System.out.println("message = " + order);
	}
	

	//@KafkaListener(topics = "customers", groupId = "my-group", containerFactory = "customerListener")
	// Method
	public void consumeCustomer(Customer customer) {
		// Print statement
		System.out.println("Customer = " + customer);
	}

	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return (List<Product>) productRepository.findAll();
	}

	public Product getProductById(Long id) {
		// TODO Auto-generated method stub
		return (Product)productRepository.findById(id).get();
	}

	public Product updateProduct(Long id, Product updatedProduct) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteProduct(Long id) {
		// TODO Auto-generated method stub
		
	}
	
	

}
