package com.example.model;

import com.example.exception.SpeedLimitExceededException;

public class Car extends Vehicle {
    private static final double SPEED_LIMIT = 80.0;

    public Car(String vehicleNumber, double speed, String location) {
        super(vehicleNumber, "Car", speed, location);
    }

    @Override
    public void checkSpeedLimit() throws SpeedLimitExceededException {
        if (speed > SPEED_LIMIT) {
            throw new SpeedLimitExceededException(vehicleNumber + " is overspeeding!");
        }
    }
}
