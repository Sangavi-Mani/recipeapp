package com.example.model;

import com.example.exception.SpeedLimitExceededException;

//Base Vehicle Class
public class Vehicle {
 protected String vehicleNumber;
 protected String vehicleType;
 protected double speed;
 protected String location;

 public Vehicle(String vehicleNumber, String vehicleType, double speed, String location) {
     this.vehicleNumber = vehicleNumber;
     this.vehicleType = vehicleType;
     this.speed = speed;
     this.location = location;
 }

 public  void checkSpeedLimit() throws SpeedLimitExceededException{
	 System.out.println(" No Speed Limit");
 }

 public String getLocation() {
     return location;
 }

 public double getSpeed() {
     return speed;
 }

public String getVehicleNumber() {
	return vehicleNumber;
}

public void setVehicleNumber(String vehicleNumber) {
	this.vehicleNumber = vehicleNumber;
}

public String getVehicleType() {
	return vehicleType;
}

public void setVehicleType(String vehicleType) {
	this.vehicleType = vehicleType;
}

public void setSpeed(double speed) {
	this.speed = speed;
}



@Override
public String toString() {
	return "Vehicle [vehicleNumber=" + vehicleNumber + ", vehicleType=" + vehicleType + ", speed=" + speed
			+ ", location=" + location + "]";
}

public void setLocation(String location) {
	this.location = location;
}
 
 
}
