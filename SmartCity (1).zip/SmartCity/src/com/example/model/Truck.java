package com.example.model;

import com.example.exception.SpeedLimitExceededException;

public class Truck extends Vehicle {
    private static final double SPEED_LIMIT = 60.0;

    public Truck(String vehicleNumber, double speed, String location) {
        super(vehicleNumber, "Truck", speed, location);
    }

    @Override
    public void checkSpeedLimit() throws SpeedLimitExceededException {
        if (speed > SPEED_LIMIT) {
            throw new SpeedLimitExceededException(vehicleNumber + " is overspeeding!");
        }
    }
}
