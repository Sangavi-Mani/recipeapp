package com.example.main;

import java.util.Scanner;

import com.example.model.*;
import com.example.service.TrafficManagementSystem;

public class SmartCityTrafficSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TrafficManagementSystem trafficSystem = new TrafficManagementSystem();

        while (true) {
            System.out.println("\nSmart City Traffic Management System");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Process Traffic Data");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter vehicle number: ");
                        String number = scanner.nextLine();
                        System.out.print("Enter vehicle type (Car/Truck): ");
                        String type = scanner.nextLine();
                        System.out.print("Enter speed: ");
                        double speed = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.print("Enter location: ");
                        String location = scanner.nextLine();

                        Vehicle vehicle = type.equalsIgnoreCase("Car") ? new Car(number, speed, location) :
                                         type.equalsIgnoreCase("Truck") ? new Truck(number, speed, location) : null;

                        if (vehicle != null) {
                            trafficSystem.addVehicle(vehicle);
                            System.out.println("Vehicle added successfully.");
                        } else {
                            System.out.println("Invalid vehicle type.");
                        }
                        break;
                    case 2:
                        trafficSystem.processTrafficData();
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
