package com.example.exception;

public class InvalidVehicleDataException extends Exception {
    public InvalidVehicleDataException(String message) {
        super(message);
    }
}
