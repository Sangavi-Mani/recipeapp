package com.example.exception;

public class TrafficDataNotAvailableException extends Exception {
    public TrafficDataNotAvailableException(String message) {
        super(message);
    }
}

