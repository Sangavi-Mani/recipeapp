package com.example.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

import com.example.exception.InvalidVehicleDataException;
import com.example.exception.SpeedLimitExceededException;
import com.example.exception.TrafficDataNotAvailableException;
import com.example.model.*;

//Traffic Management System
public class TrafficManagementSystem {
 private List<Vehicle> activeVehicles = new ArrayList<>();
 private Map<String, Integer> vehicleCountPerZone = new HashMap<>();
 private PriorityQueue<Vehicle> emergencyQueue = new PriorityQueue<>(Comparator.comparingDouble(Vehicle::getSpeed).reversed());

 public void addVehicle(Vehicle vehicle) throws InvalidVehicleDataException {
     if (vehicle.getVehicleNumber() == null || vehicle.getLocation() == null) {
         throw new InvalidVehicleDataException("Invalid vehicle data: " + vehicle.getVehicleNumber());
     }
     activeVehicles.add(vehicle);
     vehicleCountPerZone.put(vehicle.getLocation(), vehicleCountPerZone.getOrDefault(vehicle.getLocation(), 0) + 1);
 }

 public void processTrafficData() throws TrafficDataNotAvailableException {
     if (activeVehicles.isEmpty()) {
         throw new TrafficDataNotAvailableException("No traffic data available!");
     }

     // Identify overspeeding vehicles
     List<Vehicle> overspeedingVehicles = activeVehicles.stream()
             .filter(v -> {
                 try {
                     v.checkSpeedLimit();
                     return false;
                 } catch (SpeedLimitExceededException e) {
                     System.out.println(e.getMessage());
                     return true;
                 }
             })
             .collect(Collectors.toList());

     // Count vehicles per zone
     Map<String, Long> vehicleCount = activeVehicles.stream()
             .collect(Collectors.groupingBy(Vehicle::getLocation, Collectors.counting()));

     // Identify top 3 congested areas
     List<String> topCongestedAreas = vehicleCount.entrySet().stream()
             .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
             .limit(3)
             .map(Map.Entry::getKey)
             .collect(Collectors.toList());

     System.out.println("Overspeeding Vehicles: " + overspeedingVehicles);
     System.out.println("Top Congested Areas: " + topCongestedAreas);
 }
}