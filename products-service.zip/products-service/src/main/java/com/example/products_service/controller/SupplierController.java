package com.example.products_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.products_service.entity.Product;
import com.example.products_service.entity.Supplier;
import com.example.products_service.service.ProductService;
import com.example.products_service.service.SupplierService;

@RestController
@RequestMapping("/product")
@CrossOrigin("*")
public class SupplierController {
	@Autowired
	private SupplierService supplierService;
	
	@PostMapping("/supplier")
	public ResponseEntity <Supplier> createSupplier(@RequestBody Supplier supplier){
		Supplier saved = supplierService.saveSupplier(supplier);
		return ResponseEntity.ok(saved);
	}
	
	@GetMapping("/supplier")
	public ResponseEntity <List<Supplier>> getAllSuppliers(){
		return ResponseEntity.ok(supplierService.getAllSuppliers());
	}
	
	@GetMapping("/supplier/{id}")
	public ResponseEntity<Supplier> getSupplierById(@PathVariable Long id){
		Supplier supplier = supplierService.getSupplier(id);
		return new ResponseEntity<Supplier>(supplier, HttpStatus.OK);
	}
	
	@PutMapping("/supplier/{id}")
	public ResponseEntity<Supplier> updateSupplier(@PathVariable Long id, @RequestBody Supplier updatedSupplier){
		try {
			Supplier supplier = supplierService.updateSupplier(id, updatedSupplier);
		
			return  new ResponseEntity<Supplier>(supplier, HttpStatus.OK);
		}
		catch (RuntimeException ex) {
			return ResponseEntity.notFound().build();
		}	
	}
	@DeleteMapping("/supplier/{id}")
	public ResponseEntity<Void> deleteSupplier(@PathVariable Long id) {
		supplierService.deleteSupplier(id);
		return ResponseEntity.noContent().build();
	}
	
	

}
