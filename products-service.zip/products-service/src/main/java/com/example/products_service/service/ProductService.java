package com.example.products_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.products_service.entity.Product;
import com.example.products_service.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductService {
	@Autowired
	private ProductRepository productRepository;
	
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}
	
	public Product getProduct(Long id) {
		return productRepository.findById(id).orElseThrow(()-> new RuntimeException("Product is not found with " +id));
	}
	
	public List <Product> getAllProducts(){
		return productRepository.findAll();
	}
	public void deleteProduct(Long id) {
		productRepository.deleteById(id);
	}
	
	public Product updateProduct (Long id, Product updatedProduct) {
		Product product = productRepository.findById(id).get();
		product.setName(updatedProduct.getName());
		product.setCategory(updatedProduct.getCategory());
		product.setQuantity(updatedProduct.getQuantity());
		
		return productRepository.save(product);
	}

}
