package com.example.products_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.products_service.entity.Supplier;
import com.example.products_service.repository.SupplierRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class SupplierService {
	@Autowired
	private SupplierRepository supplierRepository;
	
	public Supplier saveSupplier(Supplier supplier) {
		return supplierRepository.save(supplier);
	}
	public Supplier getSupplier(Long id) {
		return supplierRepository.findById(id).get();
	}
	public List <Supplier> getAllSuppliers(){
		return supplierRepository.findAll();
	}
	public void deleteSupplier(Long id) {
		supplierRepository.deleteById(id);
	}
	
	public Supplier updateSupplier (Long id, Supplier updatedSupplier){
		Supplier supplier =  supplierRepository.findById(id).get();
		supplier.setName(updatedSupplier.getName());
		supplier.setContactInfo(updatedSupplier.getContactInfo());
		
		return supplierRepository.save(supplier);
		
		
	}
	

}
