package com.example.model;

public class Electronics extends Product {
    private int warrantyPeriod;
    public Electronics(String id, String name, double price, int qty, int warranty) {
        super(id, name, price, qty);
        this.warrantyPeriod = warranty;
    }
    public double getDiscountedPrice() { return price * 0.90; } // 10% discount
}


