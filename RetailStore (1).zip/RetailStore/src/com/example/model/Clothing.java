package com.example.model;

public class Clothing extends Product {
    private String size;
    public Clothing(String id, String name, double price, int qty, String size) {
        super(id, name, price, qty);
        this.size = size;
    }
    public double getDiscountedPrice() { return price * 0.85; } // 15% discount
}

