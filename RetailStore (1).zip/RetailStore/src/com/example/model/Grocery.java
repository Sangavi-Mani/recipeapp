package com.example.model;

public class Grocery extends Product {
    private String expiryDate;
    public Grocery(String id, String name, double price, int qty, String expiryDate) {
        super(id, name, price, qty);
        this.expiryDate = expiryDate;
    }
    public double getDiscountedPrice() { return price * 0.95; } // 5% discount
}