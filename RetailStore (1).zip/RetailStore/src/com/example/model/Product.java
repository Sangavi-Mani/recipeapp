package com.example.model;

public class Product {
    protected String productId, productName;
    protected double price;
    protected int quantity;

    public Product(String productId, String productName, double price, int quantity) {
        if (price <= 0 || productName.isEmpty()) {
            throw new IllegalArgumentException("Invalid product details");
        }
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }
    
    public  double getDiscountedPrice() {
    	return 10.00;
    }
    public String getProductId() { return productId; }
    public int getQuantity() { return quantity; }
    public void reduceStock(int qty) { quantity -= qty; }
    public void restock(int qty) { quantity += qty; }
    
    @Override
    public String toString() {
        return productName + " | Price: " + price + " | Stock: " + quantity;
    }
}
