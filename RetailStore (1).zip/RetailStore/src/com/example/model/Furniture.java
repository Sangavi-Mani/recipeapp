package com.example.model;

public class Furniture extends Product {
    private String material;
    public Furniture(String id, String name, double price, int qty, String material) {
        super(id, name, price, qty);
        this.material = material;
    }
    public double getDiscountedPrice() { return price * 0.88; } // 12% discount
}
