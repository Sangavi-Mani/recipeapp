package com.example.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

import com.example.exception.OutOfStockException;
import com.example.model.Product;

public class InventoryManagementSystem {
    private List<Product> inventory = new ArrayList<>();
    private Map<String, Integer> stockByCategory = new HashMap<>();
    private PriorityQueue<Product> fastSellingProducts = new PriorityQueue<>(Comparator.comparingInt(Product::getQuantity));
    
    public void addProduct(Product product) {
        inventory.add(product);
        stockByCategory.put(product.getClass().getSimpleName(), stockByCategory.getOrDefault(product.getClass().getSimpleName(), 0) + product.getQuantity());
    }
    
    public void purchaseProduct(String productId, int qty) throws OutOfStockException {
        for (Product product : inventory) {
            if (product.getProductId().equals(productId)) {
                if (product.getQuantity() < qty) {
                    throw new OutOfStockException("Product is out of stock!");
                }
                product.reduceStock(qty);
                fastSellingProducts.add(product);
                return;
            }
        }
        System.out.println("Product not found!");
    }
    
    public void restockProduct(String productId, int qty) {
        for (Product product : inventory) {
            if (product.getProductId().equals(productId)) {
                product.restock(qty);
                return;
            }
        }
        System.out.println("Product not found!");
    }
    
    public void displayLowStockProducts(int threshold) {
        List<Product> lowStockProducts = inventory.stream().filter(p -> p.getQuantity() < threshold).collect(Collectors.toList());
        lowStockProducts.forEach(System.out::println);
    }
    
    public void displayTopSellingProducts() {
        List<Product> topProducts = inventory.stream().sorted(Comparator.comparingInt(Product::getQuantity)).limit(3).collect(Collectors.toList());
        topProducts.forEach(System.out::println);
    }
    
    public void displayAllProducts() {
        inventory.forEach(System.out::println);
    }
}

