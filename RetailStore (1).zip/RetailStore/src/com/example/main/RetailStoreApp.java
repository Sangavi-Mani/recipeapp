package com.example.main;

import java.util.Scanner;

import com.example.exception.OutOfStockException;
import com.example.model.Clothing;
import com.example.model.Electronics;
import com.example.model.Furniture;
import com.example.model.Grocery;
import com.example.service.InventoryManagementSystem;

public class RetailStoreApp {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\n--- Inventory Management Menu ---");
            System.out.println("1. Add Product");
            System.out.println("2. View All Products");
            System.out.println("3. Purchase Product");
            System.out.println("4. Restock Product");
            System.out.println("5. View Low Stock Products");
            System.out.println("6. View Top Selling Products");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Select Product Type: 1. Electronics 2. Grocery 3. Clothing 4. Furniture");
                    int type = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter Product ID: ");
                    String productId = scanner.nextLine();
                    System.out.print("Enter Product Name: ");
                    String productName = scanner.nextLine();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    
                    switch (type) {
                        case 1:
                            System.out.print("Enter Warranty Period (years): ");
                            int warranty = scanner.nextInt();
                            ims.addProduct(new Electronics(productId, productName, price, quantity, warranty));
                            break;
                        case 2:
                            System.out.print("Enter Expiry Date (YYYY-MM-DD): ");
                            scanner.nextLine(); 
                            String expiryDate = scanner.nextLine();
                            ims.addProduct(new Grocery(productId, productName, price, quantity, expiryDate));
                            break;
                        case 3:
                            System.out.print("Enter Size: ");
                            scanner.nextLine(); 
                            String size = scanner.nextLine();
                            ims.addProduct(new Clothing(productId, productName, price, quantity, size));
                            break;
                        case 4:
                            System.out.print("Enter Material: ");
                            scanner.nextLine(); 
                            String material = scanner.nextLine();
                            ims.addProduct(new Furniture(productId, productName, price, quantity, material));
                            break;
                        default:
                            System.out.println("Invalid product type!");
                    }
                    System.out.println("Product added successfully!");
                    break;
                case 2:
                    ims.displayAllProducts();
                    break;
                case 3:
                    System.out.print("Enter Product ID: ");
                    String pid = scanner.next();
                    System.out.print("Enter Quantity: ");
                    int qty = scanner.nextInt();
                    try {
                        ims.purchaseProduct(pid, qty);
                        System.out.println("Purchase successful!");
                    } catch (OutOfStockException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.print("Enter Product ID: ");
                    pid = scanner.next();
                    System.out.print("Enter Quantity to Restock: ");
                    qty = scanner.nextInt();
                    ims.restockProduct(pid, qty);
                    System.out.println("Restocked successfully!");
                    break;
                case 5:
                    ims.displayLowStockProducts(5);
                    break;
                case 6:
                    ims.displayTopSellingProducts();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
