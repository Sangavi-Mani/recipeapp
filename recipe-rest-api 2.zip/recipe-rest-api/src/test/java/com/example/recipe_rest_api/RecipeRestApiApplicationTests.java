package com.example.recipe_rest_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
