export interface Book{
    title: string;
    author: string;
    genre: string;
    status: 'borrowed' | 'available';   
}