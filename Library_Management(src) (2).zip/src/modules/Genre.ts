
enum Genre {
    Action = "Action",
    Comedy = "Comedy",
    Drama = "Drama",
}