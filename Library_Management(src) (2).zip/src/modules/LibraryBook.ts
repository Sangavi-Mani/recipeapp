import { Book } from "./Book";

export class LibraryBook implements Book {
    title!: string;
    author!: string;
    genre!: string;
    status!: 'available';


    publishedYear!: number;
    fileSizeMB!: number;

    constructor(title:string, author:string,genre:string){
        this.title=title;
        this.author=author;
        this.genre=genre;
    }

}