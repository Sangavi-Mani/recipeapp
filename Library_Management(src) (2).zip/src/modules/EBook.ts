import { Book } from "./Book";

export class EBook implements Book {
    title!: string;
    author!: string;
    genre!: string;
    status!: "borrowed";


    publishedYear!: number;
    public fileSizeMB!: number;

    constructor(title:string, author:string, genre:string){
        this.title=title;
        this.author=author;
        this.genre=genre;
    }
}   