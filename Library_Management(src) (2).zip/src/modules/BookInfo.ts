import { Book } from "./Book";

export class BookInfo {

    title!: string;
    author!: string;
    genre!: string;
    status!:string;


    books:Book []=[];

    addBook(b:Book){
        this.books.push(b);
    }
    displayAllBooks(){
        return this.books;
    }
    constructor(title:string, author:string,genre:string){
        this.title=title;
        this.author=author;
        this.genre=genre;
    }
    
}