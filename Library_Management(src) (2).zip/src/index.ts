import { BookInfo } from "./modules/BookInfo";
import { EBook } from "./modules/EBook";
import { LibraryBook } from "./modules/LibraryBook";

const library = new BookInfo('abcd','nisanth','Action');

const libraryBook = new LibraryBook('abcd','nishanth','Action');

const ebook = new EBook('efgh','eniyaval','Drama');


library.addBook(ebook);
library.addBook(libraryBook);

console.log(library.displayAllBooks());