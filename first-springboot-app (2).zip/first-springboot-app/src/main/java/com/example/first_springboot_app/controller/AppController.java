package com.example.first_springboot_app.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppController {
	
	@GetMapping("/")
	public String showHome() {
		return "home";
	}
	@GetMapping("/home")
	public ResponseEntity<String> showDummy(){
		return new ResponseEntity<String>("Hellossadbdsmnbmsdkvxn<br/> sdkldhsd<br>", HttpStatus.OK);
	}
	
	

	
}
