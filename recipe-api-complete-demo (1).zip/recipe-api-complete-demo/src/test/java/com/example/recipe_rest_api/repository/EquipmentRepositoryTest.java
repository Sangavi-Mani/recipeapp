package com.example.recipe_rest_api.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EquipmentRepositoryTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
