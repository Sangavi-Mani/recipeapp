package com.core.banking.service;

import com.core.banking.model.Account;

public class BankService {

    private Account account;

    public void setAccount(Account account) {
        this.account = account;
    }

   //Method to check the account balance
public double checkAccountBalance() {
    // Check if the account is initialized (not null)
}

    public void deposit(double amount) {
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
        } else {
            System.out.println("Account not initialized");
        }
    }


    public boolean withdraw(double amount) {
        if (account != null && account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            return true; // Withdrawal successful
        } else {
            return false; // Insufficient funds or account not initialized
        }
    }
}
