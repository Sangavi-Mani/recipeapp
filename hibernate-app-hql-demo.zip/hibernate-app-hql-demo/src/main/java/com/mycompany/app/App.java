package com.mycompany.app;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mycompany.app.entity.Address;
import com.mycompany.app.entity.Employee;
import com.mycompany.app.util.HibernateUtil;

import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.ParameterExpression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Expression;

/**
 * Hello world!
 *
 */
public class App 
{
	static Session session = HibernateUtil.getSessionFactory().openSession();
    
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        
        //insertEmployeeWithAddress();
       // fetchAllUsingCritera();
       // fetchAllUsingQuery();
        
        
        fetchByIdUsingCriteria(4L, " John");
        fetchByIdUsingQuery(4L, " John");
        
      // sumOfAllSalaryUsingCriteria();
       // sumOfAllSalaryUsingQuery();
        
        
    }

	private static void sumOfAllSalaryUsingQuery() {
		// TODO Auto-generated method stub
		
		Query query = session.createQuery("select sum(salary) from Employee");
		double sumSalary = (Double) query.getSingleResult();
		System.out.println(" Sum Salary "+sumSalary);
		
	}

	private static void sumOfAllSalaryUsingCriteria() {
		// TODO Auto-generated method stub
		
		CriteriaBuilder critBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Employee> crit = critBuilder.createQuery(Employee.class);
		Root<Employee> root = crit.from(Employee.class);
		
		crit.multiselect(critBuilder.sum(root.<Double>get("salary")));
		
		TypedQuery<Employee> typeQuery = session.createQuery(crit);
		Employee sumSalarys = typeQuery.getSingleResult();
		
		System.out.println(" Sum Salary "+sumSalarys.getSalary());
	}

	private static void fetchByIdUsingQuery(long id, String name) {
		// TODO Auto-generated method stub
		List<Employee> empList = session.createQuery("from Employee where id = "+id+" and name = '"+name+ "'").getResultList();
		
		
		for(Employee emp : empList) {
			System.out.println(" Emp Name :"+emp.getName());
		}
		
	}

	private static void fetchByIdUsingCriteria(Long id, String name) {
		// TODO Auto-generated method stub
		
		CriteriaBuilder critBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Employee> crit = critBuilder.createQuery(Employee.class);
		Root<Employee> root = crit.from(Employee.class);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(critBuilder.equal(root.get("id"), id)); //e.id == id
		predicates.add(critBuilder.equal(root.get("name"), name)); //e.name == name
		
		
		crit.select(root).where(predicates.toArray(new Predicate[] {}));//select   * from emp where e.id=:id and e.name=:name
		
		List<Employee> empList = session.createQuery(crit).getResultList(); 
		
		for(Employee emp : empList) {
			System.out.println(" Emp Name :"+emp.getName());
		}
	}

	private static void fetchAllUsingQuery() {
		// TODO Auto-generated method stub
		
		List<Employee> empList = session.createQuery("from Employee order by name").getResultList();
		
		for(Employee emp : empList) {
			System.out.println(" Emp Name :"+emp.getName());
		}
		
	}

	private static void fetchAllUsingCritera() {
		// TODO Auto-generated method stub
		
		CriteriaQuery<Employee> crit = session.getCriteriaBuilder().createQuery(Employee.class);
		Root<Employee> root = crit.from(Employee.class);
		crit.orderBy(session.getCriteriaBuilder().asc(root.get("name")));
		crit.orderBy(session.getCriteriaBuilder().asc(root.get("id")));
		
	
		
		List<Employee> empList = session.createQuery(crit).getResultList();
		
		for(Employee emp : empList) {
			System.out.println(" Emp Name :"+emp.getName());
		}
		
	}

	private static void insertEmployeeWithAddress() {
		// TODO Auto-generated method stub
		//
        Transaction tx = session.beginTransaction();
        Address  addr = new Address();
        addr.setAddress("3th Cross Street");
        addr.setCity("San Jose");
        addr.setId(3L);
        addr.setZipcode("3ZA451");
        
        Employee emp = new Employee();
        emp.setName(" John");
        emp.setId(4L);
        emp.setSalary(500000.00);
        emp.setAddress(addr);
        
        session.save(emp);
        tx.commit();
		
	}
}
