package com.mycompany.app.util;

import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mycompany.app.entity.Address;

import com.mycompany.app.entity.Employee;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {
	
private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory() {
		
		try {
			
			
			//loading the configuration and mapping -> hibernate.properties
			Configuration config = new Configuration();
			
			config.addAnnotatedClass(Employee.class);
			config.addAnnotatedClass(Address.class);
			ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().
					applySettings(config.getProperties()).build();
			
			
			
			//Builds the session factory
			sessionFactory = config.buildSessionFactory(serviceRegistry);
			
			
	
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return sessionFactory;
	}
	
		

}
