package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Booking;
import com.model.Movie;
import com.model.Theater;
import com.repository.BookingRepository;
import com.repository.MovieRepository;
import com.repository.TheaterRepository;

@Service
public class TheaterService {
	
	@Autowired
	TheaterRepository theaterRepository;
	@Autowired
	MovieRepository movieRepository;
	@Autowired
	BookingRepository bookingRepository;
	
public Theater addTheater(Theater theater) {
		
		List<Movie> movies=theater.getMovies();
		for(Movie i:movies) {
			i.getTheaters().add(theater);
			movieRepository.save(i);
		}
		
		return theaterRepository.save(theater);
		
	}
	
	public List<Theater> listAllTheater(){
		
		return theaterRepository.findAll();
	}
	
	public Theater viewTheaterById(Long id) {
		
		return theaterRepository.findById(id).get();
	}
	
	public String deleteTheater(Long id) {
		List<Movie> movies=theaterRepository.findById(id).get().getMovies();
		for(Movie movie:movies) {
			movie.getTheaters().remove(theaterRepository.findById(id).get());
			movieRepository.save(movie);
		}
		for(Booking booking:bookingRepository.findAll()) {
			if(booking.getTheater().getId()==id) {
				booking.setTheater(null);
			}
		}
		theaterRepository.deleteById(id);
		return "Deleted Theater";

	}
	
	public Theater updateTheater(Theater toUpdate,Theater fromUpdate) {
		
		toUpdate.setLocation(fromUpdate.getLocation());
		toUpdate.setName(fromUpdate.getName());
		toUpdate.setMovies(fromUpdate.getMovies());
		
		for(Movie i:toUpdate.getMovies()) {
			i.getTheaters().add(toUpdate);
			
			movieRepository.save(i);
			System.out.println();
		}
		
		return theaterRepository.save(toUpdate);
	}

}
