package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Booking;
import com.model.Customer;
import com.repository.BookingRepository;
import com.repository.CustomerRepository;

@Service
public class BookingService {
	
	
	@Autowired
	BookingRepository bookingRepository;
	@Autowired
	CustomerRepository customerRepository;
	
	
	public Booking addBooking(Booking booking) {
		
		Customer customer =booking.getCustomer();
		customer.getBookings().add(booking);
//		customerRepository.save(customer);
		return bookingRepository.save(booking);
	}
	
	public List<Booking> listAllBooking(){
		
		return bookingRepository.findAll();
	}
	
	public String deleteBooking(Long id) {
		bookingRepository.deleteById(id);
		return "Deleted Booking";
	}
	public Booking viewByIdBooking(Long id) {
		
		return bookingRepository.findById(id).get();
	}
	public Booking updateBooking(Booking toUpdate,Booking fromUpdate) {
		
		toUpdate.setBookingDate(fromUpdate.getBookingDate());
		toUpdate.setCustomer(fromUpdate.getCustomer());
		toUpdate.setMovie(fromUpdate.getMovie());
		toUpdate.setSeats(fromUpdate.getSeats());
		toUpdate.setTheater(fromUpdate.getTheater());
		toUpdate.getCustomer().getBookings().add(toUpdate);
		
		
		return bookingRepository.save(toUpdate);
	}
}
