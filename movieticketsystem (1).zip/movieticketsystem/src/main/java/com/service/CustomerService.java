package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Booking;
import com.model.Customer;
import com.repository.BookingRepository;
import com.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	BookingRepository bookingRepository;
	
	
	public Customer addCustomer(Customer customer) {
		
		/*
		 * for(Booking i:customer.getBookings()) { i.setCustomer(customer); }
		 */
		
		return customerRepository.save(customer);
	}
	
	public List<Customer> viewAllCustomer(){
		
		return customerRepository.findAll();
	}
	
	public Customer getByIdCustomer(Long id) {
		
		return customerRepository.findById(id).get();
	}
	
	public Customer updateCustomer(Customer toUpdate,Customer fromUpdate) {
		
		toUpdate.setEmail(fromUpdate.getEmail());
		toUpdate.setName(fromUpdate.getName());
		toUpdate.setBookings(fromUpdate.getBookings());
		
		for(Booking i:toUpdate.getBookings()) {
			i.setCustomer(toUpdate);
			bookingRepository.save(i);
		}
		
		return customerRepository.save(toUpdate);
	}
	
	public String deleteCustomer(Long id) {
		
		for(Booking booking:bookingRepository.findAll()) {
			if(booking.getCustomer().getId()==id) {
				booking.setCustomer(null);
			}
		}
		customerRepository.deleteById(id);
		return "Deleted Customer";
	}
}
