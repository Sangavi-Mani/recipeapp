package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Booking;
import com.model.Movie;
import com.model.Theater;
import com.repository.BookingRepository;
import com.repository.MovieRepository;
import com.repository.TheaterRepository;

@Service
public class MovieService {
	
	@Autowired
	MovieRepository movieRepository;
	@Autowired
	TheaterRepository theaterRepository;
	@Autowired
	BookingRepository bookingRepository;
	
	public Movie addMovie(Movie movie) {
		
		List<Theater> theaters=movie.getTheaters();
		for(Theater i:theaters) {
			i.getMovies().add(movie);
			theaterRepository.save(i);
		}
		Movie result=movieRepository.save(movie);
		return result;
		
	}
	
	public List<Movie> listAllMovie(){
		
		return movieRepository.findAll();
	}
	
	public Movie viewMovieById(Long id) {
		
		return movieRepository.findById(id).get();
	}
	
	public String deleteMovie(Long id) {
		
		for(Booking booking:bookingRepository.findAll()) {
			if(booking.getMovie().getId()==id) {
				booking.setMovie(null);
			}
		}
		movieRepository.deleteById(id);
		return "Deleted Movie";

	}
	
	public Movie updateMovie(Movie toUpdate,Movie fromUpdate) {
		toUpdate.setTitle(fromUpdate.getTitle());
		toUpdate.setGenre(fromUpdate.getGenre());
		toUpdate.setTheaters(fromUpdate.getTheaters());
		for(Theater i:toUpdate.getTheaters()) {
			i.getMovies().add(toUpdate);
			theaterRepository.save(i);
		}
		return movieRepository.save(toUpdate);
		
	}
}

