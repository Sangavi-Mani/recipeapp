package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Customer;
import com.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/customer/add")
	public ResponseEntity<?> addCustomer(@RequestBody Customer customer){
		
		try {
			return new ResponseEntity<Customer>(customerService.addCustomer(customer),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/customer/viewall")
	public ResponseEntity<?> viewAllCustomer(){
		try {
			return new ResponseEntity<List<Customer>>(customerService.viewAllCustomer(),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/customer/view/{id}")
	public ResponseEntity<?> viewIdCustomer(@PathVariable Long id){
		
		try {
			return new ResponseEntity<Customer>(customerService.getByIdCustomer(id),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@PutMapping("/customer/edit/{id}")
	public ResponseEntity<?> updateCustomer(@PathVariable Long id, @RequestBody Customer customer){
		
		try {
			return new ResponseEntity<Customer>(customerService.updateCustomer(customerService.getByIdCustomer(id), customer),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	@DeleteMapping("/customer/delete/{id}")
	public ResponseEntity<?> deleteCustomer(@PathVariable Long id){
		
		try {
			return new ResponseEntity<String>(customerService.deleteCustomer(id),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}