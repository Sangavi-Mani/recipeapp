package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Theater;
import com.service.TheaterService;

@RestController
public class TheaterController {

	@Autowired
	TheaterService theaterService;
	
	@PostMapping("/theater/add")
	public ResponseEntity<?> addTheater(@RequestBody Theater Theater){
		
		try {
			return new ResponseEntity<Theater>(theaterService.addTheater(Theater),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/theater/viewall")
	public ResponseEntity<?> viewAllTheater(){
		try {
			return new ResponseEntity<List<Theater>>(theaterService.listAllTheater(),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/theater/get/{id}")
	public ResponseEntity<?> getTheater(@PathVariable Long id){
		
		try {
			return new ResponseEntity<Theater>(theaterService.viewTheaterById(id),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@DeleteMapping("/theater/delete/{id}")
	public ResponseEntity<?> deleteTheater(@PathVariable Long id){
		
		try {
			return new ResponseEntity<String>(theaterService.deleteTheater(id),HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@PutMapping("/theater/update/{id}")
	public ResponseEntity<?> updateTheater(@PathVariable Long id,@RequestBody Theater theatre){
		
		try {
			return new ResponseEntity<Theater>(theaterService.updateTheater(theaterService.viewTheaterById(id), theatre),HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
}
