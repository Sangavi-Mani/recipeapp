package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Booking;
import com.service.BookingService;

@RestController
public class BookingController {
	
	@Autowired
	BookingService bookingService;
	
	
	@PostMapping("/booking/add")
	public ResponseEntity<?> addbooking(@RequestBody Booking booking){
		
		try {
			return new ResponseEntity<Booking>(bookingService.addBooking(booking),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/booking/viewall")
	public ResponseEntity<?> viewAllbooking(){
		try {
			return new ResponseEntity<List<Booking>>(bookingService.listAllBooking(),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/booking/get/{id}")
	public ResponseEntity<?> getbooking(@PathVariable Long id){
		
		try {
			return new ResponseEntity<Booking>(bookingService.viewByIdBooking(id),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@DeleteMapping("/booking/delete/{id}")
	public ResponseEntity<?> deletebooking(@PathVariable Long id){
		
		try {
			return new ResponseEntity<String>(bookingService.deleteBooking(id),HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@PutMapping("/booking/update/{id}")
	public ResponseEntity<?> updatebooking(@PathVariable Long id,@RequestBody Booking booking){
		
		try {
			return new ResponseEntity<Booking>(bookingService.updateBooking(bookingService.viewByIdBooking(id), booking),HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
