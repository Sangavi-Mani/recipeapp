package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Movie;
import com.service.MovieService;

@RestController
public class MovieController {
	
	@Autowired
	MovieService movieService;
	
	@PostMapping("/movie/add")
	public ResponseEntity<?> addMovie(@RequestBody Movie movie){
		
		try {
			return new ResponseEntity<Movie>(movieService.addMovie(movie),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/movie/viewall")
	public ResponseEntity<?> viewAllMovie(){
		try {
			return new ResponseEntity<List<Movie>>(movieService.listAllMovie(),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping("/movie/get/{id}")
	public ResponseEntity<?> getMovie(@PathVariable Long id){
		
		try {
			return new ResponseEntity<Movie>(movieService.viewMovieById(id),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@DeleteMapping("/movie/delete/{id}")
	public ResponseEntity<?> deleteMovie(@PathVariable Long id){
		
		try {
			return new ResponseEntity<String>(movieService.deleteMovie(id),HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@PutMapping("/movie/edit/{id}")
	public ResponseEntity<?> updateMovie(@PathVariable Long id, @RequestBody Movie movie){
		
		try {
			return new ResponseEntity<Movie>(movieService.updateMovie(movieService.viewMovieById(id), movie),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
