package com.ecommerce.recipe_rest_api.controller;

import com.ecommerce.recipe_rest_api.model.RecipeDTO;
import com.ecommerce.recipe_rest_api.model.IngredientDTO;
import com.ecommerce.recipe_rest_api.model.Category;
import com.ecommerce.recipe_rest_api.model.CategoryDTO;
import com.ecommerce.recipe_rest_api.model.Ingredient;
import com.ecommerce.recipe_rest_api.model.Recipe;
import com.ecommerce.recipe_rest_api.service.CategoryService;
import com.ecommerce.recipe_rest_api.service.RecipeService;
import com.ecommerce.recipe_rest_api.exception.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
// Base path for clarity
public class RecipeController {

    private final RecipeService recipeService;
    
    @Autowired
    private CategoryService categoryService;
    

    public RecipeController(RecipeService recipeService) {
        this.recipeService = recipeService;
    }

    private CategoryDTO toCategoryDTO(Category c) {
        CategoryDTO dto = new CategoryDTO();
        dto.setId(c.getId());
        dto.setName(c.getName());
        return dto;
        }

    // -- Utility mapping methods --
    private RecipeDTO toDTO(Recipe r) {
        RecipeDTO dto = new RecipeDTO();
        dto.setId(r.getId());
        dto.setName(r.getName());
        dto.setDescription(r.getDescription());
        dto.setTime(r.getTime());

        dto.setIngredients(r.getIngredients().stream().map(i -> {
            IngredientDTO idto = new IngredientDTO();
            idto.setId(i.getId());
            idto.setName(i.getName());
            idto.setQuantity(i.getQuantity());
            return idto;
        }).collect(Collectors.toList()));

        return dto;
    }
    private Category fromCategoryDTO(CategoryDTO dto) {
    	Category c = new Category();
        c.setName(dto.getName());
       // r.setDescription(dto.getDescription());
        return c;
    }
    private Recipe fromDTO(RecipeDTO dto) {
        Recipe r = new Recipe();
        r.setName(dto.getName());
        r.setDescription(dto.getDescription());
        r.setTime(dto.getTime());

        if (dto.getCategory() != null) {
            r.setCategory(new Category(dto.getCategory().getId(), dto.getCategory().getName()));
        }

        if (dto.getIngredients() != null) {
            dto.getIngredients().forEach(idto -> {
                Ingredient ing = new Ingredient();
                ing.setName(idto.getName());
                ing.setQuantity(idto.getQuantity());
                r.addIngredient(ing);
            });
        }

        return r;
    }
    /** Create a new Category */
    @PostMapping(value = "/category/save", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CategoryDTO> saveCategory(@RequestBody CategoryDTO categoryDTO) {
        Category saved = categoryService.saveCategory(fromCategoryDTO(categoryDTO));
        return ResponseEntity.ok(toCategoryDTO(saved));
    }

    
    /** Create a new Recipe */
    @PostMapping(value = "/recipes/save", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RecipeDTO> saveRecipe(@RequestBody RecipeDTO recipeDTO) {
        Recipe saved = recipeService.saveRecipe(fromDTO(recipeDTO));
        return ResponseEntity.ok(toDTO(saved));
    }

    /** Get a Recipe by ID */
    @GetMapping("/recipes/{id}")
    public ResponseEntity<RecipeDTO> getRecipeById(@PathVariable Long id) {
        Optional<Recipe> recipeOpt = recipeService.getRecipeById(id);

        if (recipeOpt.isEmpty()) {
            throw new ResourceNotFoundException("Recipe not found with id " + id);
        }

        return ResponseEntity.ok(toDTO(recipeOpt.get()));
    }

    /** Update an existing Recipe */
    @PutMapping(value = "/recipes/update/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RecipeDTO> updateRecipe(@PathVariable Long id, @RequestBody RecipeDTO recipeDTO) {
        Optional<Recipe> existingRecipeOpt = recipeService.getRecipeById(id);

        if (existingRecipeOpt.isEmpty()) {
            throw new ResourceNotFoundException("Recipe not found with id " + id);
        }

        Recipe toSave = recipeDTO.toEntity();
        toSave.setId(id);
        Recipe updated = recipeService.saveRecipe(toSave);

        RecipeDTO updatedDTO = RecipeDTO.map(updated);
        return ResponseEntity.ok(updatedDTO);
    }

    /** Delete a Recipe by ID */
    @DeleteMapping("/recipes/delete/{id}")
    public ResponseEntity<String> deleteRecipe(@PathVariable Long id) {
		/*
		 * recipeService.getRecipeById(id) .orElseThrow(() -> new
		 * ResourceNotFoundException("Recipe not found with id " + id));
		 */  
    	recipeService.getRecipe(id);
    	recipeService.deleteRecipe(id);
        return ResponseEntity.ok("Recipe "+id+" Deleted Sucessfuly");
    }
}
