package com.ecommerce.recipe_rest_api.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.recipe_rest_api.exception.ResourceNotFoundException;
import com.ecommerce.recipe_rest_api.model.Recipe;
import com.ecommerce.recipe_rest_api.model.RecipeDTO;
import com.ecommerce.recipe_rest_api.repository.CategoryRepository;
import com.ecommerce.recipe_rest_api.repository.RecipeRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class RecipeService {
	@Autowired
	private RecipeRepository rr;
	@Autowired
	private CategoryRepository cr;
	
	public Recipe saveRecipe( Recipe recipe) {
		//List<In>
		Recipe result = rr.save(recipe);
		return result;
		//rr.saveAndFlush(recipe);
	}
	
	public Recipe getRecipe(Long id) {
		Recipe recipe = rr.findById(id).orElse(null);
        System.out.println("Recipe: " + recipe);
        return recipe;
    }
	
	public void deleteRecipe(Long id) {
		Recipe recipe = rr.findById(id).orElse(null);
		rr.delete(recipe);
	}
	public List<Recipe> getAllRecipes(){
		return rr.findAll();
	}

	public Optional<Recipe> getRecipeById(Long id) {
	    Recipe recipe = rr.findById(id)
	            .orElseThrow(() -> new ResourceNotFoundException("Recipe not found with id " + id));
	    return Optional.of(recipe);
	}
	
}
