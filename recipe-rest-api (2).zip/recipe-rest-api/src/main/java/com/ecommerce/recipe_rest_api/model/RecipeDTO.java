package com.ecommerce.recipe_rest_api.model;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RecipeDTO {
    private Long id;
    private String name;
    private String description;
    private int time;
    private CategoryDTO category;
    private List<IngredientDTO> ingredients;
    private Long categoryId;
    private String categoryName;


    public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public RecipeDTO() {}

    public RecipeDTO(Recipe recipe) {
        this.id = recipe.getId();
        this.name = recipe.getName();
        this.description = recipe.getDescription();
        this.time = recipe.getTime();
        this.category = recipe.getCategory() != null ? new CategoryDTO(recipe.getCategory()) : null;
        this.ingredients = recipe.getIngredients().stream()
            .map(IngredientDTO::new)
            .collect(Collectors.toList());
    }

    public Recipe toEntity() {
        Recipe recipe = new Recipe();
        recipe.setId(this.id);
        recipe.setName(this.name);
        recipe.setDescription(this.description);
        recipe.setTime(this.time);
        if (this.category != null) {
            recipe.setCategory(this.category.toEntity());
        }
        if (this.ingredients != null) {
            this.ingredients.forEach(dto -> {
                Ingredient ing = dto.toEntity();
                recipe.addIngredient(ing);
            });
        }
        return recipe;
    }

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getTime() { return time; }
    public void setTime(int time) { this.time = time; }
    public CategoryDTO getCategory() { return category; }
    public void setCategory(CategoryDTO category2) { this.category = category2; }
    public List<IngredientDTO> getIngredients() { return ingredients; }
    public void setIngredients(List<IngredientDTO> ingredients) { this.ingredients = ingredients; }

 // static map method
    public static  RecipeDTO map(Recipe recipe) {
        RecipeDTO dto = new RecipeDTO();
        dto.setId(recipe.getId());
        dto.setName(recipe.getName());
        dto.setDescription(recipe.getDescription());
        dto.setTime(recipe.getTime());

        if (recipe.getCategory() != null) {
            dto.setCategoryId(recipe.getCategory().getId());
            dto.setCategoryName(recipe.getCategory().getName());
        }

        if (recipe.getIngredients() != null) {
            dto.setIngredients(
                recipe.getIngredients().stream()
                      .map(IngredientDTO::map)
                      .collect(Collectors.toList())
            );
        }

        return dto;
    }

	public RecipeDTO map(Object recipe1) {
		// TODO Auto-generated method stub
		Recipe recipe = (Recipe)recipe1;
		RecipeDTO dto = new RecipeDTO();
        dto.setId(recipe.getId());
        dto.setName(recipe.getName());
        dto.setDescription(recipe.getDescription());
        dto.setTime(recipe.getTime());

        if (recipe.getCategory() != null) {
            dto.setCategoryId(recipe.getCategory().getId());
            dto.setCategoryName(recipe.getCategory().getName());
        }

        if (recipe.getIngredients() != null) {
            dto.setIngredients(
                recipe.getIngredients().stream()
                      .map(IngredientDTO::map)
                      .collect(Collectors.toList())
            );
        }

        return dto;
	}

}
