## Spring Exercise 1 - DI using XML configuration

### Objective:

The Objective of this application is to understand the fundamentals of Dependency Injection

### Expected Outcome:

By the end of the assignment you should be able to understand

1. Dependency Injection configuration using xml
2. Getting spring bean object created by the spring container

### Instructions: 

1. Clone the boilerplate in a specific folder in your local machine and import the same in your eclipse STS.
2. Add relevant dependencies in pom.xml file. 
    Note: Read the comments mentioned in pom.xml file for identifying the relevant dependencies.
3. In resources/beans.xml, add the required bean elements for Note model class
4. In User.java file (which is considered as Model class), declare all the necessary variables for the model.
5. In App.java create an ApplicationContext object and retrieve the user bean object.
6. Run the test cases present in AppTest.java


