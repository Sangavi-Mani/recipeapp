package com.stackroute.user.commander.test;

import com.stackroute.user.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit test for xml config App.
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:Beans.xml"})
public class AppTest  {
    @Autowired
    User user;

    @Autowired
    User user1;

    @Test
    public void beanCreationSuccessTest() {
        assertNotNull(user);
    }

    @Test
    public void checkSingleton() {
        assertSame(user, user1);
    }

    @Test
	public void givenBeanCreatedThenSetProperties(){
		assertEquals("John", user.getName());
		assertEquals("1", user.getId());
		assertEquals("John.v@gmail.com", user.getEmailId());
		assertEquals("John123", user.getPassword());
		assertEquals("9989989878", user.getMobile());
	}

}
