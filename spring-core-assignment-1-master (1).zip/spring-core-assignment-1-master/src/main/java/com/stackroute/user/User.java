package com.stackroute.user;
/*
 * The class "User" will be acting as the data model
 *
 */

public class User {

    /*
     * This class should have five fields (id, name,password,mobile and emailId).
     * This class should also contain the getters and setters for the fields.
     */

   

}
