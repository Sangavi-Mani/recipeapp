package com.stackroute.user;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App {

    public static void main(String[] args) {
        /**
         * Create ApplicationContext object and retrieve the user object
         *
         */
        final ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
       

    }
}
