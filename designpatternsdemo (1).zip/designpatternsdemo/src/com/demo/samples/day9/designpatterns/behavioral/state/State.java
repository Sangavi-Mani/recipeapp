package com.demo.samples.day9.designpatterns.behavioral.state;

public interface State {
	public void changeState();

	public void displayState();
}