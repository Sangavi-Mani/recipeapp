package com.demo.samples.day9.designpatterns.behavioural.iterator;

public interface Iterator {
	public boolean hasNext();
	public Object next();
}
