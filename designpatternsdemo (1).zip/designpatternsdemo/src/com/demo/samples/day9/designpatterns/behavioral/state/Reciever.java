package com.demo.samples.day9.designpatterns.behavioral.state;

public interface Reciever {
	public void on();

	public void off();
}