package com.demo.samples.day10.designpatterns.presentation.frontcontroller;

public class StudentView {
	   public void show(){
	      System.out.println("Displaying Student Page");
	   }
	}