package com.demo.samples.day10.designpatterns.presentation.interceptingfilter;

public interface Filter {
	public void execute(String request);

}
