package com.demo.samples.day10.designpatterns.presentation.interceptingfilter;

public class Target {
	   public void execute(String request){
	      System.out.println("Executing request: " + request);
	   }
	}
