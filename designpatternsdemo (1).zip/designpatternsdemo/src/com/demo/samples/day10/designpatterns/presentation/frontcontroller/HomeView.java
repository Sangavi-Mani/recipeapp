package com.demo.samples.day10.designpatterns.presentation.frontcontroller;

public class HomeView {
	   public void show(){
	      System.out.println("Displaying Home Page");
	   }
	}