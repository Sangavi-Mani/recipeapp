package com.demo.samples.day8.designpatterns.structural.proxy;

public interface OfficeInternetAccess {
	public void grantInternetAccess();
}
