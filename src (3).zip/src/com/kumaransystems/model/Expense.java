package com.kumaransystems.model;

public class Expense extends Transaction{

	@Override
	void processTransaction() {
		// TODO Auto-generated method stub
		System.out.println(amount+ " subtracted as Expense");
		
	}

}
