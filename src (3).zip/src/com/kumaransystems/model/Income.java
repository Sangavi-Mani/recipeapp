package com.kumaransystems.model;

public class Income extends Transaction {

	@Override
	void processTransaction() {
		// TODO Auto-generated method stub
		
		System.out.println(amount+ " added to Income");
		
	}

}
