package com.kumaransystems.model;



// Task 4: Shipment class
public  class Shipment implements Trackable{
    protected String shipmentId;
    protected String source;
    protected String destination;
    protected double weight;
    public String status;
    private int deliveryTime; // in days

    public Shipment(String shipmentId, String source, String destination, double weight, String status) {
        this.shipmentId = shipmentId;
        this.source = source;
        this.destination = destination;
        this.weight = weight;
        this.status = status;
    }

    public Shipment() {
		// TODO Auto-generated constructor stub
	}

	public String getShipmentId() {
        return shipmentId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Shipment{" +
                "shipmentId='" + shipmentId + '\'' +
                ", source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                ", weight=" + weight +
                ", status='" + status + '\'' +
                '}';
    }

	@Override
	public String trackLocation() {
		// TODO Auto-generated method stub
		   return "Tracking location for shipment: " + shipmentId;
	}
	 public int getDeliveryTime() {
	        return deliveryTime;
	    }

	public String getStatus() {
		// TODO Auto-generated method stub
		return status;
	}
	    
}
