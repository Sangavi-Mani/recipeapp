package com.kumaransystems.model;

public class StandardShipment extends Shipment {
    public StandardShipment(String shipmentId, String source, String destination, double weight, String status) {
        super(shipmentId, source, destination, weight, status);
    }
}

