package com.kumaransystems.model;

public class Vehicle {
	
	private int vehicleId, capacity;
	private String type;
	//private int capacity;
	private boolean availabilityStatus;
	
	//spl fn, similar to classname - constructor - empty constructor
	public Vehicle() {
		//vehicleId=100;
		
		System.out.println("  Empty constructor of Vehicle");
		//super();
	}
	
	//spl fn, similar to classname - constructor - parameterised constructor
	public Vehicle(int vehicleId, String type, int capacity, boolean availabilityStatus) {
	//	super();
		System.out.println("  Parameterised constructor of Vehicle");
		this.vehicleId = vehicleId;
		this.type = type;
		this.capacity = capacity;
		this.availabilityStatus = availabilityStatus;
	}

	public Vehicle(int string, String string2, boolean b) {
		// TODO Auto-generated constructor stub
		this.vehicleId= string;
		this.type=string2;
		this.availabilityStatus=b;
	}

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		System.out.println(" Setting vehicle idd ");
		this.vehicleId = vehicleId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public boolean isAvailabilityStatus() {
		return availabilityStatus;
	}

	public void setAvailabilityStatus(boolean availabilityStatus) {
		this.availabilityStatus = availabilityStatus;
	}

	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", capacity=" + capacity + ", type=" + type + ", availabilityStatus="
				+ availabilityStatus + "]";
	}
	
	
	

}


