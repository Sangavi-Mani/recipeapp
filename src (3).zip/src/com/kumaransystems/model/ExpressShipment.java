package com.kumaransystems.model;

//Task 8: Inheritance with specific shipment types
public class ExpressShipment extends Shipment {
 private double expressCharge;

 public ExpressShipment(String shipmentId, String source, String destination, double weight, String status, double expressCharge) {
     super(shipmentId, source, destination, weight, status);
     this.expressCharge = expressCharge;
 }

 @Override
 public String toString() {
     return super.toString() + ", ExpressCharge=" + expressCharge;
 }
}

