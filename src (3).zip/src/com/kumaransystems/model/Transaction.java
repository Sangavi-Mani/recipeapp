package com.kumaransystems.model;

public abstract class Transaction {
	
	int amount;
	String type;
	
	
	abstract void processTransaction(); //abstract or not -full defined method
	
	//fully defined method - concrete method
	void displayTransaction() {
		System.out.println(" Amount  :"+amount +"Type :"+type );
		
	}

}
