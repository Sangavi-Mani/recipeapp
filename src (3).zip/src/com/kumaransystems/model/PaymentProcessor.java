package com.kumaransystems.model;

public interface PaymentProcessor {
	

}
