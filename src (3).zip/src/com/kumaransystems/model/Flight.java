package com.kumaransystems.model;

public class Flight {
	

}
