package com.kumaransystems.model;

public interface Trackable {
	String trackLocation();
}
