package com.kumaransystems.model;

public class Voter {
	String name;
	int age;


    @Override
	public String toString() {
		return "Voter [name=" + name + ", age=" + age + "]";
	}

	/* Parameterised constructor */
    public Voter(String name, int age) {

    }

    /*Getters and Setters*/
    public String getName() {
        return null;
    }

    public void setName(String name) {

    }

    public int getAge() {
        return -1;
    }

    public void setAge(int age) {

    }

    
    /*
        Returns the age criteria of voter based on the below criteria
            ADULT : >=18
            UNDERAGE : < 18
     */
    public String getAgeCriteria() {
        return null;
    }
}
