package com.kumaransystems.service;

import com.kumaransystems.model.Vehicle;

public class ShipmentManager_Trial {

	public static void main(String[] args) {
		// ClassName objetName = new ClassName()
		Vehicle emptyVehicle = new Vehicle();
	//	Vehicle emptyVehicle = null;
		// emptyVehicle.g
		//null check
		if (emptyVehicle != null) {
			System.out.println(emptyVehicle.getVehicleId());
			emptyVehicle.setVehicleId(103);
			System.out.println(emptyVehicle.getVehicleId());
		}

		Vehicle truckVehicle = new Vehicle(101, "Truck", 100, true);
		System.out.println(truckVehicle);
		System.out.println(truckVehicle.getType());
		
		long rent = 40000L;
		int rentInt =(int) rent; //explicit conversion
		
		Vehicle[] vehicles = new Vehicle[10];
		vehicles[0] = new Vehicle();
		vehicles[1] = new Vehicle(112, "Bus", 200, true);
		
	}

}
