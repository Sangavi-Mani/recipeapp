package com.kumaransystems.service;
import com.kumaransystems.model.*;
import java.util.*;

public class VehicleManager {
    private Map<Integer, Vehicle> vehicleMap = new HashMap<>();

    public void addVehicle(Vehicle vehicle) {
        vehicleMap.put(vehicle.getVehicleId(), vehicle);
    }

    public Vehicle getVehicle(String vehicleId) {
        return vehicleMap.get(vehicleId);
    }

    public void listAvailableVehicles() {
        vehicleMap.values().stream()
                .filter(Vehicle::isAvailabilityStatus)
                .forEach(System.out::println);
    }
}
