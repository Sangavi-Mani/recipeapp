package com.kumaransystems.service;
import java.util.Arrays;

import com.kumaransystems.model.*;
public class ShipmentManager {
    private Shipment[] shipments;
    private int size;
    private static final int INITIAL_CAPACITY = 10;

    public ShipmentManager() {
        shipments = new Shipment[INITIAL_CAPACITY];
        size = 0;
    }

    public void addShipment(Shipment shipment) {
        if (size == shipments.length) {
            expandCapacity();
        }
        shipments[size++] = shipment;
    }

    public void updateShipmentStatus(String shipmentId, String newStatus) {
        for (int i = 0; i < size; i++) {
            if (shipments[i].getShipmentId().equals(shipmentId)) {
                shipments[i].setStatus(newStatus);
                break;
            }
        }
    }

    public void removeShipment(String shipmentId) {
        for (int i = 0; i < size; i++) {
            if (shipments[i].getShipmentId().equals(shipmentId)) {
                System.arraycopy(shipments, i + 1, shipments, i, size - i - 1);
                size--;
                break;
            }
        }
    }

    public void listShipments() {
        for (int i = 0; i < size; i++) {
            System.out.println(shipments[i]);
        }
    }

    public Shipment[] getAllShipments() {
        return Arrays.copyOf(shipments, size);
    }

    private void expandCapacity() {
        shipments = Arrays.copyOf(shipments, shipments.length * 2);
    }
}




/*
 * package com.kumaransystems.service;
 * 
 * import java.util.*; import com.kumaransystems.model.*;
 * 
 * //Task 5: ShipmentManager class public class ShipmentManager { private
 * List<Shipment> shipments = new ArrayList<>();
 * 
 * public void addShipment(Shipment shipment) { shipments.add(shipment); }
 * 
 * public void updateShipmentStatus(String shipmentId, String newStatus) { for
 * (Shipment shipment : shipments) { if
 * (shipment.getShipmentId().equals(shipmentId)) {
 * shipment.setStatus(newStatus); break; } } }
 * 
 * public void removeShipment(String shipmentId) { shipments.removeIf(shipment
 * -> shipment.getShipmentId().equals(shipmentId)); }
 * 
 * public void listShipments() { for (Shipment shipment : shipments) {
 * System.out.println(shipment); } } public List<Shipment> getAllShipments() {
 * return shipments; }
 * 
 * }
 */