package com.kumaransystems.util;

import com.kumaransystems.model.Shipment;
import java.util.Arrays;

// Task 15: Utility class for shipment calculations
public class ShipmentUtils {
    public static int getTotalShipments(Shipment[] shipments) {
        return shipments.length;
    }

    public static long getPendingDeliveries(Shipment[] shipments) {
        return Arrays.stream(shipments).filter(s -> !"Delivered".equals(s.getStatus())).count();
    }

    /*
     * public static double getTotalShipmentCost(Shipment[] shipments) {
     *     // return Arrays.stream(shipments).mapToDouble(Shipment::getCost).sum();
     * }
     */
    public static double getAverageDeliveryTime(Shipment[] shipments) {
        return Arrays.stream(shipments).mapToInt(Shipment::getDeliveryTime).average().orElse(0.0);
    }
}

/*
 * package com.kumaransystems.util; import java.util.*;
 * 
 * import com.kumaransystems.model.Shipment;
 * 
 * //Task 15: Utility class for shipment calculations public class ShipmentUtils
 * { public static int getTotalShipments(List<Shipment> shipments) { return
 * shipments.size(); }
 * 
 * public static long getPendingDeliveries(List<Shipment> shipments) { return
 * shipments.stream().filter(s -> !"Delivered".equals(s.status)).count(); }
 * 
 * 
 * public static double getTotalShipmentCost(List<Shipment> shipments) { //
 * return shipments.stream().mapToDouble(Shipment::getCost).sum(); }
 * 
 * public static double getAverageDeliveryTime(List<Shipment> shipments) {
 * return
 * shipments.stream().mapToInt(Shipment::getDeliveryTime).average().orElse(0.0);
 * } }
 */