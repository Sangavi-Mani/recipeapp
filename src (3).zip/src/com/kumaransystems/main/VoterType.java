package com.kumaransystems.main;

public enum VoterType {
	CAN_CAST_VOTE,
	CAN_NOT_CAST_VOTE

}
