package com.kumaransystems.main;

public class Student {
	int id;
	static final int score=10;
		/*
		 * Student(int score){ // this.score=score; }
		 */
	
	public static void main(String[] args) throws CloneNotSupportedException {
		Student s = new Student();
		
		System.out.println(s.hashCode());
		
		Student s1 = new Student();
		System.out.println(s1.hashCode());
		
		Student s2 = s1;//new 
		System.out.println(s2.hashCode());
		
		System.out.println(s1.toString());
		Student xyz = new Student();
		System.out.println(xyz.getClass());
		
		if(s.equals(s2)) {
			System.out.println(" both are equals");
		}else {
			System.out.println(" not equal");
		}
		
		Integer[] ints = new Integer[10];
		ints[0] = new Integer(1);
		
		
		try {
			Object rishi =  s.clone();// class casting
			System.out.println(rishi.hashCode());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
