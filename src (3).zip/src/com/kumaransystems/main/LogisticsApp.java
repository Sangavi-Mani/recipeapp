package com.kumaransystems.main;

//Enum defining transportation modes with speed (km/h) and cost per km ($)
enum TransportationMode {
 ROAD(60, 0.5),//new ROAD(60,0.5)
 AIR(800, 5.0),
 SEA(30, 0.2),
 RAIL(100, 0.8);

 private final double speed; // in km/h
 private  final double costPerKm; // in $

 // Constructor
 TransportationMode(double speed, double costPerKm) {
	 System.out.println(" Trans");
     this.speed = speed;
     this.costPerKm = costPerKm;
 }

 // Method to calculate estimated time (in hours)
 public double getEstimatedTime(double distance) {
	     return distance / speed; 
 }

 // Method to calculate estimated cost
 public double getEstimatedCost(double distance) {
     return distance * costPerKm;
 }
}

//Main class for testing the enum
public class LogisticsApp {
 public static void main(String[] args) {
     double distance = 1500; // Example distance in km

     for (TransportationMode mode : TransportationMode.values()) {
         System.out.println("Mode: " + mode);
         System.out.println("Estimated Time: " + mode.getEstimatedTime(distance) + " hours");
         System.out.println("Estimated Cost: $" + mode.getEstimatedCost(distance));
         System.out.println("-----------------------------------");
     }
 }
}
