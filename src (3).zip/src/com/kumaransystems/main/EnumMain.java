package com.kumaransystems.main;

public class EnumMain {
    

    public static void main(String[] args) {
        Transport mode = Transport.AIR;

        switch (mode) {
            case TRUCK:
                System.out.println("Goods are transported by road.");
                break;
            case SHIP:
                System.out.println("Goods are transported by sea.");
                break;
            case AIR:
                System.out.println("Goods are transported by air.");
                break;
            case TRAIN:
                System.out.println("Goods are transported by rail.");
                break;
        }
    }
}

