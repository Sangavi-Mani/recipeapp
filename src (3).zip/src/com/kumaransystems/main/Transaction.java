package com.kumaransystems.main;

class Transaction{
	
	static {
		System.out.println(" Inside static ");
	}

	Transaction(){
		System.out.println(" Inside constructor ");
	}
	public static void main(String args[]){
		Transaction t = new Transaction();
		t.addTransaction();
		Transaction.performTransaction();
		String message = String.join("-", "Java", "is", "cool");
		System.out.println(message);
		String s = "hello";
		System.out.println(s.charAt(3));

		
	System.out.println("TRansaction Manager");
		
	if(args.length < 1)
		System.out.println("No args");
	else
		for(String arg : args)	
			System.out.println(arg);


	}

	static void performTransaction() {
		System.out.println(" Inside static performTransaction");
	}

	//instance method
	void addTransaction() {
		System.out.println(" Inside add Transaction");
	}
}