package com.kumaransystems.main;

public enum Transport {
    TRUCK,
    SHIP,
    AIR,
    TRAIN;
}