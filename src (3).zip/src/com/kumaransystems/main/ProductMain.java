package com.kumaransystems.main;


class Product {

   int productCode;

   String name;

   double price;

   String category;

   public Product(int productCode, String name, double price, String category) {

       this.productCode = productCode;

       this.name = name;

       this.price = price;

       this.category = category;

   }

   public int getProductCode() {

       return productCode;

   }

   public void setProductCode(int productCode) {

       this.productCode = productCode;

   }

   public String getName() {

       return name;

   }

   public void setName(String name) {

       this.name = name;

   }

   public double getPrice() {

       return price;

   }

   public void setPrice(double price) {

       this.price = price;

   }

   public String getCategory() {

       return category;

   }

   public void setCategory(String category) {

       this.category = category;

   }

}


class ProductRepository {

   private static final Product[] products;

   private static final String COMPUTERS = "computers";

   private static final String CLOTHING = "clothing";

   private static final String TOYS = "toys";

   /*

       static block initializes the Array of Products with eight products

    */

   static {

       products = new Product[8];

       products[0] = new Product(101, "keyboard", 300, COMPUTERS);

       products[1] = new Product(102, "mouse", 600, COMPUTERS);

       products[2] = new Product(103, "monitor", 5000, COMPUTERS);

       products[3] = new Product(104, "t-shirt", 500, CLOTHING);

       products[4] = new Product(105, "jeans", 2000, CLOTHING);

       products[5] = new Product(106, "sweater", 1000, CLOTHING);

       products[6] = new Product(107, "doll", 500, TOYS);

       products[7] = new Product(108, "car", 1000, TOYS);

   }

   private ProductRepository() {

       //Prevents object creation

   }

   public static Product[] getProducts() {

       return products;

   }

}


class ProductService {

   /*

       Returns the name of the product given the productCode

    */

   public String findProductNameByCode(int productCode) {

       for (Product product : ProductRepository.getProducts()) {

           if (product.getProductCode() == productCode) {

               return product.getName();

           }

       }

       return "Product not found";

   }

   /*

       Returns the Product with maximum price in a given category

    */

public Product findMaxPriceProductInCategory(String category) {

   Product maxProduct = null;

   double maxPrice = Double.MIN_VALUE;

   for (Product product : ProductRepository.getProducts()) {

       if (product.getCategory().equalsIgnoreCase(category) && product.getPrice() > maxPrice) {

           maxPrice = product.getPrice();

           maxProduct = product;

       }

   }

   return maxProduct;

}

   /*

       Returns a array of products for a given category

    */

   public Product[] getProductsByCategory(String category) {

       return new Product[]{};

   }

}


public class ProductMain{

   public static void main(String[] args){

       ProductService pd1 = new ProductService();

       Product pdname = pd1.findMaxPriceProductInCategory("CLOTHING");

       System.out.print(pdname.name);


   }

}


