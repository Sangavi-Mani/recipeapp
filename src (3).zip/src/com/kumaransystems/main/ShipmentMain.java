package com.kumaransystems.main;
import com.kumaransystems.service.*;
import com.kumaransystems.util.ShipmentUtils;
import com.kumaransystems.model.*;
public class ShipmentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ShipmentManager manager = new ShipmentManager();

        Shipment shipment1 = new StandardShipment("S001", "New York", "Los Angeles", 15.5, "In Transit");
        Shipment shipment2 = new ExpressShipment("S002", "Chicago", "Houston", 10.0, "Delivered", 25.0);

        
        manager.addShipment(shipment1);
        manager.addShipment(shipment2);
        
        manager.listShipments();
        
        manager.updateShipmentStatus("S001", "Delivered");
        manager.listShipments();
        
        manager.removeShipment("S002");
        manager.listShipments();
        
 System.out.println(shipment1.trackLocation());
        
        // Managing vehicles
        Vehicle vehicle1 = new Vehicle(1, "Truck", true);
        Vehicle vehicle2 = new Vehicle(2, "Van", false);
        VehicleManager vehicleManager = new VehicleManager();
        vehicleManager.addVehicle(vehicle1);
        vehicleManager.addVehicle(vehicle2);
        
        vehicleManager.listAvailableVehicles();
        
        // Shipment Utils usage
        System.out.println("Total Shipments: " + ShipmentUtils.getTotalShipments(manager.getAllShipments()));
        System.out.println("Pending Deliveries: " + ShipmentUtils.getPendingDeliveries(manager.getAllShipments()));
        System.out.println("Average Delivery Time: " + ShipmentUtils.getAverageDeliveryTime(manager.getAllShipments()));


	}

}
