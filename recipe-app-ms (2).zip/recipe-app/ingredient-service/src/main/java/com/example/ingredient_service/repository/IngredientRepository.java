package com.example.ingredient_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
import com.example.ingredient_service.model.Ingredient;

public interface IngredientRepository extends JpaRepository<Ingredient, Long>{
	List<Ingredient> findByRecipeId(Long recipeId);


}
