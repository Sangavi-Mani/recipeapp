package com.example.ingredient_service.controller;


import com.example.ingredient_service.model.Ingredient;
import com.example.ingredient_service.service.IngredientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ingredient")
public class IngredientController {

    @Autowired
    private IngredientService ingredientService;

    @PostMapping
    public ResponseEntity<Ingredient> save(@RequestBody Ingredient ingredient) {
        return ResponseEntity.ok(ingredientService.saveIngredient(ingredient));
    }

    @GetMapping
    public ResponseEntity<List<Ingredient>> findAll() {
        return ResponseEntity.ok(ingredientService.getAllIngredients());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ingredient> findById(@PathVariable Long id) {
        return ResponseEntity.ok(ingredientService.getIngredientById(id));
    }

    @GetMapping("/recipe/{recipeId}")
    public ResponseEntity<List<Ingredient>> findByRecipeId(@PathVariable Long recipeId) {
        return ResponseEntity.ok(ingredientService.getIngredientsByRecipeId(recipeId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Ingredient> update(@PathVariable Long id, @RequestBody Ingredient updated) {
        return ResponseEntity.ok(ingredientService.updateIngredient(id, updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        ingredientService.deleteIngredient(id);
        return new ResponseEntity<String>("Deleted :"+id+ " successfully !",HttpStatus.OK);
    }
}

