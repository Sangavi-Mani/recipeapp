package com.example.recipe_service.service;

import com.example.recipe_service.dto.CategoryDTO;
import com.example.recipe_service.dto.IngredientDTO;
import com.example.recipe_service.dto.RecipeResponseDTO;
import com.example.recipe_service.model.Recipe;
import com.example.recipe_service.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecipeService {

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private RestTemplate restTemplate;

	private final String CATEGORY_SERVICE_URL = "http://localhost:1000/category";
	private final String INGREDIENT_SERVICE_URL = "http://localhost:2000/ingredient";

	public Recipe saveRecipe(Recipe recipe) {
		return recipeRepository.save(recipe);
	}

	public List<Recipe> getAllRecipes() {
		return recipeRepository.findAll();
	}

	public Optional<Recipe> getRecipeById(Long id) {
		return recipeRepository.findById(id);
	}

	public void deleteRecipe(Long id) {
		recipeRepository.deleteById(id);
	}

	public Recipe updateRecipe(Long id, Recipe updatedRecipe) {
		return recipeRepository.findById(id).map(recipe -> {
			recipe.setName(updatedRecipe.getName());
			recipe.setDescription(updatedRecipe.getDescription());
			recipe.setTime(updatedRecipe.getTime());
			recipe.setCategoryId(updatedRecipe.getCategoryId());
			recipe.setIngredientIds(updatedRecipe.getIngredientIds());
			return recipeRepository.save(recipe);
		}).orElseThrow(() -> new RuntimeException("Recipe not found with id " + id));
	}

	public RecipeResponseDTO getRecipeDetails(Long id) {
		Recipe recipe = recipeRepository.findById(id).orElseThrow(() -> new RuntimeException("Recipe not found"));

		CategoryDTO category = restTemplate.getForObject(CATEGORY_SERVICE_URL + "/" + recipe.getCategoryId(),
				CategoryDTO.class);

		List<IngredientDTO> ingredients = recipe
				.getIngredientIds().stream().map(ingredientId -> restTemplate
						.getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId, IngredientDTO.class))
				.filter(Objects::nonNull).collect(Collectors.toList());

		RecipeResponseDTO response = new RecipeResponseDTO();
		response.setId(recipe.getId());
		response.setName(recipe.getName());
		response.setDescription(recipe.getDescription());
		response.setTime(recipe.getTime());
		response.setCategory(category);
		response.setIngredients(ingredients);

		return response;
	}
}