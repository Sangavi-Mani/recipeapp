package com.example.recipe_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.recipe_service.model.Recipe;

public interface RecipeRepository extends JpaRepository<Recipe, Long>{

}
