package com.example.springbootcrudapp.exception;

import org.springframework.boot.context.properties.bind.BindException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionController {

	// For your UIs
	@ExceptionHandler(ProductNotFoundException.class)
	public String prouctNotFoundException(ProductNotFoundException px) {
		System.out.println(px.getLocalizedMessage());
		return "error";
	}

	@ExceptionHandler(BindException.class)
    public String handleBindException(BindException ex, Model model) {
        model.addAttribute("errorMessage", "Invalid Product ID: Must be a number.");
        return "error_demo"; // your error page
    }
	
	@ExceptionHandler(IllegalArgumentException.class)
	public String prouctIllgel(IllegalArgumentException ex) {
		return "error_demo";
	}

	
	  

}
