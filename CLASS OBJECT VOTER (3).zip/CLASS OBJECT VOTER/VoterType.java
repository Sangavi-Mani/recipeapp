package com.demo.oops;

public enum VoterType {
    /*
 Enumeration of Voter types based on the age criteria of voter
*/
    VOTER_CAN_CAST_VOTE,
    VOTER_CANNOT_CAST_VOTE,
    INVALID_VOTER,
}
