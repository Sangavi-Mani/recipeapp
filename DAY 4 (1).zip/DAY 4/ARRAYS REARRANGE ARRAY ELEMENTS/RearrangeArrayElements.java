package com.demo.arrays;

public class RearrangeArrayElements {
    public static void main(String[] args) {
    }

    //write logic to get inputs from user and send inputs for validation
    public void inputAcceptor() {
	
	
    }

    //write logic to validate the given array size is valid or not
    public boolean inputArraySizeValidator(int size) {
        return (Boolean) null;
    }

    //write logic to validate the given input array is sorted or not
    public boolean inputArrayValidator(int[] input) {
        return (Boolean) null;
    }

    //write logic to rearrange elements of array and return the result array
    public int[] computeRearrangedArray(int[] inputArray) {
        return null;
    }

    //write logic to print the result
    public void displayResult(int[] outputArray) {
    }
}
