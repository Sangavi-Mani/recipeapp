package com.demo.oops;

public interface Vehicle {
    int maxSpeed(String type);
}
