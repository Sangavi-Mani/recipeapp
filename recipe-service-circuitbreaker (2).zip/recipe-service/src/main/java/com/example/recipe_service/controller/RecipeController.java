package com.example.recipe_service.controller;

import com.example.recipe_service.dto.RecipeResponseDTO;
import com.example.recipe_service.model.Recipe;
import com.example.recipe_service.service.RecipeService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recipe")
public class RecipeController {

	@Autowired
	private RecipeService recipeService;

	@PostMapping
	public ResponseEntity<Recipe> createRecipe(@RequestBody Recipe recipe) {
		Recipe saved = recipeService.saveRecipe(recipe);
		return ResponseEntity.ok(saved);
	}

	@GetMapping
	public ResponseEntity<List<Recipe>> getAllRecipes() {
		return ResponseEntity.ok(recipeService.getAllRecipes());
		//return new ResponseEntity<List<Recipe>>(recipeService.getAllRecipes(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Recipe> getRecipeById(@PathVariable Long id) {
		//Recipe recipe = recipeService.getRecipeId(id).orElse("");
		//return new ResponseEntity<Recipe>(recipe, HttpStatus.OK);
		return recipeService.getRecipeById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}

	@PutMapping("/{id}")
	public ResponseEntity<Recipe> updateRecipe(@PathVariable Long id, @RequestBody Recipe updatedRecipe) {
		try {
			Recipe updated = recipeService.updateRecipe(id, updatedRecipe);
			return ResponseEntity.ok(updated);
		} catch (RuntimeException ex) {
			return ResponseEntity.notFound().build();
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteRecipe(@PathVariable Long id) {
		recipeService.deleteRecipe(id);
	//HttpStatus.ACCEPTED
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/details/{id}")
	public ResponseEntity<RecipeResponseDTO> getRecipeDetails(@PathVariable Long id) {
		try {
			RecipeResponseDTO responseDTO = recipeService.getRecipeDetails(id);
			return ResponseEntity.ok(responseDTO);
		} catch (RuntimeException ex) {
			return ResponseEntity.notFound().build();
		}
	}
}