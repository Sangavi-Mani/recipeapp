package com.example.recipe_service.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreaker;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.recipe_service.dto.CategoryDTO;
import com.example.recipe_service.dto.IngredientDTO;
import com.example.recipe_service.dto.RecipeResponseDTO;
import com.example.recipe_service.model.Recipe;
import com.example.recipe_service.repository.RecipeRepository;

@Service
public class RecipeService {

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private CircuitBreakerFactory cFactory;

	private final String CATEGORY_SERVICE_URL = "http://category-service:1000/category";
	private final String INGREDIENT_SERVICE_URL = "http://ingredient-service:2000/ingredient";

	public Recipe saveRecipe(Recipe recipe) {
		return recipeRepository.save(recipe);
	}

	public List<Recipe> getAllRecipes() {
		return recipeRepository.findAll();
	}

	public Optional<Recipe> getRecipeById(Long id) {
		return recipeRepository.findById(id);
	}

	public void deleteRecipe(Long id) {
		recipeRepository.deleteById(id);
	}

	public Recipe updateRecipe(Long id, Recipe updatedRecipe) {
		return recipeRepository.findById(id).map(recipe -> {
			recipe.setName(updatedRecipe.getName());
			recipe.setDescription(updatedRecipe.getDescription());
			recipe.setTime(updatedRecipe.getTime());
			recipe.setCategoryId(updatedRecipe.getCategoryId());
			recipe.setIngredientIds(updatedRecipe.getIngredientIds());
			return recipeRepository.save(recipe);
		}).orElseThrow(() -> new RuntimeException("Recipe not found with id " + id));
	}

	/*
	 * public RecipeResponseDTO getRecipeDetails(Long id) { Recipe recipe =
	 * recipeRepository.findById(id).orElseThrow(() -> new
	 * RuntimeException("Recipe not found"));
	 * 
	 * CategoryDTO category = restTemplate.getForObject(CATEGORY_SERVICE_URL + "/" +
	 * recipe.getCategoryId(), CategoryDTO.class);
	 * 
	 * List<IngredientDTO> ingredients = recipe
	 * .getIngredientIds().stream().map(ingredientId -> restTemplate
	 * .getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId,
	 * IngredientDTO.class)) .filter(Objects::nonNull).collect(Collectors.toList());
	 * 
	 * RecipeResponseDTO response = new RecipeResponseDTO();
	 * response.setId(recipe.getId()); response.setName(recipe.getName());
	 * response.setDescription(recipe.getDescription());
	 * response.setTime(recipe.getTime()); response.setCategory(category);
	 * response.setIngredients(ingredients);
	 * 
	 * return response; }
	 */

	public RecipeResponseDTO getRecipeDetails(Long id) {
		Recipe recipe = recipeRepository.findById(id).orElseThrow(() -> new RuntimeException("Recipe not found"));

		// Category (Circuit Breaker)
		CategoryDTO category = getCategoryById(recipe.getCategoryId());

		// Ingredients (Circuit Breaker per call)
		List<IngredientDTO> ingredients = recipe.getIngredientIds().stream().map(this::getIngredientById)
				.filter(Objects::nonNull).collect(Collectors.toList());

		RecipeResponseDTO response = new RecipeResponseDTO();
		response.setId(recipe.getId());
		response.setName(recipe.getName());
		response.setDescription(recipe.getDescription());
		response.setTime(recipe.getTime());
		response.setCategory(category);
		response.setIngredients(ingredients);

		return response;
	}

	public CategoryDTO getCategoryById(Long categoryId) {
		CircuitBreaker circuitBreaker = (CircuitBreaker) cFactory.create("categoryServiceCB");

        return ((org.springframework.cloud.client.circuitbreaker.CircuitBreaker) circuitBreaker).run(
            () -> restTemplate.getForObject(CATEGORY_SERVICE_URL + "/" + categoryId, CategoryDTO.class),
            throwable -> categoryFallback(categoryId, throwable) // Fallback logic
        );

	}

	public CategoryDTO categoryFallback(Long categoryId, Throwable ex) {
		return new CategoryDTO(categoryId, "Unknown Category (fallback)");
	}

	public IngredientDTO getIngredientById(Long ingredientId) {
		CircuitBreaker circuitBreaker = (CircuitBreaker) cFactory.create("ingredientServiceCB");

        return ((org.springframework.cloud.client.circuitbreaker.CircuitBreaker) circuitBreaker).run(
            () -> restTemplate.getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId, IngredientDTO.class),
            throwable -> ingredientFallback(ingredientId, throwable) // Fallback logic
        );
		//return restTemplate.getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId, IngredientDTO.class);
	}

	public IngredientDTO ingredientFallback(Long ingredientId, Throwable ex) {
		return new IngredientDTO(ingredientId, "Unknown Ingredient Name (fallback)","Unknown Quantity(fallback)");
	}

}