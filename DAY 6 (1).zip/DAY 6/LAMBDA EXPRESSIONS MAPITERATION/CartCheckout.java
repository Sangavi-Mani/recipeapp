package com.demo.exercises;


import java.math.BigDecimal;
import java.util.Map;

public class CartCheckout {

    //write here logic to add a Map values include tax using lambda expression
    public String billGenerator(Map<String, BigDecimal> cart, Double taxPercent) {

        return null;
    }
}
