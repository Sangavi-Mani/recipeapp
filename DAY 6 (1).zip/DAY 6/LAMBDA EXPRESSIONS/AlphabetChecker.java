package com.demo.lambdaexpression;

import java.util.List;

public class AlphabetChecker {
    //write logic to find whether given string contains only alphabets or not
    public String checkAlphabets(List<String> inputList) {
        return null;
    }
}
