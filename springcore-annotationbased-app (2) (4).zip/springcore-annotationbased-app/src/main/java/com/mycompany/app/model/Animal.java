package com.mycompany.app.model;

public interface Animal {
	public void makeSound();

}
