package com.mycompany.app.model;

public interface PaymentService {
	void makePayment();
}
