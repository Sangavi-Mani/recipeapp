package com.mycompany.app.model;

public interface DataSource {
	void connect();
}
