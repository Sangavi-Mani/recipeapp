package com.example.jpa;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

@Entity
@Table(name="ipl_match")
public class Match {
	
	@Id
	@Column(name="match_id")
	@GeneratedValue
	private int matchId;
	
	private String name;
	
	public Match() {
		
	}

	public int getMatchId() {
		return matchId;
	}

	public void setMatchId(int matchId) {
		this.matchId = matchId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
