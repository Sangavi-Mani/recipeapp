package com.example.jpa;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

@Entity
@Table(name="ipl_scores")
public class Score {
	
	@Id
	@Column(name="score_id")
	private int scoreId;
	
	public int getScoreId() {
		return scoreId;
	}

	public void setScoreId(int scoreId) {
		this.scoreId = scoreId;
	}

	public String getMatchName() {
		return matchName;
	}

	public void setMatchName(String matchName) {
		this.matchName = matchName;
	}

	@Column(name="match_name")
	private String matchName;
	
	public Score() {
		
	}

}
