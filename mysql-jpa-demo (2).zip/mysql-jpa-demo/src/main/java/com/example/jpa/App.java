package com.example.jpa;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("fdssd");
  	  EntityManager entityManager = emf.createEntityManager();
  	entityManager.getTransaction().begin();

	  Player p = new Player();
	  p.setPassword("my-password");
	  entityManager.persist(p);
	  
	  
	  Match m = new Match();
	  m.setName("CSKvsLSG");
	  entityManager.persist(m);
	  
	  
	  Long key = Long.valueOf(52);
	  Player existingPlayer = entityManager.find(Player.class, key);
	  System.out.println(existingPlayer);
	   entityManager.remove(existingPlayer);

	

	  entityManager.getTransaction().commit();


    }
}
