package com.example.jpa;

import jakarta.persistence.*;

@Entity
public class Player {

	@Id
	@GeneratedValue
	private Long id;
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", password=" + password + "]";
	}

	
	
}
