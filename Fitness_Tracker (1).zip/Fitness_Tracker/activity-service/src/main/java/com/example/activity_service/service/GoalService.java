package com.example.activity_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.activity_service.model.Activity;
import com.example.activity_service.model.Goal;
import com.example.activity_service.repository.ActivityRepository;
import com.example.activity_service.repository.GoalRepository;

@Service

public class GoalService {
	@Autowired
    private  GoalRepository goalRepository;
	
	@Autowired
	private ActivityRepository activityRepository;
	
	public Goal saveGoal(Goal goal,Long userId) {
	                       
		// Step 1: Fetch activity for user
        Activity activity = activityRepository.findFirstByUserId(userId);

        if (activity != null) {
            goal.setActivity(activity); // Step 2: Assign activity to goal
        } else {
            throw new RuntimeException("No activity found for userId: " + userId);
        }

        return goalRepository.save(goal); // Step 3: Save goal
 
	}


    public List<Goal> getAllGoals() {
        return goalRepository.findAll();
    }


	public List<Goal> findByActivityUserId(Long userId) {
		// TODO Auto-generated method stub
		return goalRepository.findByActivityUserId(userId);
	}
}
