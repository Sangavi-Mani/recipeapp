package com.example.activity_service.controller;

import com.example.activity_service.model.Activity;
import com.example.activity_service.model.Goal;
import com.example.activity_service.service.ActivityService;
import com.example.activity_service.service.GoalService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // for Angular access
public class ActivityController {

	@Autowired
    private  ActivityService activityService;
	@Autowired
    private  GoalService goalService;

    // ✅ GET all activities by userId
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Activity>> getActivitiesByUser(@PathVariable Long userId) {
        List<Activity> activities = activityService.getActivitiesByUser(userId);
        return ResponseEntity.ok(activities);
    }

    // ✅ POST goal for a user
    @PostMapping("/goals/{userId}")
    public ResponseEntity<Goal> setGoal(@RequestBody Goal goal, @PathVariable Long userId) {
        Goal savedGoal = goalService.saveGoal(goal,userId);
        return ResponseEntity.ok(savedGoal);
    }
 // 🔹 POST /api/activities
    @PostMapping("/activities")
    public ResponseEntity<Activity> logActivity(@RequestBody Activity activity) {
        Activity savedActivity = activityService.logActivity(activity);
        return ResponseEntity.ok(savedActivity);
    }
    @GetMapping("/goals/user/{userId}")
    public ResponseEntity<List<Goal>> getGoalsByUser(@PathVariable Long userId) {
        List<Goal> goals = goalService.findByActivityUserId(userId);
        return ResponseEntity.ok(goals);
    }
   
}
