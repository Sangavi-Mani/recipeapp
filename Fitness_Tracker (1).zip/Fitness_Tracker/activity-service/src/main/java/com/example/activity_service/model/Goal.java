package com.example.activity_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity
public class Goal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int targetSteps;
    private double targetCalories;

    
    
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "activity_id")  // Foreign key column
    private Activity activity;

    
    public Activity getActivity() {
		return activity;
	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}

	
	
	public Goal() {
    	super();
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getTargetSteps() {
		return targetSteps;
	}

	public void setTargetSteps(int targetSteps) {
		this.targetSteps = targetSteps;
	}

	public double getTargetCalories() {
		return targetCalories;
	}

	public void setTargetCalories(double targetCalories) {
		this.targetCalories = targetCalories;
	}

	    
    
}

