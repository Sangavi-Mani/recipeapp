package com.demo.collections;

import java.util.ArrayList;
import java.util.List;

/*
 * This class contains methods for adding Fruits to a List and searching the fruits from the List
 */
public class FruitsListService {

    public static List<String> addFruitsToList(String fruitNames) {
        return null;
    }

    public static int searchFruitInList(List<String> fruitList, String searchFruit) {
        return -2;
    }

    public static int searchFruitInListIgnoreCase(List<String> fruitList, String searchFruit) {
        return -2;
    }
}