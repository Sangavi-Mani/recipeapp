package com.demo.exercises;

public class WrongInputException extends Exception {
    public WrongInputException(String message) {
        super(message);
    }
}
