package com.demo.exercises;

public enum CarType {
    HatchBack,
    SUV,
    Sedan,
    PickupTruck,
}
