package com.example.recipe_service.service;

import com.example.recipe_service.dto.CategoryDTO;
import com.example.recipe_service.dto.IngredientDTO;
import com.example.recipe_service.dto.RecipeResponseDTO;
import com.example.recipe_service.model.Recipe;
import com.example.recipe_service.repository.RecipeRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecipeService {

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private RestTemplate restTemplate;

	private final String CATEGORY_SERVICE_URL = "http://localhost:1000/category";
	private final String INGREDIENT_SERVICE_URL = "http://localhost:2000/ingredient";
	
	private IngredientDTO ingredientDTO;
	private CategoryDTO categoryDTO;
	
	

	public Recipe saveRecipe(Recipe recipe) {
		return recipeRepository.save(recipe);
	}

	public IngredientDTO getIngredientDTO() {
		return ingredientDTO;
	}

	public void setIngredientDTO(IngredientDTO ingredientDTO) {
		this.ingredientDTO = ingredientDTO;
	}

	public CategoryDTO getCategoryDTO() {
		return categoryDTO;
	}

	public void setCategoryDTO(CategoryDTO categoryDTO) {
		this.categoryDTO = categoryDTO;
	}

	public List<Recipe> getAllRecipes() {
		return recipeRepository.findAll();
	}

	public Optional<Recipe> getRecipeById(Long id) {
		return recipeRepository.findById(id);
	}

	public void deleteRecipe(Long id) {
		recipeRepository.deleteById(id);
	}

	public Recipe updateRecipe(Long id, Recipe updatedRecipe) {
		return recipeRepository.findById(id).map(recipe -> {
			recipe.setName(updatedRecipe.getName());
			recipe.setDescription(updatedRecipe.getDescription());
			recipe.setTime(updatedRecipe.getTime());
			recipe.setCategoryId(updatedRecipe.getCategoryId());
			recipe.setIngredientIds(updatedRecipe.getIngredientIds());
			return recipeRepository.save(recipe);
		}).orElseThrow(() -> new RuntimeException("Recipe not found with id " + id));
	}

	/*public RecipeResponseDTO getRecipeDetails(Long id) {
		Recipe recipe = recipeRepository.findById(id).orElseThrow(() -> new RuntimeException("Recipe not found"));

		CategoryDTO category = restTemplate.getForObject(CATEGORY_SERVICE_URL + "/" + recipe.getCategoryId(),
				CategoryDTO.class);

		List<IngredientDTO> ingredients = recipe
				.getIngredientIds().stream().map(ingredientId -> restTemplate
						.getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId, IngredientDTO.class))
				.filter(Objects::nonNull).collect(Collectors.toList());

		RecipeResponseDTO response = new RecipeResponseDTO();
		response.setId(recipe.getId());
		response.setName(recipe.getName());
		response.setDescription(recipe.getDescription());
		response.setTime(recipe.getTime());
		response.setCategory(category);
		response.setIngredients(ingredients);

		return response;
	}*/
	
	@CircuitBreaker(name = "recipeDetailsCB", fallbackMethod = "recipeFallback")
    public RecipeResponseDTO getRecipeDetails(Long id) {
        Recipe recipe = recipeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));

        // Category (Circuit Breaker)
        CategoryDTO category = getCategoryById(recipe.getCategoryId());

        // Ingredients (Circuit Breaker per call)
        List<IngredientDTO> ingredients = recipe.getIngredientIds().stream()
                .map(this::getIngredientById)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        RecipeResponseDTO response = new RecipeResponseDTO();
        response.setId(recipe.getId());
        response.setName(recipe.getName());
        response.setDescription(recipe.getDescription());
        response.setTime(recipe.getTime());
        response.setCategory(category);
        response.setIngredients(ingredients);

        return response;
    }

    @CircuitBreaker(name = "categoryServiceCB", fallbackMethod = "categoryFallback")
    
    public CategoryDTO getCategoryById(Long categoryId) {
        return restTemplate.getForObject(CATEGORY_SERVICE_URL + "/" + categoryId, CategoryDTO.class);
    }

    public CategoryDTO categoryFallback(Long categoryId, Throwable ex) {
    	CategoryDTO category = restTemplate.getForObject(CATEGORY_SERVICE_URL + "/" + categoryId, CategoryDTO.class);
        if(category ==  null)
        	return new CategoryDTO(categoryId, "Unknown Category (fallback)");
        else {
        	setCategoryDTO(category);
        	return category;
        }
    }

    @CircuitBreaker(name = "ingredientServiceCB", fallbackMethod = "ingredientFallback")
    public IngredientDTO getIngredientById(Long ingredientId) {
    	IngredientDTO ingredient = restTemplate.getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId, IngredientDTO.class);
    	   System.out.println(" $$$$$$$ "+ingredient);
        return ingredient;
    }

    public IngredientDTO ingredientFallback(Long ingredientId, Throwable ex) {
    	IngredientDTO ingredient = restTemplate.getForObject(INGREDIENT_SERVICE_URL + "/" + ingredientId, IngredientDTO.class);
        if(ingredient == null)
        	return new IngredientDTO(ingredientId, "Unknown Ingredient (fallback)");
        else {
        	setIngredientDTO(ingredient);
        	return ingredient;
        }
    }

    public RecipeResponseDTO recipeFallback(Long id, Throwable ex) {
        RecipeResponseDTO fallback = new RecipeResponseDTO();
        Recipe recipe = recipeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));
        if(recipe == null ) {
	        fallback.setId(id);
	        fallback.setName("Unknown Recipe");
	        fallback.setDescription("Recipe service is currently unavailable.");
	        if(getCategoryDTO() == null)
	        	fallback.setCategory(new CategoryDTO(0L, "Unavailable"));
	        else
	        	fallback.setCategory(getCategoryDTO());
	        if(getIngredientDTO() == null)
	        	fallback.setIngredients(Collections.emptyList());
	        else {
	        	List ind = new ArrayList<IngredientDTO>();
	        	ind.add(ingredientDTO);
	        	fallback.setIngredients(ind);
	        }
	        			
        }else {
        	fallback.setId(recipe.getId());
	        fallback.setName(recipe.getName());
	        fallback.setDescription(recipe.getDescription());
	        fallback.setTime(recipe.getTime());
	        if(getCategoryDTO() == null)
	        	fallback.setCategory(new CategoryDTO(0L, "Unavailable"));
	        else
	        	fallback.setCategory(getCategoryDTO());
	        	List<Long> ingredients = recipe.getIngredientIds();
	        	List<IngredientDTO> ingredientList = new ArrayList<IngredientDTO>();
	        	for(Long ingredientId : ingredients) {
	        		IngredientDTO existingIngredient = getIngredientById(ingredientId);
				        if(existingIngredient==null) {
				        	fallback.setIngredients(Collections.emptyList());
				        } else {
				        	System.out.println(" Inside %%%%%%%%%%%%%%%%%%");
				        	ingredientList.add(existingIngredient);
				        	
				        }
	        	}
	        	if(ingredientList != null  && ingredientList.size()> 0){
	        		fallback.setIngredients(ingredientList);
	        	}else {
	        		fallback.setIngredients(Collections.emptyList());
	        	}
	        
        }
        return fallback;
    }
}