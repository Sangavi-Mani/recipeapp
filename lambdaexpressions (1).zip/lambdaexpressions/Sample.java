package day7.lambdaexpressions;


public interface Sample {
    void ab();
}