package com.example.jpa;

import java.util.*;
import jakarta.persistence.*;

public class JpaCrudExample {

  public static void main(String[] args) throws Exception {
    JpaCrudExample.createRecord();
    JpaCrudExample.retrieveRecord();
    JpaCrudExample.updateRecord();
    JpaCrudExample.deleteRecord();
  }

  public static void createRecord() {
	  EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
	  EntityManager entityManager = emf.createEntityManager();

	  entityManager.getTransaction().begin();

	  Player p = new Player();
	  p.setPassword("my-password");
	  entityManager.persist(p);
	  
	  Match m = new Match();
	  m.setName("CSKvsLSG");
	  entityManager.persist(m);

	  entityManager.getTransaction().commit();
	 }

  public static void retrieveRecord() {
	  EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
	  EntityManager entityManager = emf.createEntityManager();

	  entityManager.getTransaction().begin();
	  Long key = Long.valueOf(1);
	  Player p = entityManager.find(Player.class, key);
	  System.out.println(p.getPassword());
	  
	  
	  
	  //select * from match where matchId=1
	  Long key1 = Long.valueOf(1);
	  Match m = entityManager.find(Match.class, key1);
	  System.out.println(m.getName());


	  entityManager.getTransaction().commit();
	 }
  public static void updateRecord() { }
  public static void deleteRecord() {

	  EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-tutorial");
	  EntityManager entityManager = emf.createEntityManager();

	  entityManager.getTransaction().begin();
	  Long key = Long.valueOf(2);
	  Player p = entityManager.find(Player.class, key);
	  entityManager.remove(p);

	  entityManager.getTransaction().commit();

	 }


}


