package com.example.jpa;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;



/*

🧩 Realistic Relationship Assumptions:
A Match can have many Scores → OneToMany

A Score belongs to one Match → ManyToOne

A Player can have many Scores (player scores in different matches) → OneToMany

A Score belongs to one Player → ManyToOne
*/

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("fdssd");
  	  EntityManager entityManager = emf.createEntityManager();
  	entityManager.getTransaction().begin();

 // Create player
    Player player = new Player();
    player.setPassword("abc345");

    // Create match
    Match match = new Match();
    match.setName("MI vs RCB");

    // Create score
    Score score = new Score();
    score.setScoreId(2);
    score.setMatchName("MI vs RCB");
    score.setMatch(match);
    score.setPlayer(player);

    // Set relations
    match.getScores().add(score);
    player.getScores().add(score);

    // Persist
    entityManager.persist(player);
    entityManager.persist(match);
    entityManager.persist(score);

    entityManager.getTransaction().commit();

 new App().fetchAllPlayersWithScores(entityManager);
    }
    
    public void fetchAllPlayersWithScores(EntityManager em) {
        List<Player> players = em.createQuery("SELECT p FROM Player p", Player.class)
                                 .getResultList();

        for (Player p : players) {
            System.out.println("Player ID: " + p.getId());
            for (Score s : p.getScores()) {
                System.out.println("  Match: " + s.getMatchName());
            }
        }
    }

}
