package com.example.jpa;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;


@Entity
public class Player {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String password;
	
	@OneToMany
	private List<Score> scores = new ArrayList();
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Score> getScores() {
		return scores;
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", password=" + password + ", scores=" + scores + "]";
	}

	

	
	
}
