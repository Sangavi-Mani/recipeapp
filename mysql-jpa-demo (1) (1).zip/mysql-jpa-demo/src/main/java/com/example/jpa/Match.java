package com.example.jpa;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name="ipl_match")
public class Match {
	
	@Id
	@Column(name="match_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int matchId;
	
	private String name;
	
	@OneToMany
	private List<Score> scores = new ArrayList();
	
	public List<Score> getScores() {
		return scores;
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}

	public Match() {
		
	}

	public int getMatchId() {
		return matchId;
	}

	public void setMatchId(int matchId) {
		this.matchId = matchId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
